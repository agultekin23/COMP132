/* *********** Pledge of Honor ************************************************ *

I hereby certify that I have completed this lab assignment on my own
without any help from anyone else. I understand that the only sources of authorized
information in this lab assignment are (1) the course textbook, (2) the
materials posted on the course website, and (3) any study notes handwritten by myself.
I have not used, accessed, or received any information from any other unauthorized
source in taking this lab assignment. The effort in the assignment thus belongs
completely to me.
READ AND SIGN BY WRITING YOUR NAME SURNAME, AND STUDENT ID
SIGNATURE: <Adnan Gültekin, 86816>
********************************************************************************/
package operation;

import timeTravel.*;

public class Main {
	public static void main(String[] args) {
        // Create a operation control with a fixed number of operations
		OperationControl simulator = new OperationControl(3);

		Chrononaut e1 = new Chrononaut("Dr. Celeste Orion", 101); //Lead chrononaut and expedition commander
		Chrononaut e2 = new Chrononaut("Captain Nova Vega", 102); // Bold explorer from the future’s Chrono-Fleet
        Chrononaut e3 = new Chrononaut("Professor Aris Kepler", 103); // Historian-scientist specializing in temporal physics

        // Create and add eras to the time control
        Era location1 = new Era("Renaissance Florence"); // Era of art, invention, and exploration
        Era location2 = new Era("Neo-Tokyo 2200");       // A futuristic era of neon megacities
        Era location3 = new Era("Bronze Age Mesopotamia"); // Birthplace of writing and ancient astronomy
        Era location4 = new Era("Frozen Antarctica 3050");  // Post-climate-shift future buried in ice

        location1.collectSample("Da Vinci's Blueprint");
        location1.collectSample("Guild Ledger");

        location2.collectSample("Quantum Transit Pass");
        location2.collectSample("Neon Energy Cell");

        location3.collectSample("Clay Tablet");
        location3.collectSample("Cylinder Seal");
        location3.collectSample("Star Chart");
        location3.collectSample("Irrigation Plan");
        location3.collectSample("Bronze Alloy Fragment");
        location3.collectSample("Ancient Chrono Dial");

        // Add Temporal Entities to the expeditions
        TemporalEntity entity1 = new TemporalEntity("Archivum", "I was preserving trade records from a vanished guild.");
        TemporalEntity entity2 = new TemporalEntity("Vireen", "I was collecting quantum data to stabilize the city's time core.");
        TemporalEntity entity3 = new TemporalEntity("Xylog", "I am searching for my lost chronometric arm.");

        // Create and add expeditions to the time control
        Operation quest1 = new Operation(location1);
        Operation quest2 = new Operation(location2);
        Operation quest3 = new Operation(location3);
        Operation quest4 = new Operation(location4);

        quest1.setTemporalEntity(entity1);
        quest2.setTemporalEntity(entity2);
        quest3.setTemporalEntity(entity3);

        quest1.setChrononaut(e1);
        quest2.setChrononaut(e2);
        quest3.setChrononaut(e3);

        // Add expeditions to the time control
        simulator.addOperation(quest1);
        simulator.addOperation(quest2);
        simulator.addOperation(quest3);
        simulator.addOperation(quest4);

        // Start the expedition
        simulator.startOperation();

        ////////////////////////// inLab test code //////////////////////////
        ///
        System.out.print("\n\n------------------------ In lab ------------------------\n\n");
        TemporalEntity entity4 = new TemporalEntity("Omekra", "I was studying the flora of this timeline’s frozen biosphere.");
        // Create the complex Operation Control
        ComplexOperationControl simulator2 = new ComplexOperationControl(3);
        // Create complex expeditions and add them to the complex operation control
        ComplexOperation complexCase1 = new ComplexOperation(location1, 3);
        ComplexOperation complexCase2 = new ComplexOperation(location2, 2);
        ComplexOperation complexCase3 = new ComplexOperation(location3, 4);
        ComplexOperation complexCase4 = new ComplexOperation(location4, 2);
        complexCase1.setChrononaut(e1);
        complexCase2.setChrononaut(e2);
        complexCase3.setChrononaut(e3);
        // Add Temporal Entities to the expeditions
        complexCase1.addTemporalEntity(entity1);
        complexCase1.addTemporalEntity(entity2);
        complexCase1.addTemporalEntity(entity3);
        complexCase2.addTemporalEntity(entity1);
        complexCase2.addTemporalEntity(entity2);
        complexCase2.addTemporalEntity(entity3);
        complexCase3.addTemporalEntity(entity1);
        complexCase3.addTemporalEntity(entity2);
        complexCase3.addTemporalEntity(entity3);
        complexCase3.addTemporalEntity(entity4);
        complexCase4.addTemporalEntity(entity1);
        complexCase4.addTemporalEntity(entity2);
        // Add expeditions to the simulator
        simulator2.addComplexOperation(complexCase1);

        simulator2.addComplexOperation(complexCase2);
        simulator2.addComplexOperation(complexCase3);
        simulator2.addComplexOperation(complexCase4);
        // Start the expedition
        simulator2.startOperation();

        
    }

}

