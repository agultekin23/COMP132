
public class ComplexOperationControl {
	ComplexOperation[] operations;
	int currentOperationIndex;
	

public ComplexOperationControl(int numberOfOperations) {
	this.operations = new ComplexOperation[numberOfOperations];
	
}

public void addComplexOperation(ComplexOperation complexOperation) {
	if(currentOperationIndex<operations.length) {
		operations[currentOperationIndex] = complexOperation;
		currentOperationIndex++;
	}else {
		System.out.println("Cannot add more operations. Maximum limit reached.");
	}
	}
public void startOperation() {
	
	System.out.println("--------------------- New Operation -------------------");
	System.out.println("Investigating the Operation:");
	

	
}


	




public ComplexOperation[] getOperations() {
	return operations;
}

public int getCurrentOperationIndex() {
	return currentOperationIndex;
}
}