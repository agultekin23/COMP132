import timeTravel.Chrononaut;
import timeTravel.Era;
import timeTravel.Operation;
import timeTravel.TemporalEntity;

public class ComplexOperation {
	private Era era;
	private TemporalEntity [] temporalEntities;
	private int currentTemporalEntityIndex=0;
	private Chrononaut chrononaut;
	
	public ComplexOperation(Era era, int numberOfTemporalEntities) {
		this.era=era;
		this.temporalEntities = new TemporalEntity[numberOfTemporalEntities];
		
	}
	
	public void displayComplexOperationDetails() {
		System.out.println("Era: " + era.getname());
		System.out.println("Chrononaut Name: " + chrononaut.getName());
		System.out.println("TemporalEntities: " );
		for(int i=0; i<this.currentTemporalEntityIndex; i++) {
			System.out.println("-" + temporalEntities[i].getEntitySpecies());
		
			
		

		}
		

	}
	
	public void addTemporalEntity(TemporalEntity temporalEntity) {
		if(currentTemporalEntityIndex<temporalEntities.length) {
			this.temporalEntities[currentTemporalEntityIndex] = temporalEntity;
			currentTemporalEntityIndex++;
		}else {
			System.out.println("Cannot add more temporalEntities. Maximum limit reached.");
		
		
	}
	public static void interact(String question, TemporalEntity[], temporalEntities) {
		System.out.println("Expedition: ");
		System.out.println("The Chrononaut for this operation is: " + chron);

	}

}

	public void setEra(Era era) {
		this.era = era;
	}

	public void setTemporalEntities(TemporalEntity[] temporalEntities) {
		this.temporalEntities = temporalEntities;
	}

	public void setCurrentTemporalEntityIndex(int currentTemporalEntityIndex) {
		this.currentTemporalEntityIndex = currentTemporalEntityIndex;
	}

	public void setChrononaut(Chrononaut chrononaut) {
		this.chrononaut = chrononaut;
	}
}
