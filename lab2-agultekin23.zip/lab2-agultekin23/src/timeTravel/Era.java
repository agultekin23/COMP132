package timeTravel;

public class Era {

	static final int MAX_SAMPLES=5;
	
	public String name;
	public String[] samples = new String [MAX_SAMPLES];
	public int numOfSamples=0;
	
	public Era(String name) {
		this.name = name;
		this.samples = new String[MAX_SAMPLES];
		
		}
	
	public void collectSample(String sample) {
		if(numOfSamples<MAX_SAMPLES) {
			samples[numOfSamples] = sample;
		}else {
		System.out.println("Boş yer yok.");
		}
		
		
	}
	
	
	public void displayEraInfo() {
		
		System.out.println("Era Name: " + name);
		System.out.println("Samples: ");
		for(int i=0; i<samples.length; i++) {
			if(samples[i]!=null) {
			System.out.println("- " + samples[i]);
		}}
		
	}
	public String getname() {
		return name;
		}	
		
	}


