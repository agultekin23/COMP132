package timeTravel;

public class OperationControl {
	private Operation [] operations;
	private int currentOperationIndex=0;
	
public OperationControl(int numberOfOperations) {
		this.operations = new Operation[numberOfOperations];

}

public void addOperation(Operation operation) {
	if(currentOperationIndex<operations.length) {
		this.operations[currentOperationIndex] = operation;
		currentOperationIndex = currentOperationIndex + 1;
	}else {
		System.out.println("Cannot add more operations. Maximum limit reached.");
	}
	
}

public void startOperation() {
	for(int i=0; i<currentOperationIndex; i++) {
		Operation currentOperation = operations[i];
		System.out.println("--------------------- New Operation -------------------");
		currentOperation.getEra().displayEraInfo();
		System.out.println();
		currentOperation.displayOperationDetails();
		String question = "What were you doing in this era?";
		TemporalEntity.interact(question, currentOperation.getTemporalEntity());
		System.out.println("Operation Expedition Completed.");

		
		
	}
}

}



