package timeTravel;

public class Operation {
	private Era era;
	private TemporalEntity temporalEntity;
	private Chrononaut chrononaut;
	
	public Operation(Era era) {
		this.era = era;
		
	}
	public void setChrononaut(Chrononaut chrononaut){
		this.chrononaut = chrononaut;
	}
	
	public void setTemporalEntity(TemporalEntity temporalEntity){
		this.temporalEntity = temporalEntity;
	}
	
	public void displayOperationDetails() {
		System.out.println("Operation details: ");
		System.out.println("Era: " + era.getname());
		System.out.println("Chrononaut name: " chrononaut.getName());
		System.out.println("TemporalEntity Species: " temporalEntity.getEntitySpecies());
		
	}
	public Era getEra() {
		return era;
	}
	
	public TemporalEntity getTemporalEntity() {
		return temporalEntity;
	}

}
