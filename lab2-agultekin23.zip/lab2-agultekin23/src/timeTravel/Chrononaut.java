package timeTravel;

public class Chrononaut {

	private String name;
	private int chrononautID;
			
		
	public Chrononaut(String name, int chrononautID) {
		this.name = name;
		this.chrononautID = chrononautID;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getChrononautID() {
		return chrononautID;
	}


	public void setChrononautID(int chrononautID) {
		this.chrononautID = chrononautID;
	}
		



}