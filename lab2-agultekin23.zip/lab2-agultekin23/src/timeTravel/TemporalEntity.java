package timeTravel;

import java.util.Random;

public class TemporalEntity {
	public static Random RAND = new Random(2025);
	private static String species;
	private String motive; 
	
	public TemporalEntity(String species, String motive) {
		this.species = species;
		this.motive = motive;
		
		
	}
	public static void interact(String question, TemporalEntity temporalEntity) {
			System.out.println(question);
			System.out.println("TemporalEntity Species: " + temporalEntity);
			
		
		
			/*Operation Details:
			Era: Renaissance Florence
			Chrononaut Name: Dr. Celeste Orion
			TemporalEntity Species: Archivum
			Chrononaut: What were you doing in this era? 
			The TemporalEntity Archivum's response: I was preserving trade records from a vanished guild.
			The TemporalEntity Archivum is hostile.
			Operation Expedition Completed.*/


	}
	public static String getEntitySpecies() {
		return species;
	}
	public String getMotive() {
		return motive;
	}
	
	}


