[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/UnnZ2qt7)
# COMP132, Fall 2025, Lab-2 PreLab

# IMPORTANT

For each lab assignment, **you must include and sign (by writing your name and student ID number) the following Pledge of Honor statement at the beginning of your main method source code file. After including this statement, make sure that you do the commit and push operation on GitHub. Otherwise, your lab solution will not be graded.**
```
/* *********** Pledge of Honor ************************************************ *

I hereby certify that I have completed this lab assignment on my own
without any help from anyone else. I understand that the only sources of authorized
information in this lab assignment are (1) the course textbook, (2) the
materials posted on the course website, and (3) any study notes handwritten by myself.
I have not used, accessed, or received any information from any other unauthorized
source in taking this lab assignment. The effort in the assignment thus belongs
completely to me.
READ AND SIGN BY WRITING YOUR NAME SURNAME, AND STUDENT ID
SIGNATURE: <Name Surname, Student id>
********************************************************************************/
```
## IMPORTANT NOTES: 

   ##### :pushpin: - All instance variables MUST be private unless specified otherwise, and they should have the exact name written in the instructions.
   ##### :pushpin: - You should implement getter/setter methods whenever needed (for example, if you are going to access the instance variables from other classes). You may use auto-generator for getter/setter methods (under the Source menu in Eclipse). Do NOT implement unused Getter/Setter methods. You will be penalized for each unused Getter/Setter.
   ##### :pushpin: -  You MUST follow the instructions (Package name, Class name, method name, variables, ...) so carefully. The packages, classes, instance variables, and methods MUST be created following the descriptions given in the assignment.
   ##### :pushpin: -  Please check the sample output provided at the end of this assignment. Your output MUST be exactly the same as the provided sample output.
   ##### :pushpin: -  After you complete the tasks, do not forget to commit your changes and push them to your repository on GitHub BEFORE 9.30 :clock930: AM, Friday.
   ##### :pushpin: -  This README.md file only contains the instructions for PRELAB. You will also have INLAB questions.


   
# Lab-2 PreLab: Time Travel Operation Simulator

In this prelab, your task is to develop a Time Travel Operation Simulator, where chrononauts travel to different eras, collect historical samples, encounter temporal entities, and complete operations. Below are the details of the classes and methods you need to implement:


#### In this assignment, you need to create two packages and the corresponding classes inside them as follows:
- **timeTravel** package including the following classes
   - Chrononaut class
   - Era class
   - TemporalEntity class
   - Operation class
   - OperationControl class

- **operation** package including the following class
   - Main class (Given)

![](/img/lab2.jpg?raw=true "")

## timeTravel package:

### Chrononaut Class:
 
#### Instance Variables:
- String name: The name of the chrononaut.
- int chrononautID: The unique ID of the chrononaut.

#### Methods:
```java
public Chrononaut(String name, int chrononautID):
```
Constructor to initialize the chrononaut with a name and ID.
 
### Era Class:

#### Class Variables:
- static final int MAX_SAMPLES: Determines the maximum number of samples that can be collected (should be initialized to 5).

#### Instance Variables:
- String name: The name of the Era.
- String[] samples (fixed size array with the size MAX_SAMPLES): An array of samples collected from the Era.
- int numOfSamples: An integer to keep track of the number of samples collected.
 
#### Methods:
```java
public Era(String name):
```
Constructor to initialize the Era with a name.
```java
public void collectSample(String sample):
```
Method to add a sample to the samples array. If the array is full, the method should display "Sample collection limit reached for this era."
```java
public void displayEraInfo():
```
Method to display the era details and collected samples. (See sample output for display format)

 
### TemporalEntity Class:

#### Class Variable:
- final static Random RAND: Used to decide if the temporalEntity is friendly or hostile, randomly. It should generate a random Boolean value, which will be used in the interact() method.

**Note:** Use a **constant seed of 2025** for the Random class to produce consistent outputs.

#### Instance Variables:
- String species: The name of the temporalEntity species.
- String motive: The temporalEntity’s reason for interacting with the chrononauts.
 
#### Methods:
```java
public TemporalEntity(String species, String motive):
```
Constructor to initialize the temporalEntity.
```java
public static void interact(String question, TemporalEntity temporalEntity): 
```
A static method that interacts with the given temporalEntity by asking a question and displaying its response. Also, randomly determines whether they are friendly or hostile.
(See sample output for required formatting and question to use in your implementation)

#### Important Note: You MUST use RAND.nextBoolean() from the Random class to decide whether the temporal entity is hostile or friendly. In your implementation, a return value of true from RAND.nextBoolean() should mean the temporal entity is hostile.

 
### Operation Class:
 
#### Instance Variables:
- Era era: The era being explored in the operation.
- TemporalEntity temporalEntity: A temporalEntity encountered on the operation.
- Chrononaut chrononaut: The chrononaut responsible for the operation.

#### Methods:
```java
public Operation(Era era):
```
Constructor to initialize the operation with an era.
```java
public void displayOperationDetails():
```
A method to display the operation details, including the era, the chrononaut, and the temporalEntity encounter. (See sample output for required formatting)


## OperationControl Class:
 
#### Instance Variables:
- Operation [ ] operations: A fixed-size array to keep track of operations.
- int currentOperationIndex: Tracks the current operation index.

#### Methods:
```java
public OperationControl(int numberOfOperations):
```
Constructor to initialize the currentOperationIndex to zero, and set up the operations array.

*Hint*: It is possible to use numberOfOperations when setting up the array.
```java
public void addOperation(Operation operation):
```
Method to add an operation to the simulator. Whenever the operations array gets full, the new operation cannot be added and the following message should be displayed:  
"Cannot add more operations. Maximum limit reached."
```java
public void startOperation():
```
This method begins the exploration simulation by displaying the era information,  operation details, and interacting with the temporal entity. Your implementation should make use of the displayEraInfo(), displayOperationDetails(), and Interact() methods which you have previously implemented. 

 
## Main Class:

The provided Main class is for testing your implemented Java application. You are not allowed to change the given main file. You should add the pledge of honor to it. Any change more than that may lead to grade reduction.



 ## Sample output
```
Sample collection limit reached for this era.
Cannot add more operations. Maximum limit reached.

--------------------- New Operation -------------------

Era Name: Renaissance Florence
Samples: 
- Da Vinci's Blueprint
- Guild Ledger

Operation Details:
Era: Renaissance Florence
Chrononaut Name: Dr. Celeste Orion
TemporalEntity Species: Archivum
Chrononaut: What were you doing in this era? 
The TemporalEntity Archivum's response: I was preserving trade records from a vanished guild.
The TemporalEntity Archivum is hostile.
Operation Expedition Completed.

--------------------- New Operation -------------------

Era Name: Neo-Tokyo 2200
Samples: 
- Quantum Transit Pass
- Neon Energy Cell

Operation Details:
Era: Neo-Tokyo 2200
Chrononaut Name: Captain Nova Vega
TemporalEntity Species: Vireen
Chrononaut: What were you doing in this era? 
The TemporalEntity Vireen's response: I was collecting quantum data to stabilize the city's time core.
The TemporalEntity Vireen is friendly.
Operation Expedition Completed.

--------------------- New Operation -------------------

Era Name: Bronze Age Mesopotamia
Samples: 
- Clay Tablet
- Cylinder Seal
- Star Chart
- Irrigation Plan
- Bronze Alloy Fragment

Operation Details:
Era: Bronze Age Mesopotamia
Chrononaut Name: Professor Aris Kepler
TemporalEntity Species: Xylog
Chrononaut: What were you doing in this era? 
The TemporalEntity Xylog's response: I am searching for my lost chronometric arm.
The TemporalEntity Xylog is friendly.
Operation Expedition Completed.
```
