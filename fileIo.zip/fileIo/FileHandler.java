package fileIo;

import java.io.*;
import java.security.SecureRandom;
import java.util.*;

public class FileHandler {
    
	public String era;
    public String playerRole;
    public int round, totalRounds, gridSize;

    public int scoreApex, xApex, yApex, cooldownApex;
    public int scorePredator, xPredator, yPredator, cooldownPredator;
    public int scorePrey, xPrey, yPrey, cooldownPrey;

    public int xFood, yFood;
    public String foodName;

    private static final String LOG_PATH = "log.txt";
    /*
     * That method is for get names from .animals.txt file by generic form of selectedEra parameters. and it splits the files according to ":".
     * at the end it returns nameList without whitespaces thanks to trim function. 
     */

    public List<String> getCharacterNames(String selectedEra) {
        List<String> allFoodChains = new ArrayList<>();
        String fileName = selectedEra.toLowerCase() + "_animals.txt";

        try (Scanner scanner = new Scanner(new File(fileName))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                if (line.contains(":")) {
                    allFoodChains.add(line);
                }
            }
        } catch (FileNotFoundException e) {
            System.err.println("CRITICAL ERROR: File not found -> " + fileName);
            return new ArrayList<>();
        }

        if (allFoodChains.isEmpty()) {
        	return new ArrayList<>();
        }
        SecureRandom secureRandom = new SecureRandom();
        
        int randomIndex = secureRandom.nextInt(allFoodChains.size());
        String chosenLine = allFoodChains.get(randomIndex);

        String afterColon = chosenLine.split(":")[1].trim();
        String[] rawNamesArray = afterColon.split(",");
        
        List<String> cleanedNamesList = new ArrayList<>();

        for (String rawName : rawNamesArray) {
            cleanedNamesList.add(rawName.trim());
        }

        return cleanedNamesList;
    }
    /*
     * It records the datas to log.txt file. data, hour and the other game data's. If it could not find it might be catched by catch blok. 
     */

    public void recordLog(String status, String message) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(LOG_PATH, true))) {
            String timestamp = new java.util.Date().toString();
            String logLine = "[" + timestamp + "] " +
                             "[ERA: " + era + "] " +
                             "[ROUND: " + round + "/" + totalRounds + "] " +
                             status + ": " + message;
            
            writer.println(logLine);
        } catch (IOException e) {
            System.err.println("Logging Error: " + e.getMessage());
        }
    }
    /*
     * It records the movement of characters. 
     */
    public void recordMovement(String name, int x, int y) {
        recordLog("MOVE", name + " moved to square: (" + x + ", " + y + ")");
    }
    /*
     * It records the simulations is finished and who is the winner of that game. 
     */

    public void logGameOver(String winnerName) {
        recordLog("STATUS", "--- SIMULATION FINISHED ---");
        recordLog("WINNER", "The winner is: " + winnerName);
        recordLog("STATUS", "--- GAME OVER ---");
    }
    /*
     * It records the round cmpletion to log.txt file. 
     */
    public void logRoundCompletion() {
        recordLog("INFO", "Round " + round + " has been played.");
    }
    

    /*
     * that method takes parameters as filename and exports all the data's to that file by that function. We use these datas in savegame.txt file. 
     */
    public void exportFile(String fileName) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(fileName))) {
            writer.println("=== Game Data ===");
            writer.println("GridSize: " + gridSize);
            writer.println("Era: " + era);
            writer.println("PlayerRole: " + playerRole);
            writer.println("CurrentRound: " + round);
            writer.println("TotalRounds: " + totalRounds);
            writer.println();

            writer.println("=== Scores ===");
            writer.println("ApexPredatorScore: " + scoreApex);
            writer.println("PredatorScore: " + scorePredator);
            writer.println("PreyScore: " + scorePrey);
            writer.println();

            writer.println("=== Positions ===");
            writer.println("ApexLocation: " + (xApex + 1) + "," + (yApex + 1));
            writer.println("PredatorLocation: " + (xPredator + 1) + "," + (yPredator + 1));
            writer.println("PreyLocation: " + (xPrey + 1) + "," + (yPrey + 1));
            writer.println("FoodLocation: " + (xFood + 1) + "," + (yFood + 1));
            
            if (foodName != null && !foodName.isEmpty()) {
                writer.println("FoodName: " + foodName);
            }
            writer.println();

            writer.println("=== Cooldowns ===");
            writer.println("ApexCooldown: " + cooldownApex);
            writer.println("PredatorCooldown: " + cooldownPredator);
            writer.println("PreyCooldown: " + cooldownPrey);
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }	

/*
 * we use that method to import datas to log.txt file. It also relevant with savegame.txt since it transfers the datas to savegame.txt file.
 */
    public void importFile(String fileName) {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
           
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("===") || line.trim().isEmpty()) {
                    continue;
                }

                String[] parts = line.split(": ");
                if (parts.length < 2) {
                    continue;
                }
                
                String key = parts[0];
                String value = parts[1];

                if (key.equals("GridSize")) {
                    gridSize = Integer.parseInt(value);
                    
                } else if (key.equals("Era")) {
                    era = value;
                    
                } else if (key.equals("PlayerRole")) {
                    playerRole = value;
                    
                } else if (key.equals("CurrentRound")) {
                    round = Integer.parseInt(value);
                    
                } else if (key.equals("TotalRounds")) {
                    totalRounds = Integer.parseInt(value);
                    
                } else if (key.equals("ApexPredatorScore")) {
                    scoreApex = Integer.parseInt(value);
                    
                } else if (key.equals("PredatorScore")) {
                    scorePredator = Integer.parseInt(value);
                    
                } else if (key.equals("PreyScore")) {
                    scorePrey = Integer.parseInt(value);
                    
                } else if (key.equals("ApexLocation")) {
                    String[] aLoc = value.split(",");
                    xApex = Integer.parseInt(aLoc[0]) - 1;
                    yApex = Integer.parseInt(aLoc[1]) - 1;
                    
                } else if (key.equals("PredatorLocation")) {
                    String[] pLoc = value.split(",");
                    xPredator = Integer.parseInt(pLoc[0]) - 1;
                    yPredator = Integer.parseInt(pLoc[1]) - 1;
                    
                } else if (key.equals("PreyLocation")) {
                    String[] prLoc = value.split(",");
                    xPrey = Integer.parseInt(prLoc[0]) - 1;
                    yPrey = Integer.parseInt(prLoc[1]) - 1;
                    
                } else if (key.equals("FoodLocation")) {
                    String[] fLoc = value.split(",");
                    xFood = Integer.parseInt(fLoc[0]) - 1;
                    yFood = Integer.parseInt(fLoc[1]) - 1;
                    
                } else if (key.equals("FoodName")) {
                    foodName = value;
                    
                } else if (key.equals("ApexCooldown")) {
                    cooldownApex = Integer.parseInt(value);
                    
                } else if (key.equals("PredatorCooldown")) {
                    cooldownPredator = Integer.parseInt(value);
                    
                } else if (key.equals("PreyCooldown")) {
                    cooldownPrey = Integer.parseInt(value);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}