package applications;

public class Application {
	protected String name;
	protected final String domain;
	protected int complexityLevel;
	protected String status;

	public Application(String name, String domain, int complexityLevel) {
		this.status = "In Development";
		this.domain = domain;
		this.complexityLevel = complexityLevel;
	}
	
	public String toString() {
		String str = "Application name: " + name + "/n" + "Complexity level: " + complexityLevel + "/n" + "Status: " + status;
		return str;
	}
	
	public void updateStatus(String newStatus) {
		this.status = newStatus;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getComplexityLevel() {
		return complexityLevel;
	}

	public void setComplexityLevel(int complexityLevel) {
		this.complexityLevel = complexityLevel;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDomain() {
		return domain;
	}
	


}