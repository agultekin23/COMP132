package applications;

public class EnergyOptimization extends Application {
	protected String optimizationTechnique;
	protected boolean renewableIntegration;
	
public EnergyOptimization(String name, String domain, int complexityLevel, String optimizationTechnique, boolean renewableIntegration) {
	super(name, domain, complexityLevel);
	this.optimizationTechnique = optimizationTechnique;
	this.renewableIntegration = renewableIntegration;
}
public String toString() {
	return super.toString() + "\n" + "  Optimization Technique: " + optimizationTechnique + "\n" +  "  Distributed Processing: " + (renewableIntegration ? "Yes" : "No") + "\n" ;
}

public int calculateEstimatedCompletionTime() {
	complexityLevel*=2;
	complexityLevel-=1;
	return complexityLevel;
}

}
