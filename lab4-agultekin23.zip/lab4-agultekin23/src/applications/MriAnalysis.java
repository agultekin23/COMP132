package applications;

public class MriAnalysis extends MedicalEmergencyAI {
	
public MriAnalysis(String name, int complexityLevel, boolean anomalyDetection) {
	super(name, "Medical Emergency AI",complexityLevel,"MRI", anomalyDetection);
	this.name=name;
	this.complexityLevel = complexityLevel;
	this.anomalyDetection = anomalyDetection;
	
	
	
	
}

public int calculateEstimatedCompletionTime(){
	complexityLevel *= 4;
	if(anomalyDetection) {
		complexityLevel +=5;
	}
	return complexityLevel;
}

public String toString() {
	return super.toString() + "\n" + "  Imaging Type: " + imagingType + "\n" +  "  Anomaly Detection: " + (anomalyDetection ? "Yes" : "No") + "\n" ;
}

}
