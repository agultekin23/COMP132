package applications;

public class MedicalEmergencyAI extends Application{
	protected String imagingType;
	protected boolean anomalyDetection;

public MedicalEmergencyAI(String name, String domain, int complexityLevel, String imagingType, boolean anomalyDetection) {
	super(name, domain, complexityLevel);
	this.imagingType = imagingType;
	this.anomalyDetection = anomalyDetection;
}

public String toString() {
	return super.toString() + "\n" + "  Imaging Type: " + imagingType + "\n" +  "  Anomaly Detection: " + (anomalyDetection ? "Yes" : "No") + "\n" ;
}}
