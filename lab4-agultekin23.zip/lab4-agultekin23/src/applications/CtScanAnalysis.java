package applications;

public class CtScanAnalysis extends MedicalEmergencyAI{


	
	public CtScanAnalysis(String name, int complexityLevel, boolean anomalyDetection) {
		super(name, "Medical Emergency AI",complexityLevel,"MRI", anomalyDetection);
		this.name=name;
		this.complexityLevel = complexityLevel;
		this.anomalyDetection = anomalyDetection;
	
		
	}
	

	}