package applications;

public class PublicSafetyAI extends Application{
	protected String safetyDomain;
	protected boolean predictiveAlerts;

public PublicSafetyAI(String name, String domain, int complexityLevel, String safetyDomain, boolean predictiveAlerts) {
	super(name, domain, complexityLevel);
	this.safetyDomain = safetyDomain;
	this.predictiveAlerts = predictiveAlerts;
}

public String toString() {
	return super.toString() + "/nImaging Type: " + safetyDomain + "/nAnomaly Detection: " + predictiveAlerts;
}


}
