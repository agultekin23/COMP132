package applications;

public class UrbanVideoAnalytics extends Application{
	protected int frameRate;
	protected boolean crowdDetection;

public UrbanVideoAnalytics(String name, String domain, int complexityLevel, int frameRate, boolean crowdDetection) {
	super(name, domain, complexityLevel);
	this.frameRate = frameRate;
	this.crowdDetection = crowdDetection;
}

}

