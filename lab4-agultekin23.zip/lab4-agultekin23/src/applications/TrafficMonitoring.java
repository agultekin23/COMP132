package applications;

public class TrafficMonitoring extends Application{
	protected String modelType;
	protected boolean realTimeDetection;

	public TrafficMonitoring(String name, String domain, int complexityLevel, String modelType, boolean realTimeDetection) {
		super(name, domain, complexityLevel);
		this.modelType = modelType;
		this.realTimeDetection = realTimeDetection;
	}
	
	public String toString() {
		return super.toString() + "Model Type: " + modelType + "Uses Pretarieaned Models: " + realTimeDetection;
	}

}
