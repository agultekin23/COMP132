/* *********** Pledge of Honor ************************************************ *

I hereby certify that I have completed this lab assignment on my own
without any help from anyone else. I understand that the only sources of authorized
information in this lab assignment are (1) the course textbook, (2) the
materials posted on the course website, and (3) any study notes handwritten by myself.
I have not used, accessed, or received any information from any other unauthorized
source in taking this lab assignment. The effort in the assignment thus belongs
completely to me.
READ AND SIGN BY WRITING YOUR NAME, SURNAME, AND STUDENT ID
SIGNATURE: <Adnan Gültekin, 86816>
********************************************************************************/
package main;

import applications.*;
import management.*;


public class MainSmartCity {
	public static void main(String[] args) {
        // Create a smart city object
		SmartCityCenter smartCity = new SmartCityCenter();

        // Create some applications
        Application trafficMonitoringApp = new TrafficMonitoring("Object Detection", "Traffic Monitoring", 8, "CNN", true);
        Application safetyApp = new PublicSafetyAI("Detector", "Safety", 7, "Crime Detection", true);
        Application videoApp = new UrbanVideoAnalytics("Live Streaming", "Video Processing", 6, 60, true);
        Application medicalApp = new MedicalEmergencyAI("Trauma Detection", "Medical Emergency AI", 9, "MRI", true);
        Application energyApp = new EnergyOptimization("Load Balancing", "Energy Optimization", 7, "Genetic Algorithms", true);

        System.out.println(trafficMonitoringApp.toString());
        System.out.println(medicalApp.toString());
        System.out.println(energyApp.toString());

        // Add applications to the smart city
        smartCity.addApplication(trafficMonitoringApp);
        smartCity.addApplication(safetyApp);
        smartCity.addApplication(videoApp);
        smartCity.addApplication(medicalApp);
        smartCity.addApplication(energyApp);

        // Create some managers
        ProjectManager manager1 = new ProjectManager("Dr. One", "Traffic Monitoring");
        ProjectManager manager2 = new ProjectManager("Dr. Two", "Energy Optimization");

        // Add managers to the Smart City Center
        smartCity.addManager(manager1);
        smartCity.addManager(manager2);

        // Assign applications to managers
        System.out.println("\n-------------------Assign applications to managers: ");
        smartCity.assignManagerToApplication(manager1, trafficMonitoringApp);
        smartCity.assignManagerToApplication(manager1, safetyApp);
        smartCity.assignManagerToApplication(manager2, energyApp);

        // Create some supervisors
        ApplicationSupervisor supervisor1 = new ApplicationSupervisor("Ms. White", "Model Deployment");
        ApplicationSupervisor supervisor2 = new ApplicationSupervisor("Mr. Walter", "Data Integration");

        // Add supervisors to the smart city
        smartCity.addSupervisor(supervisor1);
        smartCity.addSupervisor(supervisor2);

        //smart city operations
        System.out.println("\nSmart city Tasks:");
        System.out.println("---------------");

        // Organize development cycle
        manager1.organizeDevelopmentCycle();
        manager2.organizeDevelopmentCycle();

        // Monitor application status
        manager1.monitorApplicationStatus();
        manager2.monitorApplicationStatus();

        // Supervisors attend to applications
        supervisor1.attendToApplication(trafficMonitoringApp);
        supervisor1.attendToApplication(safetyApp);
        supervisor2.attendToApplication(videoApp);

        // Supervise development
        supervisor1.superviseDevelopment(medicalApp);
        supervisor2.superviseDevelopment(energyApp);

        // Display attended applications
        smartCity.displayAttendedApplications();

        // Display supervised applications
        smartCity.displaySupervisedApplications();
        
        
        // In lab Test code should be added below this line during the in lab
        System.out.println("\n\n------------------------------------ In Lab ------------------------------------\n");

        System.out.println("--------- Create and add new applications -----------\n");

        Application mr = new MriAnalysis("Brain MRI", 7, true);

        Application mr2 = new MriAnalysis("Bone marrow MRI", 9, false);
        Application ct = new CtScanAnalysis("Chest CT", 8, true);
        Application vi = new TrafficMonitoring("Edge Detection", "Traffic Monitoring", 1, "CNN", true);

        smartCity.addApplication(mr);
        smartCity.addApplication(mr2);
        smartCity.addApplication(ct);
        smartCity.addApplication(vi);

        System.out.println(mr.toString());
        System.out.println(mr2.toString());
        System.out.println(ct.toString());
        System.out.println(vi.toString());

        ProjectManager manager3 = new ProjectManager("Dr. Three", "Medical Emergency AI");
        smartCity.addManager(manager3);

        // Assign applications to managers
        System.out.println("\n------------------- Assign applications to managers: -------------------\n");

        smartCity.assignManagerToApplication(manager3, mr);
        smartCity.assignManagerToApplication(manager3, mr2);
        smartCity.assignManagerToApplication(manager3, ct);

        smartCity.assignManagerToApplication(manager2, ct);

        System.out.println("");
        smartCity.displayEstimatedCT();
        
    }

}
