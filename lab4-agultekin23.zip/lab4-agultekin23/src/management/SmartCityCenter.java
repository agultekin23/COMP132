package management;

import java.util.ArrayList;

import applications.Application;

public class SmartCityCenter {
	private ArrayList<Application> applications = new ArrayList<>();
	private ArrayList<ProjectManager> managers = new ArrayList<>();
	private ArrayList<ApplicationSupervisor> supervisors = new ArrayList<>();
	private String complexityLevel;

public void addApplication(Application application) {
	applications.add(application);
}

public void addManager(ProjectManager manager) {
	managers.add(manager);
}

public void addSupervisor(ApplicationSupervisor supervisor) {
	supervisors.add(supervisor);
}

public void assignManagerToApplication(ProjectManager manager, Application application) {
	manager.assignApplication(application);
}

public void displaySupervisedApplications() {
	System.out.println("\n" + "---- Supervised Applications ----" + "\n");
	for(int i=0; i<supervisors.size(); i++ ) {
		ApplicationSupervisor s = supervisors.get(i);
		for(int j=0; j<s.getSupervisedApplications().size(); j++) {
		Application b = s.getSupervisedApplications().get(j);
		System.out.println(s.getName() + " supervised " + b.getName() + ".");
	}}
}

public void setApplications(ArrayList<Application> applications) {
	this.applications = applications;
}

public void setManagers(ArrayList<ProjectManager> managers) {
	this.managers = managers;
}

public void setSupervisors(ArrayList<ApplicationSupervisor> supervisors) {
	this.supervisors = supervisors;
}

public ArrayList<Application> getApplications() {
	return applications;
}

public ArrayList<ProjectManager> getManagers() {
	return managers;
}

public ArrayList<ApplicationSupervisor> getSupervisors() {
	return supervisors;
}

public void displayAttendedApplications() {
	System.out.println("\n" + "---- Attended Applications ----" + "\n");
	for(int i=0; i<supervisors.size(); i++ ) {
		ApplicationSupervisor k = supervisors.get(i);
		for(int j=0; j<k.getAttendedApplications().size(); j++) {
		Application d = k.getAttendedApplications().get(j);
		System.out.println(k.getName() + " attended " + d.getName() + ".");
	}}
	
}

public void displayEstimatedCT() {
	System.out.println("------ The estimated Completion Time for each application in the AI center ----------- : " + "\n" + "The estimated Completion Time for: ");
	for(int i=0; i<supervisors.size(); i++ ) {
		ApplicationSupervisor k = supervisors.get(i);
		for(int j=0; j<k.getAttendedApplications().size(); j++) {
		Application d = k.getAttendedApplications().get(j);
		System.out.println(k.getName() + " in " + d.getDomain() + " is: " + d.calculateEstimatedCompletionTime());
	}
	
}
	
}

private String calculateEstimatedCompletionTime() {
	// TODO Auto-generated method stub
	return complexityLevel;
}}
