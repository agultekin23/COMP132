package management;
import applications.Application;
import java.util.ArrayList;

public class ProjectManager {
	private String name;
	private String department;
	private ArrayList<Application> assignedApplications;

public ProjectManager(String name, String department) {
	this.name = name;
	this.department = department;
	this.assignedApplications = new ArrayList<>();
	
}

public void assignApplication(Application application) {
	
	if(application.getDomain().equals(this.department)) {
		assignedApplications.add(application);
		System.out.println(application.getName() + " has been assigned to " + name + ".");
		}else {
			System.out.println(application.getName() + " cannot be assigned to " + name + " as it does not match the department.");
		}
}

public void organizeDevelopmentCycle() {
	for(int i=0; i<assignedApplications.size(); i++ ) {
		Application a = assignedApplications.get(i);
		System.out.println(this.name + " is organizing the development cycle for " + a.getName() + ".");
	}
}

public void monitorApplicationStatus() {
	for(int i=0; i<assignedApplications.size(); i++ ) {
		Application a = assignedApplications.get(i);
		System.out.println(this.name + " is monitoring the status of " + a.getName() + ".");
	}
}


}
