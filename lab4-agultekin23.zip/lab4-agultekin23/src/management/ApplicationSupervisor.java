package management;
import applications.Application;
import java.util.ArrayList;

public class ApplicationSupervisor {
	private String name;
	private String focusArea;
	private ArrayList<Application> attendedApplications;
	private ArrayList<Application> supervisedApplications;
	
public String getName() {
		return name;
	}

	public String getFocusArea() {
		return focusArea;
	}

	public ArrayList<Application> getAttendedApplications() {
		return attendedApplications;
	}

	public ArrayList<Application> getSupervisedApplications() {
		return supervisedApplications;
	}

public void setName(String name) {
		this.name = name;
	}

	public void setFocusArea(String focusArea) {
		this.focusArea = focusArea;
	}

	public void setAttendedApplications(ArrayList<Application> attendedApplications) {
		this.attendedApplications = attendedApplications;
	}

	public void setSupervisedApplications(ArrayList<Application> supervisedApplications) {
		this.supervisedApplications = supervisedApplications;
	}

public ApplicationSupervisor(String name, String focusArea) {
	this.name = name;
	this.focusArea = focusArea;
	this.attendedApplications = new ArrayList<>();
	this.supervisedApplications = new ArrayList<>();

}

public void attendToApplication(Application application) {
	attendedApplications.add(application);
	System.out.println(this.name + " is attending to " + application.getName() + " in the focus area: " + this.focusArea + ".");
}

public void superviseDevelopment(Application application) {
	supervisedApplications.add(application);
	System.out.println(this.name + " is supervising the development of " + application.getName() + ".");

}



}
