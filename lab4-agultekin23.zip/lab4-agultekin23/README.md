[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/hDZIWYWA)
# COMP132, Fall 2025, Lab 4 PreLab

# IMPORTANT

For each lab assignment, **you must include and sign (by writing your name and student ID number) the following Pledge of Honor statement at the beginning of your main method source code file. After including this statement, make sure that you do the commit and push operation on GitHub. Otherwise, your lab solution will not be graded.**
```
/* *********** Pledge of Honor ************************************************ *

I hereby certify that I have completed this lab assignment on my own
without any help from anyone else. I understand that the only sources of authorized
information in this lab assignment are (1) the course textbook, (2) the
materials posted on the course website, and (3) any study notes handwritten by myself.
I have not used, accessed, or received any information from any other unauthorized
source in taking this lab assignment. The effort in the assignment thus belongs
completely to me.
READ AND SIGN BY WRITING YOUR NAME, SURNAME, AND STUDENT ID
SIGNATURE: <Name Surname, Student id>
********************************************************************************/
```
## Please carefully review the following important notes. Violating each one of them will result in a grade deduction.

## IMPORTANT NOTES: 

   ##### :pushpin: - All instance variables MUST have the exact name written in the instructions.
   ##### :pushpin: - You should implement getter/setter methods whenever needed (for example, if you are going to access the instance variables from other classes). You may use auto-generator for getter/setter methods (under the Source menu in Eclipse). Do NOT implement unused Getter/Setter methods. You will be penalized for each unused Getter/Setter.
   ##### :pushpin: -  You MUST follow the instructions (Package name, Class name, method name, variables, ...) so carefully. The packages, classes, instance variables, and methods MUST be created following the descriptions given in the assignment.
   ##### :pushpin: -  Please check the sample output provided at the end of this assignment. Your output MUST be exactly the same as the provided sample output.
   ##### :pushpin: -  After you complete the tasks, do not forget to commit your changes and push them to your repository on GitHub BEFORE 9.30 :clock930: AM, Friday.
   ##### :pushpin: -  This README.md file only contains the instructions for PRELAB. You will also have INLAB questions.

  # Lab 4 Prelab: Smart City Innovation Center Coordination System

In this assignment, you are tasked with implementing a Smart City Innovation Center Coordination System, designed to manage various smart city AI applications, their involved researchers, and the projects in a Smart City Center.

This system will help track the progress and management of various AI-powered urban applications in the smart city, including Traffic Monitoring, Energy Optimization, Urban Video Analytics, Public Safety AI, and Medical Emergency AI.

## Assignment Details:

The system has three packages:

- applications package:
  - Application
  - TrafficMonitoring
  - EnergyOptimization
  - UrbanVideoAnalytics
  - PublicSafetyAI
  - MedicalEmergencyAI
- management package:
  - ProjectManager
  - ApplicationSupervisor
  - SmartCityCenter
- main package:
  - MainSmartCity (provided)

##### You must decide on access modifiers (private, protected, public) and appropriate data types where necessary.

<div align="center">
  <img src="/img/01.png" alt="Matrix Operations" />
</div>

# Class Details

## Classes under the applications package:

## Application Class

### Important: All instance variables of the Application class must be protected.

### Instance Variables:
- String `name`: Name of the application.
- final String `domain`: Domain of the application (e.g., "Traffic Monitoring", "Energy Optimization").
- int `complexityLevel`: Complexity level of the application (scale 1-10).
- String `status`: Current status of the application (e.g., "In Development", "Deployed").
  
### Methods:
- `Application(String name, String domain, int complexityLevel)`: Constructor that initializes attributes. Status set to `"In Development"` by default.
- String `toString()`: Method to display the details of the application.
- void `updateStatus(String newStatus)`: Updates the current status of the application.

## TrafficMonitoring Class (Subclass of Application)

### Additional Instance Variables:
- String `modelType`: Type of model used (e.g., "CNN", "Transformer").
- boolean `realTimeDetection`: Whether real-time detection is supported.

### Methods:
- `TrafficMonitoring(String name, String domain, int complexityLevel, String modelType, boolean realTimeDetection)`: Constructor to initialize Traffic Monitoring application attributes.
- Override String `toString()`: Displays Traffic Monitoring-specific details. This method should call its superclass's toString method in this regard.

## UrbanVideoAnalytics Class (Subclass of Application)

### Additional Instance Variables:
- int `frameRate`: Frame rate of analysis, range between 1 and 120 FPS.
- boolean `crowdDetection`: Whether it supports crowd detection.

### Methods:
- `UrbanVideoAnalytics(String name, String domain, int complexityLevel, int frameRate, boolean crowdDetection)`: Constructor to initialize `UrbanVideoAnalytics` application attributes.
- Override String `toString()`: Displays `UrbanVideoAnalytics`-specific details. This method should call its superclass's toString method in this regard.

## PublicSafetyAI Class (Subclass of Application)

### Additional Instance Variables:
- String `safetyDomain`: Area of focus (e.g., "Crime Detection", "Disaster Response").
- boolean `predictiveAlerts`: Whether predictive alerts are generated.

### Methods:
- `PublicSafetyAI(String name, String domain, int complexityLevel, String safetyDomain, boolean predictiveAlerts)`: Constructor to initialize `PublicSafetyAI` application attributes.
- Override String `toString()`: Displays `PublicSafetyAI`-specific details. This method should call its superclass's toString method in this regard.

## MedicalEmergencyAI Class (Subclass of Application)

### Additional Instance Variables:
- String `imagingType`: Type of medical imaging used (e.g., "Thermal", "CT Scan").
- boolean `anomalyDetection`: Whether the application performs anomaly detection in emergency cases.

### Methods:
- `MedicalEmergencyAI(String name, String domain, int complexityLevel, String imagingType, boolean anomalyDetection)`: Constructor to initialize `MedicalEmergencyAI` application attributes.
- Override String `toString()`: Displays `MedicalEmergencyAI`-specific details. This method should call its superclass's toString method in this regard.

## EnergyOptimization Class (Subclass of Application)

### Additional Instance Variables:
- String `optimizationTechnique`: Optimization technique used (e.g., "Gradient Descent", "Meta Heuristic algorithms").
- boolean `renewableIntegration`: Whether it integrates renewable sources.

### Methods:
- `EnergyOptimization(String name, String domain, int complexityLevel, String optimizationTechnique, boolean renewableIntegration)`: Constructor to initialize `EnergyOptimization` application attributes.
- Override String `toString()`: Displays `EnergyOptimization`-specific details.

## Classes under management package:

## ProjectManager Class 

### Instance Variables:
- String `name`: Name of the project manager.
- String `department`: Department managed by the project manager (e.g., "Traffic Monitoring", "Energy Optimization").
- `ArrayList<Application> assignedApplications`: List of applications managed by the project manager.

### Methods:
- `ProjectManager(String name, String department)`: Constructor to initialize project manager attributes.
- void `assignApplication(Application application)`: Assigns an application to the project manager.
   - If the application’s domain matches the manager’s department, it assigns the application and displays a confirmation message.
   - Otherwise, it displays a message that the application cannot be assigned (Check the sample output).
- void `organizeDevelopmentCycle()`: Organizes the development cycle for assigned applications, displaying which manager is assigning which activity to each application.
- void `monitorApplicationStatus()`: Monitors the application status of assigned applications, displaying which manager is overseeing which application.

## ApplicationSupervisor Class 

### Instance Variables:
- String `name`: Name of the application supervisor.
- String `focusArea`: Specific focus area they are responsible for (e.g., “Model Deployment,” “Data Integration”).
- `ArrayList<Application> attendedApplications`: List of applications the supervisor has attended.
- `ArrayList<Application> supervisedApplications`: List of applications the supervisor has supervised.

### Methods:
- `ApplicationSupervisor(String name, String focusArea)`: Constructor to initialize supervisor attributes.
- void `attendToApplication(Application application)`: Attends an application, adding it to `attendedApplications`.
- void `superviseDevelopment(Application application)`: Supervises the development of an application, adding it to `supervisedApplications`.

## SmartCityCenter Class 

### Instance Variables:
- `ArrayList<Application> applications`: List of applications being developed in the AI Center.
- `ArrayList<ProjectManager> managers`: List of project managers employed in the AI Center.
- `ArrayList<ApplicationSupervisor> supervisors`: List of supervisors associated with the AI Center.

### Methods:
- `void addApplication(Application application)`: Adds an application to the AICenter.
- void `addManager(ProjectManager manager)`: Adds a project manager to the AICenter.
- void `addSupervisor(ApplicationSupervisor supervisor)`: Adds a supervisor to the AICenter.
- void `assignManagerToApplication(ProjectManager manager, Application application)`: Assigns a manager to an application using the `assignApplication()` method from the `ProjectManager` class.
- void `displaySupervisedApplications()`: Displays all applications supervised by the application supervisors.
- void `displayAttendedApplications()`: Displays all applications attended by the application supervisors.

## main package
## MainSmartCity class

The provided `MainSmartCity` class is for testing your implemented Java application. This class is a driver class to demonstrate and test the functionalities of your Smart City Innovation Center Coordination System application. You are not allowed to change the given file. **You are only allowed to add the pledge of honor to it**. Any other changes may lead to a grade reduction.

# Sample output
```
Application Name: Object Detection
  Domain: Traffic Monitoring
  Complexity Level: 8
  Status: In Development
  Model Type: CNN
  Uses Pretrained Models: Yes

Application Name: Trauma Detection
  Domain: Medical Emergency AI
  Complexity Level: 9
  Status: In Development
  Imaging Type: MRI
  Anomaly Detection: Yes

Application Name: Load Balancing
  Domain: Energy Optimization
  Complexity Level: 7
  Status: In Development
  Optimization Technique: Genetic Algorithms
  Distributed Processing: Yes

-------------------Assign applications to managers: 
Object Detection has been assigned to Dr. One.
Detector cannot be assigned to Dr. One as it does not match the department.
Load Balancing has been assigned to Dr. Two.

AI Center Tasks:
---------------
Dr. One is organizing the development cycle for Object Detection.
Dr. Two is organizing the development cycle for Load Balancing.
Dr. One is monitoring the status of Object Detection.
Dr. Two is monitoring the status of Load Balancing.
Ms. White is attending to Object Detection in the focus area: Model Deployment.
Ms. White is attending to Detector in the focus area: Model Deployment.
Mr. Walter is attending to Live Streaming in the focus area: Data Integration.
Ms. White is supervising the development of Trauma Detection.
Mr. Walter is supervising the development of Load Balancing.

---- Attended Applications ----
Ms. White attended Object Detection.
Ms. White attended Detector.
Mr. Walter attended Live Streaming.

---- Supervised Applications ----
Ms. White supervised Trauma Detection.
Mr. Walter supervised Load Balancing.
```



