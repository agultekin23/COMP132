package gamePlaces;

import characters.Characters; 

public class Location {
    private Characters characters; 
    private Food food;
    private boolean obstacle;
    /*
     * It checks the grid  whether it is full or empty.It returns the true or false value.
     */
    public boolean totallyEmpty() {
        boolean value = (characters == null && food == null && !obstacle);
        return value;
    }
    /*
     * getter-setters
     */

	public Characters getCharacters() {
		return characters;
	}

	public void setCharacter(Characters character) {
		this.characters = character;
	}

	public Food getFood() {
		return food;
	}

	public void setFood(Food food) {
		this.food = food;
	}

	public boolean isObstacle() {
		return obstacle;
	}

	public void setObstacle(boolean obstacle) {
		this.obstacle = obstacle;
	}


}