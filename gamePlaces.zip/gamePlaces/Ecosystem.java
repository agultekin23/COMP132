package gamePlaces;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import characters.Characters;
import view.GridCell;

public class Ecosystem {
    private int gridSize;
    private GridCell[][] grid;
    private SecureRandom secureRandom = new SecureRandom();
/*
 * ıt is the constructor of ecosystem. In that constructor we creates GridCell(i,j)
 */
    public Ecosystem(int gridSize) {
        this.gridSize = gridSize;
        this.grid = new GridCell[gridSize][gridSize];

        for (int i = 0; i < gridSize; i++) {
            for (int j = 0; j < gridSize; j++) {
                grid[i][j] = new GridCell(i, j);
            }
        }
    }
/*
 * It generates obstacle as we can understand from its name. We enter a number how many do we want to create obstacles. that process is completely happened random.
 */
    public void generateObstacles(int obstacleCount) {
        int placed = 0;
        while (placed < obstacleCount) {
            int x = secureRandom.nextInt(gridSize);
            int y = secureRandom.nextInt(gridSize);
            if (grid[x][y].totallyEmpty() && !grid[x][y].isObstacle()) {
                grid[x][y].setObstacle(true);
                placed++;
            }
        }
    }
    /*
     * It places characters according to grid's availability. by taking parameters chracter object x and y coordinates. 
     */

    public boolean placeCharacter(Characters character, int x, int y) {
        if (x < 0 || x >= gridSize || y < 0 || y >= gridSize) {
        	return false;
        }
        if (grid[x][y].isObstacle()) {
        	return false;
        }
        
        grid[x][y].setCharacter(character);
        return true;
    }
/*
 * It places the foods. by taking the parameters food object, x and y. 
 */
    public void placeFood(Food food, int x, int y) {
        if (x >= 0 && x < gridSize && y >= 0 && y < gridSize) {
            grid[x][y].setFood(food);
        }
    }
/*
 * It respawns the character when they are eaten. they are completely random generated again in grid. They can respawn in grid if there is no obstacle and there is no character. 
 * It first collects available points after that by instanceof operator It places them. It doesnt return anything since it is void.
 */
    public void respawn(Object character) {
        List<int[]> available = new ArrayList<>();
        for (int i = 0; i < gridSize; i++) {
            for (int j = 0; j < gridSize; j++) {
                if (!grid[i][j].isObstacle() && grid[i][j].totallyEmpty()) {
                    available.add(new int[]{i, j});
                }
            }
        }

        if (!available.isEmpty()) {
        	
            int[] cell = available.get(secureRandom.nextInt(available.size()));
            int nx = cell[0];
            int ny = cell[1];

            if (character instanceof Characters) {
            	
                Characters c = (Characters) character;
                c.setLocationX(nx);
                c.setLocationY(ny);
                placeCharacter(c, nx, ny);
                
            } else if (character instanceof Food) {
                Food f = (Food) character;
                f.setX(nx);
                f.setY(ny);
                placeFood(f, nx, ny);
            }
        }
    }
    /*
     * It completely clears the characters in the grid. We use that method if characters are eaten.
     */
    public void clearCharacters() {
        for (int i = 0; i < gridSize; i++) {
            for (int j = 0; j < gridSize; j++) {
                grid[i][j].setCharacter(null);
            }
        }
    }
/*
 * It completely clears the food in the grid. We use that method if food is eaten.
 */
    public void clearFood() {
        for (int i = 0; i < gridSize; i++) {
            for (int j = 0; j < gridSize; j++) {
                grid[i][j].setFood(null);
            }
        }
    }
    /*
     * getter and setters.
     */

    public GridCell[][] getGrid() { 
    	return grid; 
    	}
    public int getGridSize() { 
    	return gridSize; 
    	}
}