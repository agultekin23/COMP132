package gamePlaces;

public class Food {

    private int x, y;
    private String name;
    /*
     * it is the constructor of class with parameters name, x and y. 
     */
    public Food(String name, int x, int y) {
        this.x = x;
        this.y = y;
        this.name = name;
    }
    /*
     * getter and setters.
     */
    
	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


    
    
}