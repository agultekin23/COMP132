package modesAndEcosystems;

import computer.AIManager;
import fileIo.FileHandler;
import gamePlaces.*;

import java.io.*;
import java.security.SecureRandom;
import java.util.*;
import characters.*;

public class GameManager {
    private List<Prey> preys = new ArrayList<>();
    private List<Predator> predators = new ArrayList<>();
    private List<ApexPredator> apexUnits = new ArrayList<>();
    private List<Food> foods = new ArrayList<>();
    private FileHandler gh;
    private int currentRound = 1;
    private int totalRounds;
    private String era;
    private Ecosystem ecosystem;
    private SecureRandom secureRandom = new SecureRandom();
    private boolean gameOverProcessed = false;
    
    /*
     * It is the constructor of GameManager class. It sets the parameters and initializes currentRound to 1. It loads data to continue where it stayed.
     */
    public GameManager(String era, int gridSize, int totalRounds, Ecosystem ecosystem) {
        this.era = era; 
        this.totalRounds = totalRounds;
        this.ecosystem = ecosystem;
        this.gh = new FileHandler();
        this.gh.era = era;
        this.gh.totalRounds = totalRounds;
        this.ecosystem.generateObstacles(5);
        this.currentRound = 1;
        loadData(); 
    }
    /*
     * It doesnt take parameter. it's function is start the round and trigger to Computer to move. By for loop it updates the locations of characters and in the last
     * It checkcollisions, update cooldowns and refrest the GUI to replace the new characters. It also checks thw game is over or not and announce the winner. 
     * It doesnt return since it is void
     */
    public void runRound() {
        if (isGameOver() || gameOverProcessed) {
            return;
        }

        gh.round = currentRound;
        gh.recordLog("INFO", "=== Round " + currentRound + " Started ===");

        for (ApexPredator apex : apexUnits) {
            int oldX = apex.getLocationX();
            int oldY = apex.getLocationY();
            int oldCD = apex.getCooldown();

            AIManager.handleApexTurn(apex, preys, predators, era, ecosystem);
            
            int dist = Math.max(Math.abs(apex.getLocationX() - oldX), Math.abs(apex.getLocationY() - oldY));
            if (dist > 1) {
                if (oldCD == 0) {
                    apex.setCooldown(EraSettings.getAbilityCooldown("Apex", era) + 1);
                } else {
                    apex.setLocationX(oldX);
                    apex.setLocationY(oldY);
                }
            }
        }

        for (Prey prey : preys) {
            int oldX = prey.getLocationX();
            int oldY = prey.getLocationY();
            int oldCD = prey.getCooldown();

            AIManager.handlePreyTurn(prey, predators, apexUnits, foods, era, ecosystem);
            
            int dist = Math.max(Math.abs(prey.getLocationX() - oldX), Math.abs(prey.getLocationY() - oldY));
            if (dist > 1) {
                if (oldCD == 0) {
                    prey.setCooldown(EraSettings.getAbilityCooldown("Prey", era) + 1);
                } else {
                    prey.setLocationX(oldX);
                    prey.setLocationY(oldY);
                }
            }
        }

        checkCollisions();
        updateAllCooldowns();
        refreshBoard();

        if (currentRound >= totalRounds) {
            gameOverProcessed = true;
            gh.logGameOver(getWinner());
        }
        currentRound++;
    }	
    
    /*
     * this method manages the predators' movement. It first calculates distance and by cooldown values it sets the cooldown. 
     * after that it checks apex ate the predator or not. to continue without error it returns true all the time
     */
    
    public boolean movePlayer(int targetX, int targetY) {
        if (isGameOver() || predators.isEmpty() || gameOverProcessed) {
            return false;
        }
        if (ecosystem.getGrid()[targetX][targetY].isObstacle()) {
            return false;
        }

        Predator player = predators.get(0);
        int dx = Math.abs(player.getLocationX() - targetX);
        int dy = Math.abs(player.getLocationY() - targetY);
        int dist = Math.max(dx, dy);
        
        if (dist == 0) {
            runRound();
            return true;
        }

        if (!isMoveLegal(player, dx, dy, dist)) {
            return false;
        }

        if (dist > 1) {
            int cdValue = EraSettings.getAbilityCooldown("Predator", era); 
            player.setCooldown(cdValue + 1); 
        }

        player.setLocationX(targetX);
        player.setLocationY(targetY);
        
        handlePlayerCollisions(player);
        runRound(); 
        return true;
    }
    /*
     * it updates cooldowns by updateCooldown method. We call just that method when we want to update all cooldowns. there is no return.
     */
    private void updateAllCooldowns() {
        for (Predator p : predators) {
        	p.updateCooldown();
        }
        for (ApexPredator a : apexUnits) {
        	a.updateCooldown();
        }
        for (Prey pr : preys) {
        	pr.updateCooldown();
        }}
    
/*
 * It checks the the move is appliable or not according to rules that indicated in pdf file. It takes parameters as distnce d,y and charactetr p and distance.
 * If movement does not obey any of the rule. returns false. 
 */
    
    private boolean isMoveLegal(Characters p, int dx, int dy, int dist) {
        if (dist == 1) {
        	return true;
        }

        if (p.getCooldown() > 0) {
        	return false;
}
        
        if (p instanceof Predator && era.equalsIgnoreCase("Present")) {
            return dist == 2 && isNearApex(p);
        		}

        if (p instanceof Predator) {
            if (era.equalsIgnoreCase("Past")) {
                return (dx == 2 && dy == 0) || (dx == 0 && dy == 2);
} 
            
            	else if (era.equalsIgnoreCase("Present")) {
                return dist == 2 && isNearApex(p);   
            } 
            else if (era.equalsIgnoreCase("Future")) {
            return dist == 2 && (dx == dy || dx == 0 || dy == 0);
            }
        }
        
        else if (p instanceof Prey) {
            if (era.equalsIgnoreCase("Past")) {
            	boolean d = (dx == 2 && dy == 1) || (dx == 1 && dy == 2); 
            	return d;
            }
            
            if (era.equalsIgnoreCase("Present")) {
            	return dist == 2; 
            }
            
            if (era.equalsIgnoreCase("Future")) {
            	return dist == 3; 
            }
        }
        
        return false;
    }
    
    
/*
 * It checks the collisions between characters and foods by itereating the lists. If there is a collision it recordsLog. 
 */
    public void checkCollisions() {
        this.gh.era = this.era;
        this.gh.round = this.getRound();
        this.gh.totalRounds = this.getTotalRounds();

        for (ApexPredator apex : apexUnits) {
            for (Predator predator : predators) {
                if (apex.getLocationX() == predator.getLocationX() && apex.getLocationY() == predator.getLocationY()) {
                    apex.setScore(apex.getScore() + 1); 
                    predator.setScore(predator.getScore() - 1); 
                    ecosystem.respawn(predator);
                    this.gh.recordLog("COLLISION", "Apex Predator ate Predator.");
                }
            }
            for (Prey prey : preys) {
                if (apex.getLocationX() == prey.getLocationX() && apex.getLocationY() == prey.getLocationY()) {
                    apex.setScore(apex.getScore() + 1); 
                    prey.setScore(prey.getScore() - 1); 
                    ecosystem.respawn(prey);
                    this.gh.recordLog("COLLISION", "Apex Predator ate Prey.");
                }}
        }
        for (Predator pred : predators) {
            for (Prey prey : preys) {
                if (pred.getLocationX() == prey.getLocationX() && pred.getLocationY() == prey.getLocationY()) {
                    pred.setScore(pred.getScore() + 3); 
                    prey.setScore(prey.getScore() - 1);
                    ecosystem.respawn(prey);
                    this.gh.recordLog("COLLISION", "Predator ate Prey.");
                }}
        }
        for (Prey prey : preys) {
            for (Food food : foods) {
                if (prey.getLocationX() == food.getX() && prey.getLocationY() == food.getY()) {
                    prey.setScore(prey.getScore() + 3); 
                    ecosystem.respawn(food);
                    this.gh.recordLog("COLLISION", "Prey ate Food.");
                    }}}
    }
    /*
     * It only checks the predator eat prey or not. If it ate the prey it respawns and recors to log.txt file. 
     */
    private void handlePlayerCollisions(Predator player) {
        for (Prey prey : preys) {
        	
            if (player.getLocationX() == prey.getLocationX() && player.getLocationY() == prey.getLocationY()) {
                player.setScore(player.getScore() + 3); 
                prey.setScore(prey.getScore() - 1);
                ecosystem.respawn(prey);
                gh.recordLog("COLLISION", "Predator ate Prey. New Score: " + player.getScore());
            }}
    }
/*
 * Firstly clear ecosystem by clear characters and foods. After that by for loops apex places to ecosystem and if it is not in ecosystem, respawn it.
 */
    public void refreshBoard() {
        ecosystem.clearCharacters();
        ecosystem.clearFood();
        
        for(ApexPredator apex : apexUnits) {
            boolean ap = ecosystem.placeCharacter(apex, apex.getLocationX(), apex.getLocationY());
            if(!ap) {
                ecosystem.respawn(apex);
                }}
        for(Predator predator : predators) {
            boolean pred = ecosystem.placeCharacter(predator, predator.getLocationX(), predator.getLocationY());
            if(!pred) {
                ecosystem.respawn(pred);
            }
        }
        for(Prey prey : preys) {
            boolean pr = ecosystem.placeCharacter(prey, prey.getLocationX(), prey.getLocationY());
            if(!pr) {
                ecosystem.respawn(prey);
            }
        }
        for(Food f : foods) {
            ecosystem.placeFood(f, f.getX(), f.getY());
        }
    }
    /*
     * Firstly it clears list of characters and foods. after that it assigns a string value to fileName. after that it prints to log.txt file. 
     * After that it checks the list is empty or not. it adds the names of characters to names and separates after all of them is collected. 
     * in the end if it does not get to try block it moves to catch blok and exception. 
     */

    private void loadData() {
        this.apexUnits.clear(); 
        this.predators.clear(); 
        this.preys.clear(); 
        this.foods.clear();
        
        String fileName = this.era.toLowerCase() + "_animals.txt";
        
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            List<String> list = new ArrayList<>();
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains("Food Chain")) {
                    list.add(line);
                }
            }
            if (!list.isEmpty()) {
                String[] names = list.get(secureRandom.nextInt(list.size())).split(":")[1].split(",");
                apexUnits.add(new ApexPredator(names[0].trim(), 0, 0));
                predators.add(new Predator(names[1].trim(), 0, 0));
                preys.add(new Prey(names[2].trim(), 0, 0));
                foods.add(new Food(names[3].trim(), 0, 0));
               
                for (Prey p : preys) {
                	ecosystem.respawn(p);
                }
                
                for (Predator p : predators) {
                	ecosystem.respawn(p);
                }
                
                for (ApexPredator a : apexUnits) {
                	ecosystem.respawn(a);
                }
                
                for (Food f : foods) {
                	ecosystem.respawn(f);
                }
            }
        } catch (Exception e) { 
            e.printStackTrace(); 
        }
    }
    
    /* 
     * that method is constructed for fileHandler class. It allows the players to continue with their previous score and location
     */
    
    public void savedData(FileHandler fh) {
        this.currentRound = fh.round;
        this.totalRounds = fh.totalRounds;
        
        if (!predators.isEmpty()) {
            Predator predator = predators.get(0);
            predator.setScore(fh.scorePredator);
            predator.setLocationX(fh.xPredator);
            predator.setLocationY(fh.yPredator);
        }
        
        if (!preys.isEmpty()) {
            Prey prey = preys.get(0);
            prey.setScore(fh.scorePrey);
            prey.setLocationX(fh.xPrey);
            prey.setLocationY(fh.yPrey);
        }
        
        if (!apexUnits.isEmpty()) {
            ApexPredator apex = apexUnits.get(0);
            apex.setScore(fh.scoreApex);
            apex.setLocationX(fh.xApex);
            apex.setLocationY(fh.yApex);
        }

        refreshBoard(); 
    }
    /*
     * First we take the scores by instance variables. after that we check who has the greatest score. return winners name.
     */

    public String getWinner() {
        
        int apexScore = apexUnits.get(0).getScore();
        int predatorScore = predators.get(0).getScore();
        int preyScore = preys.get(0).getScore();
        
        if (apexScore >= predatorScore && apexScore >= preyScore) {
            String sApex = apexUnits.get(0).getCharactersName() + " (Apex)";
            return sApex;
        }
        if (predatorScore >= apexScore && predatorScore >= preyScore) {
            String sPredator = predators.get(0).getCharactersName() + " (Predator)";
            return sPredator;
        }
        String sPrey = preys.get(0).getCharactersName() + " (Prey)";
        return sPrey;
    }
    /*
     * It checks the Apex is adjacent for present era dash ability. It returns boolean whether it is adjacent or not. 
     */
    private boolean isNearApex(Characters p) {
        if (apexUnits.isEmpty()) {
            return false; 
        }
        ApexPredator a = apexUnits.get(0);
        boolean ap = Math.max(Math.abs(a.getLocationX() - p.getLocationX()), Math.abs(a.getLocationY() - p.getLocationY())) <= 1;
        return ap;
    }
    
    /*
     * getter and setters methods
     */
    
    public boolean isGameOver() { 
        return currentRound > totalRounds; 
    }
    
    public int getRound() { 
        return Math.min(currentRound, totalRounds); 
    }

    public int getTotalRounds() { 
    	return totalRounds; 
    }
    
    public void setTotalRounds(int totalRounds) { 
    	this.totalRounds = totalRounds; 
    }
    
    public List<Prey> getPreys() { 
    	return preys; 
    }
    
    public List<Predator> getPredators() { 
    	return predators; 
    }
    
    public List<ApexPredator> getApexUnits() { 
    	return apexUnits; 
    }
    
    public List<Food> getFoods() { 
    	return foods; 
    }
    
    public FileHandler getGh() { 
    	return gh; 
    }
    
    public String getEra() { 
    	return era; 
    }
    
    public Ecosystem getEcosystem() { 
    	return ecosystem; 
   	}
    
    public int getCurrentRound() { 
    	return currentRound; 
    }
    
    public void setCurrentRound(int currentRound) { 
    	this.currentRound = currentRound; 
    }
    
}