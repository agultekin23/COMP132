package modesAndEcosystems;
import java.security.SecureRandom;
import java.util.List;

import fileIo.FileHandler;

public class Era {
    
	private static final SecureRandom secureRandom = new SecureRandom();
    private static final FileHandler handler = new FileHandler();
    
    /*
     * It picks chracter name according to era. file object from fileHandler it can scans and find names. Lastly we pick name randomly by secureRandom object. and it returns name.
     */
    public static String pickCharacterName(String era) {
        
    	List<String> names = handler.getCharacterNames(era);
        
        
        String name = names.get(secureRandom.nextInt(names.size()));
        return name;
    }
    public static String pickFoodName(String era) {
    	/*
    	 * It compeletely random picks the food's name if it equals to 1. foodchain or 2. foodchain. 
    	 * It returns food names.
    	 */
        
    	if (era.equals("Past")) {
            String x = secureRandom.nextBoolean() ? "Ferns" : "Cycads";
            return x;
            
        } else if (era.equals("Present")) {
            String y = secureRandom.nextBoolean() ? "Grass" : "Shrubs";
            return y;
            
        } else {
            String z = secureRandom.nextBoolean() ? "Cow" : "Energy Node";
        	return z;
        }
    }
    
    /*
     * getters
     */
	public static SecureRandom getSecurerandom() {
		return secureRandom;
	}
	public static FileHandler getHandler() {
		return handler;
	}
    
    
}