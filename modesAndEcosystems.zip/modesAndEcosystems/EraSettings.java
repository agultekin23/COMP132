package modesAndEcosystems;

public class EraSettings {
/* It takes characterType as string and era.
 * that method is relevant with ability cooldowns of characters. It firstly chooses the era after that it returns cooldown's according to character's type.
 */
	public static int getAbilityCooldown(String characterType, String era) {
        
		if (era.equalsIgnoreCase("Past")) {
        	return 2; 
        }
        
        if (era.equalsIgnoreCase("Present")) {
            
        	if (characterType.equals("Apex")) {
            	return 3;
            }
            if (characterType.equals("Predator")) {
            	return 0;
            }
            if (characterType.equals("Prey")) {
            	return 3;
            }
        }
        
        if (era.equalsIgnoreCase("Future")) {
            
        	if (characterType.equals("Apex")) {
            	return 3;
            }
            if (characterType.equals("Predator")) {
            	return 2;
            }
            if (characterType.equals("Prey")) {
            	return 2;
            }
        }
        return 2;
    }
	/*
	 * In that method It decides the range of abilities. In oast they are all 2. present apex 3 others 2. future they are all 2. It returns the ranges. 
	 */

	public static int getAbilityDistance(String animalType, String era) {
	    if (era.equalsIgnoreCase("Past")) {
	        return 2;
	    }
	    if (era.equalsIgnoreCase("Present")) {
	        return (animalType.equals("Apex")) ? 3 : 2; 
	    }
	    if (era.equalsIgnoreCase("Future")) {
	        if (animalType.equals("Predator")) {
	        	return 2; 
	        }
	        return 3; 
	    }
	    return 2;
	}
}