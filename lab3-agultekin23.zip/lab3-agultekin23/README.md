[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/nHiWYFiO)
# COMP132, Fall2025, Lab 3 PreLab

# IMPORTANT

For each lab assignment, **you must include and sign (by writing your name and student ID number) the following Pledge of Honor statement at the beginning of your main method source code file. After including this statement, make sure that you do the commit and push operation on GitHub. Otherwise, your lab solution will not be graded.**
```
/* *********** Pledge of Honor ************************************************ *

I hereby certify that I have completed this lab assignment on my own
without any help from anyone else. I understand that the only sources of authorized
information in this lab assignment are (1) the course textbook, (2) the
materials posted on the course website, and (3) any study notes handwritten by myself.
I have not used, accessed, or received any information from any other unauthorized
source in taking this lab assignment. The effort in the assignment thus belongs
completely to me.
READ AND SIGN BY WRITING YOUR NAME SURNAME, AND STUDENT ID
SIGNATURE: <Name Surname, Student id>
********************************************************************************/
```
## Please carefully review the following important notes. Violating each one of them will result in a grade deduction.

## IMPORTANT NOTES: 

   ##### :pushpin: - All instance variables MUST have the exact name written in the instructions.
   ##### :pushpin: - You should implement getter/setter methods whenever needed (for example, if you are going to access the instance variables from other classes). You may use auto-generator for getter/setter methods (under the Source menu in Eclipse). Do NOT implement unused Getter/Setter methods. You will be penalized for each unused Getter/Setter.
   ##### :pushpin: -  You MUST follow the instructions (Package name, Class name, method name, variables, ...) so carefully. The packages, classes, instance variables, and methods MUST be created following the descriptions given in the assignment.
   ##### :pushpin: -  Please check the sample output provided at the end of this assignment. Your output MUST be exactly the same as the provided sample output.
   ##### :pushpin: -  After you complete the tasks, do not forget to commit your changes and push them to your repository on GitHub BEFORE 9.30 :clock930: AM, Friday.
   ##### :pushpin: -  This README.md file only contains the instructions for PRELAB. You will also have INLAB questions.

  # EcoFarm Plot Manager

In this pre-lab, you’ll build a small Java application to monitor and adjust crop health/production across an eco-farm divided into rectangular plots. Each farm keeps plot data in grid-shaped beds represented as 2D arrays of integers.
This assignment will help you practice working with **multidimensional arrays**, which have numerous real-world applications, including scientific computing, simulations, and robotics.
    

<div align="center">
  <img src="/img/03.png" alt="Programming Languages" />
</div>


    
## Packages and Classes
Your Java project should be structured into three packages:
   - farm (contains FarmUtils and PlotGrid classes)
   - logistics (contains ShipmentPlan class)
   - app (contains FarmMain driver class, provided for testing)


# farm package

## FarmUtils Class
Contains utility helpers for working with 2D plot grids. This class provides static utility methods for common operations on farm grids.

### Methods:
- `public static int[][] cloneGrid(int[][] grid)`: Returns a deep copy of the grid (new outer and inner arrays). This ensures that modifying the copy will not alter the original grid, which is essential for maintaining data integrity during operations that generate new results.

- `public static boolean sameDimensions(int[][] farm1, int[][] farm2)`: Returns true if both farm1 and farm2 are non-null and have the same row count and the same column count. Checks whether two grids have identical dimensions; otherwise, returns false. This method is crucial for validating compatibility before performing merge or subtraction operations.

## PlotGrid Class
Represents an eco-farm’s plots and operations on them.
### Instance Variables:
- `String farmName`: representing the name of the farm (e.g., “Olive Grove” or “Sunny Acres”).
- `int[][] plots`: A fixed-size 2D array of integers (int[][]) representing the crop yield or health values stored across the farm’s plots. Each row and column corresponds to physical sections of the farm, reflecting the actual layout of the land and making it easy to visualize how resources or productivity are distributed spatially.


### Constructors:
- `public PlotGrid(String farmName, int[][] plots)`: Initializes a PlotGrid object with the given farm name and an existing 2D integer array representing the farm’s plot data. Each element of the array corresponds to a single plot’s crop yield or condition value. This constructor is used when both the farm name and the plot data are already known.
- `public PlotGrid(String farmName)`: Initializes a PlotGrid object with the given farm name and creates a new 3×3 grid of plots, where all values are initially zero. This simulates a newly established farm with no recorded yields yet. The constructor internally calls the two-parameter constructor to ensure consistent initialization.
- `public PlotGrid()`: Initializes a PlotGrid object with the default name "Unnamed Farm" and a new 3×3 empty plot grid (all zeros). This constructor is typically used when no specific name or data is provided. It internally calls the single-parameter constructor for consistency in initialization.

#### Important Implementation Notes:
- Whenever an operation generates a new plot grid, you must use the 'cloneGrid()' method from the 'FarmUtils' class to create a deep copy. This ensures that any modifications made to the new grid do not affect the original farm’s data.
- Grid-based operations, such as merge and aid allocation, can only be performed when both farms have grids of the same dimensions (i.e., the same number of rows and columns). Before performing these operations, you must check compatibility using the 'sameDimensions()' method from the 'FarmUtils' class. If the dimensions do not match, the operation should be skipped, and an appropriate warning message should be displayed.

### Methods: 
- `public void mergeFrom(PlotGrid other)`: This method merges two farms’ plot data by performing element-wise addition between the current farm’s grid and another farm’s grid. This simulates combining harvest results or shared resources between neighboring farms.
 
   - If the grids do not share the same dimensions, the method displays: "Merge failed between farmName and otherFarmName: plot sizes do not match."
   - Otherwise, the method displays the resulting merged grid using the 'toString()' method. Both original grids remain unchanged.

- `public void allocateAid(PlotGrid request)`: Subtracts another farm’s grid values from the current farm’s grid to simulate sending aid or resources to fulfill requests. After subtraction, any negative value is replaced with zero to prevent negative resource counts.
   - If the grids differ in size, the method displays:
     Aid allocation failed due to incompatible plot sizes.

   - Otherwise, the resulting grid is displayed using 'toString()', while both original grids stay unmodified.

- `public void scaleAll(int factor)`: Multiplies every value in the plot grid by the given factor, simulating seasonal yield growth or scaling up production levels. The method then displays the scaled grid using the 'toString()' method. The original grid remains unchanged.
- `public void rotateClockwise()`: Performs a 90-degree clockwise rotation of the plot grid in place. This method redistributes plots by reorienting rows and columns, useful for analyzing the farm from different layout perspectives. After rotation, the method displays the updated grid using the 'toString()' method.

- `public void checkFarmParity()`: Verifies whether the total yield of each row/column in the grid is the same.
   - If all rows have identical total values, the farm is considered row-balanced, and the method displays: "Farm farmName is row-balanced." Otherwise, it displays: "Farm farmName is not row-balanced."
   - Similarly, for the column, if all columns have identical total values, the farm is considered column-balanced, and the method displays: "Farm farmName is column-balanced." Otherwise, it displays: "Farm farmName is not column-balanced."
   - Finally, 
      - If the Farm is both row-balanced and column-balanced, the method should also display: "Farm farmName is Totally-balanced."
      - If the farm is Totally-balanced and the row sum value equals the column sum value, the method displays: "Farm farmName is Super-Balanced." This indicates perfect harmony between row and column distributions, meaning the total yield per row equals the total yield per column.
      - If the Farm is not balanced in both row and column, the method should display: "Farm farmName is NOT balanced at all."
      - If the farm is either balanced in row or column, the method should display: "Farm farmName is ONLY row-balanced (column-balanced).”

- `public void checkAllZero()`: Checks whether the farm’s grid is completely empty, meaning all values are zero.
   - If the grid is empty, the method displays: "All plots at Farm farmName are empty."
   - Otherwise, it displays: "Farm farmName has active plots."

- `public void checkMajorityValue(int value)`: Determines if the given value (representing a specific crop or soil condition) appears in at least half of all the grid cells.
   - If the condition holds (value appears in at least half of all cells), the method displays: "Farm farmName has a majority of value."
   - Otherwise, it displays: "Farm farmName does not have a majority of value."
- `public String toString()`:  Provides a string representation of the Farm’s grid.

# logistics package

## ShipmentPlan Class
Represents a shipment routing matrix applied to a farm’s plots to compute outbound batches. This is classic matrix multiplication.
### Instance Variables:
- `int[][] plan`: representing the shipment routing or load distribution plan. Each row corresponds to an origin plot, and each column represents a delivery route or storage bin, enabling the modeling of how harvested crops are transported from specific plots to their designated shipment destinations.

### Constructor: 
- `public ShipmentPlan(int[][] plan)`: Initializes a ShipmentPlan object with a given 2D integer matrix representing the routing or shipment configuration. Each element defines the quantity or weight transferred from one plot (row) to a delivery route or destination (column). This matrix is later used for compatibility checks and matrix multiplication with a PlotGrid.

### Methods:
- `public boolean isCompatible(PlotGrid grid)`: Checks whether the shipment plan matrix can be multiplied by the given farm’s plot grid. Returns true if the number of columns in the farm’s grid equals the number of rows in the plan matrix, satisfying the standard rule of matrix multiplication compatibility. Otherwise, it returns false.
##### Note: Grid multiplication between two grids, A and B, is only possible if the number of columns in A matches the number of rows in B. Specifically, if A has dimensions m x n and B has dimensions p x q, then n must be equal to p for the multiplication to be valid. If these dimensions do not align, it is not possible to perform multiplication.

- `public PlotGrid apply(PlotGrid grid)`: Applies the shipment plan to the given farm by performing matrix multiplication between the farm’s plot grid and the shipment plan. This operation simulates the packaging and distribution of harvested crops along various routes or storage units. If the dimensions are incompatible, the method prints: "Cannot apply shipment plan: dimension mismatch.", and returns the original PlotGrid unchanged. Otherwise, it computes the product and returns a new PlotGrid containing the resulting shipment configuration, with the same name as the given grid.

# app package

## FarmMain class
The provided FarmMain class is for testing your implemented Java application. This class serves as a driver to demonstrate and test the functionalities of your implementation. You are not permitted to modify the provided file. You are only allowed to add the pledge of honor to it. Any other changes may lead to a grade reduction.

**Important Note 1**: You are not allowed to change the given main file, unless specified. You just need to add the pledge of honor to it. Any changes beyond that may lead to a grade reduction.

**Important Note 2**: As long as your output includes all the words from the sample output, it is sufficient for us, since the autograder does not consider spaces. However, you need to be careful to match the exact text as given in the sample output. For example:

<table>
  <tr>
    <th>Sample</th>
    <th>Accepted by autograder</th>
    <th>Rejected by autograder</th>
  </tr>
  <tr>
    <td><pre>Today is rainy.
       
Do not forget your umbrella.</pre></td>
    <td><pre>Today is rainy.
       
Do not forget your umbrella.</pre></td>
    <td><pre>Today’**s** rainy.
   
Do**n’t** forget your umbrella.</pre></td>
  </tr>
</table>


### Sample Output
```
--- Initial Farms ---

  Farm A ---

[ 2 0 4 ]
[ 3 1 2 ]
[ 1 2 3 ]


  Farm B ---

[ 1 1 2 ]
[ 0 3 3 ]
[ 2 1 1 ]



--- After merge at Olive Grove ---

[ 3 1 6 ]
[ 3 4 5 ]
[ 3 3 4 ]



--- Original Olive Grove plots were ---

[ 2 0 4 ]
[ 3 1 2 ]
[ 1 2 3 ]

--- After aid allocation at Olive Grove ---

[ 1 0 2 ]
[ 3 0 0 ]
[ 0 1 2 ]


Aid allocation failed due to incompatible plot sizes.

--- Original Olive Grove plots were ---

[ 2 0 4 ]
[ 3 1 2 ]
[ 1 2 3 ]

Scaled plots for Olive Grove:
[ 4 0 8 ]
[ 6 2 4 ]
[ 2 4 6 ]


Rotated plots for Olive Grove (clockwise):
[ 1 3 2 ]
[ 2 1 0 ]
[ 3 2 4 ]


Merge failed between Olive Grove and Coastal Annex: plot sizes do not match.



--------------Parity checks----------- 

Farm Olive Grove is not row-balanced.
Farm Olive Grove is column-balanced.
Farm Olive Grove is ONLY column-balanced.


Farm Riverbank is not row-balanced.
Farm Riverbank is not column-balanced.
Farm Riverbank is NOT balanced at all.


Farm Green Land is row-balanced.
Farm Green Land is column-balanced.
Farm Green Land is Totally-balanced.
Farm Green Land is Super-Balanced.


Farm Green Valley is row-balanced.
Farm Green Valley is column-balanced.
Farm Green Valley is Totally-balanced.
Farm Green Valley is NOT Super-Balanced.


All plots at Farm Unnamed Farm are empty.


Farm Green Land has active plots.


Farm Olive Grove does not have a majority of 5.



--- Applying shipment plan to Olive Grove ---

[ 25 16 21 ]
[ 9 6 10 ]
[ 32 26 29 ]



--- Applying shipment plan to Riverbank ---

[ 20 16 ]
[ 33 15 ]
[ 19 23 ]



--- Applying shipment plan to Coastal Annex ---

Cannot apply shipment plan: dimension mismatch.
[ 3 1 ]
[ 2 4 ]
[ 5 2 ]
