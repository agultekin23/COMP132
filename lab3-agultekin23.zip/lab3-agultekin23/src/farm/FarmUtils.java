package farm;

public class FarmUtils {

public static int[][] cloneGrid(int[][] grid){
	int[][] copyGrid = new int[grid.length][grid[0].length];
	for(int i=0; i<grid.length; i++) {
		for(int j=0; j<grid[0].length; j++) {
			copyGrid[i][j] = grid[i][j];
		}
	}
	return copyGrid;
	
}

public static boolean sameDimensions(int[][] farm1, int[][] farm2) {
	int A = farm1.length;
	int B = farm1[0].length;
	int C = farm2.length;
	int D = farm2[0].length;
	
	boolean x = true;
	
	if(A!=C) {
		x = false;
			}
	if(B!=D) {x = false;}
	
	return x;
	
	}
	
	
	}






