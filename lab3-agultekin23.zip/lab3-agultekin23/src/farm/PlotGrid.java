package farm;

import java.util.Arrays;

public class PlotGrid {
	private String farmName;
	private int[][] plots;
	
public PlotGrid(String farmName, int[][] plots) {
	this.farmName = farmName;
	this.plots = FarmUtils.cloneGrid(plots);
	
}

public PlotGrid(String farmName) {
	this(farmName, new int [3][3]);

}
public PlotGrid() {
	this("Unnamed Farm");
}

public void mergeFrom(PlotGrid other) {
	if(!FarmUtils.sameDimensions(this.plots, other.plots)) {
		System.out.println("Merge failed between " + farmName + " and " + other.farmName + ": plot sizes do not match.");
	}else {
		int[][] copyGrid = FarmUtils.cloneGrid(this.plots);
		for(int i=0; i<copyGrid.length; i++) {
			for(int j=0; j<copyGrid[i].length; j++) {
				copyGrid[i][j]+=other.plots[i][j];
			}
		}
	PlotGrid yazdir1 = new PlotGrid(this.farmName + " (Merged Result),",copyGrid);
	System.out.println(yazdir1.toString());
	}
	
}

public void allocateAid(PlotGrid request) {
	if(!FarmUtils.sameDimensions(this.plots, request.plots)){
		System.out.println("Aid allocation failed due to incompatible plot sizes.");
	}else {
		int[][] copiedGrid = FarmUtils.cloneGrid(this.plots);
		for(int i=0; i<copiedGrid.length; i++) {
			for(int j=0; j<copiedGrid[i].length; j++) {
				copiedGrid[i][j] -= request.plots[i][j];
			}
		}
		for(int i=0; i<copiedGrid.length; i++) {
			for(int j=0; j<copiedGrid[i].length; j++) {
				if(copiedGrid[i][j]<0) {
					copiedGrid[i][j]=0;
				}
	}
		}
		
		PlotGrid yazdir2 = new PlotGrid(this.farmName + " (Aid Allocation Result)", copiedGrid);
		System.out.println(yazdir2.toString());
		
		}
	}

public void scaleAll(int factor) {
	int[][] newGrid = FarmUtils.cloneGrid(this.plots);
	for(int i=0; i<newGrid.length; i++) {
		for(int j=0; j<newGrid[i].length; j++) {
			newGrid[i][j]*=factor;

}}
	System.out.println("Scaled plots for Olive Grove:");
	String name = this.farmName;
	PlotGrid yazdir3 = new PlotGrid(name, newGrid);
	System.out.println(yazdir3.toString());
}

public void rotateClockwise() {
	int row = this.plots.length;
	int col = this.plots[0].length;
		
	int[][] rotatedPlot = new int[col][row];
	for(int i=0; i<this.plots.length; i++) {
		for(int j=0; j<this.plots[0].length; j++) {
			rotatedPlot[j][row-1-i] = this.plots[i][j];
		}
	}
	this.plots = rotatedPlot;
	System.out.println("Rotated plots for Olive Grove (clockwise): ");

	String name = this.farmName;
	PlotGrid yazdir4 = new PlotGrid(name, this.plots);
	System.out.println(yazdir4.toString());

}

public void checkFarmParity() {
	boolean x=true;
	boolean y=true;
	
	int rows = this.plots.length;
	int cols = this.plots[0].length;
	int[] totalArray = new int[this.plots.length];
	
	
	for(int i=0; i<rows; i++) {
		int total =0;
		for(int j=0; j<cols; j++) {
			total+=this.plots[i][j];	
}		totalArray[i] = total;
}		int rowSum = totalArray[0];

	for(int k = 0; k < totalArray.length; k++){
        if(rowSum!= totalArray[k]) {
            x = false;
            break; 
        }
	}

    
	if (x) {
        System.out.println("Farm " + this.farmName + " is row-balanced.");
    } else {
        System.out.println("Farm " + this.farmName + " is not row-balanced.");
    }
	int[] totalArray1 = new int[cols];

	for(int i=0; i<cols; i++) {
		int total =0;
		for(int j=0; j<rows; j++) {
			total+=this.plots[j][i];

	
}		totalArray1[i] = total;
}		int colSum = totalArray1[0];

	for(int k = 0; k < totalArray1.length; k++){
        if(colSum != totalArray1[k]) {
            y = false;
            break; 
        }
    }
    
	if (y) {
        System.out.println("Farm " + this.farmName + " is column-balanced.");
    } else {
        System.out.println("Farm " + this.farmName + " is not column-balanced.");
    }
	
	if (x && y) {
		System.out.println("Farm " + this.farmName + " is Totally-balanced.");
        
		if (rowSum == colSum) {
			System.out.println("Farm " + this.farmName + " is Super-Balanced.");
		} else {
			System.out.println("Farm " + this.farmName + " is NOT Super-Balanced.");
		}
	} else if (x==true && y==false) { 
        System.out.println("Farm " + this.farmName + " is ONLY row-balanced.");
    } else if (y==true && x==false) {
        System.out.println("Farm " + this.farmName + " is ONLY column-balanced.");
	} else {
		System.out.println("Farm " + this.farmName + " is NOT balanced at all.");
	}
}

public void checkAllZero() {
	boolean checker=true;
	int rows = this.plots.length;
	int cols = this.plots[0].length;
	for(int i=0; i<rows; i++) {
		for(int j=0; j<cols; j++) {
			if(this.plots[i][j]!=0) {
				checker=false;
				break;
			}
		}
	if(!checker) {
		break;
	}
	}
	if(!checker) {
		System.out.println("Farm "+ this.farmName + " has active plots.");
	}else {
		System.out.println("All plots at Farm " + this.farmName + " are empty.");

	}
}

public void checkMajorityValue(int value) {
	int total = 0;
	int rows = this.plots.length;
	int cols = this.plots[0].length;
	for(int i=0; i<rows; i++) {
		for(int j=0; j<cols; j++) {
		
		if(this.plots[i][j]==value) {
			total++;
		}	
		}
			}
	int dimension = rows*cols;
	if(total>=(dimension/2)) {
		System.out.println("Farm " + this.farmName + " has a majority of value.");
	}else {
		System.out.println("Farm " + this.farmName + " does not have a majority of " + value + ".");
	}
	
}

public String toString() {
    String farmGridString = "";

    int rows = this.plots.length;

    for (int i = 0; i < rows; i++) {
        farmGridString = farmGridString + "[ ";

        int cols = this.plots[i].length;
        
        for (int j = 0; j < cols; j++) {
            farmGridString = farmGridString + this.plots[i][j];

            if (j < cols - 1) {
                farmGridString = farmGridString + " ";
            }
        }
        
        farmGridString = farmGridString + " ]\n";
    }

    return farmGridString;
}

public int[][] getPlots() {
	// TODO Auto-generated method stub
	return this.plots;
}

public String getFarmName() {
	// TODO Auto-generated method stub
	return this.farmName;
}

public void analyzePlots(int threshold) {
	if(this.plots==null) {
		System.out.println("No data available to analyze,");
	}else {
	int maxNumber = this.plots[0][0];
	int minNumber = this.plots[0][0];
	int total = 0;
	double avg = 0;
	int counter = 0;
	for(int i=0; i<this.plots.length; i++ ) {
		for(int j=0; j<this.plots[0].length; j++){
			total+=this.plots[i][j];
			if(this.plots[i][j]>maxNumber) {
				maxNumber = this.plots[i][j];
			}
			if(this.plots[i][j]<minNumber) {
				minNumber = this.plots[i][j];
			}
			if(this.plots[i][j]<threshold) {
				counter++;
			}
			}	
		}	avg = total / this.plots.length;
	System.out.println("Farm " + this.plots + " Analysis:");
	System.out.println("Maximum yield " + maxNumber);
	System.out.println("Minimum yield " + minNumber);
	System.out.println("Average yield " + avg);
	System.out.println("Plots below threshold <" + threshold + ">:" + counter);

	
	
	}


}

public void fertilizeDiagonal(int fertilizerUnits) {
	int rows = this.plots.length;
	int cols = this.plots[0].length;
	if(rows!=cols) {
		System.out.println("The grid is not square. Diagonal fertilization skipped.");
	}else {
		System.out.println("The grid is square. Diagonal fertilization has been done.");
		for(int i=0; i<this.plots.length; i++ ) {
			for(int j=0; j<this.plots[0].length; j++){
				if(i==j) {
				this.plots[i][j] += fertilizerUnits;
			}
			}
	}
}
	
	System.out.println(toString());
}

public void checkUniformityAndSymmetry() {
	boolean rowUniformity = true;
	boolean colUniformity = true;
	boolean symmetry = true;
	
	int rows = this.plots.length;
	int cols = this.plots[0].length;
	
	int row0 = this.plots[0][0];
	int row1 = this.plots[1][0];
	int row2 = this.plots[2][0];
	int row3 = this.plots[3][0];
	int row4 = this.plots[4][0];
	int row5 = this.plots[5][0];

	for(int j=0; j<this.plots[0].length; j++ ) {
		if(this.plots[0][j]!=row0) {
			rowUniformity = false;
		}
		if(this.plots[1][j]!=row1) {
			rowUniformity = false;
}
		if(this.plots[2][j]!=row2) {
			rowUniformity = false;
}
		if(this.plots[3][j]!=row3) {
			rowUniformity = false;
}
		if(this.plots[4][j]!=row4) {
			rowUniformity = false;
}
		if(this.plots[5][j]!=row5) {
			rowUniformity = false;
}

		
}
	int col0 = this.plots[0][0];
	int col1 = this.plots[1][0];
	int col2 = this.plots[2][0];
	int col3 = this.plots[3][0];
	int col4 = this.plots[4][0];	
	int col5 = this.plots[5][0];

	for(int i=0; i<this.plots.length; i++ ) {
		if(this.plots[i][0]!=col0) {
			colUniformity = false;
		}
		if(this.plots[i][1]!=col1) {
			colUniformity = false;
}
		if(this.plots[i][2]!=col2) {
			colUniformity = false;
}
		if(this.plots[i][3]!=col3) {
			colUniformity = false;
}		if(this.plots[i][4]!=col4) {
	colUniformity = false;
}		if(this.plots[i][5]!=col5) {
	colUniformity = false;
}
}

	if(rows!=cols) {
		System.out.println("The grid is not square. Symmetry check skipped.");
	}
	else {
		for(int i=0; i<this.plots.length; i++ ) {
			for(int j=0; j<this.plots[0].length; j++){
				if(this.plots[i][j]!=this.plots[j][i]) {
					symmetry = false;
				}
	}
		}	
	if(symmetry==true) {
		System.out.println("Farm " + this.farmName + " is symmetric");
	}
	else {
		System.out.println("Farm " + this.farmName + " is  not symmetric");
	}
	}
	
	
}
}



