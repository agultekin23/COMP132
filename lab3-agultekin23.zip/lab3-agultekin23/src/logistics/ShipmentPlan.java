package logistics;

import java.util.ArrayList;

import farm.FarmUtils;
import farm.PlotGrid;
import farm.FarmUtils;

public class ShipmentPlan {
	private int[][] plan;

public ShipmentPlan(int[][] plan) {
	this.plan = FarmUtils.cloneGrid(plan);
}

public boolean isCompatible(PlotGrid grid) {
    int[][] farmPlots = grid.getPlots();
    int[][] shipmentPlan = this.plan;
    
    if (farmPlots == null || shipmentPlan == null) {
        return false;
    }
    
    if (farmPlots.length == 0 || shipmentPlan.length == 0) {
        return false;
    }
    
    if (farmPlots[0] == null || shipmentPlan[0] == null) {
        return false;
    }
    
    int farmCols = farmPlots[0].length;
    int planRows = shipmentPlan.length;
    
    return farmCols == planRows;
}

public PlotGrid apply(PlotGrid grid) {
	int[][] farmPlots = grid.getPlots();
	int[][] shipmentPlan = this.plan;
	
	if(!isCompatible(grid)) {
		System.out.println("Cannot apply shipment plan: dimension mismatch.");
		return grid;
		}
	int a = farmPlots.length;
	int b = farmPlots[0].length;
	int d = shipmentPlan[0].length;
	
	int[][] mulMat = new int[a][d];
	
	for(int i=0; i<a; i++) {
		for(int j=0; j<d; j++) {
			int sum=0;
			for(int k=0; k<b; k++) {
				sum += farmPlots[i][k] * shipmentPlan[k][j];
			}
			mulMat[i][j] = sum;
			}
	}
	return new PlotGrid(grid.getFarmName(), mulMat);
}

public int[][] getPlan() {
	return plan;
}

public void setPlan(int[][] plan) {
	this.plan = plan;
}

public void apply(ArrayList<Integer> v) {
	
	int rows = plan.length;
	int cols = plan[0].length;
	int vsize = v.size();
	if(v.size()!=cols) {
		System.out.println("posssible değil");
	}

		int[] result = new int[rows];
		for(int i=0; i<plan.length; i++) {
			int sum=0;
			for(int j=0; j<plan[0].length; j++) {
				sum += plan[rows][cols] * vsize;
			}
			result[rows] = sum;
		}
			
}

}








