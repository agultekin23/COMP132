/* *********** Pledge of Honor ************************************************ *

I hereby certify that I have completed this lab assignment on my own
without any help from anyone else. I understand that the only sources of authorized
information in this lab assignment are (1) the course textbook, (2) the
materials posted on the course website, and (3) any study notes handwritten by myself.
I have not used, accessed, or received any information from any other unauthorized
source in taking this lab assignment. The effort in the assignment thus belongs
completely to me.
READ AND SIGN BY WRITING YOUR NAME SURNAME, AND STUDENT ID
SIGNATURE: <Adnan Gültekin, 86816>
********************************************************************************/
package app;

import java.util.*;

import farm.*;
import logistics.*;

public class FarmMain {
    public static void main(String[] args) {
       
        int[][] farmAData = {
            {2, 0, 4},
            {3, 1,2},
            {1, 2,3}
        };

        int[][] farmBData = {
            {1, 1, 2},
            {0, 3, 3},
            {2, 1, 1}
        };

        int[][] farmCData = { // Different shape for mismatch paths
            {3, 1},
            {2, 4},
            {5, 2}
        };
        
        int[][] farmDData = {
        		{2, 2, 2},
        	    {3, 1, 2},
        	    {1, 3, 2}
            };
        
        int[][] farmFdata = {
        	    {2, 2, 2},
        	    {2, 2, 2},
        	};
        
       
        int[][] farmGdata = {
        	    {2, 2, 2},
        	    {2, 2, 2},
        	    {2, 2, 2}
        	};

        

        int[][] planA = {
            {2, 2, 3},
            {5, 2, 4},
            {4, 4, 3}
        };

        int[][] planB = {
            {4, 9},
            {6, 3},
            {5, 2}
        };

        int[][] planC = {
            {2, 2},
            {4, 4},
            {3, 3}
        };

        PlotGrid oliveGrove = new PlotGrid("Olive Grove", farmAData);
        PlotGrid riverbank  = new PlotGrid("Riverbank",  farmBData);
        PlotGrid unnamed    = new PlotGrid(); // "Unnamed Farm" 3x3 zeros
        PlotGrid annex      = new PlotGrid("Coastal Annex", farmCData);
        PlotGrid greenLand = new PlotGrid("Green Land", farmDData);
        PlotGrid greenValley = new PlotGrid("Green Valley", farmFdata);
        PlotGrid greenHill = new PlotGrid("Green Valley", farmGdata);
        
        

        ShipmentPlan spA = new ShipmentPlan(planA);
        ShipmentPlan spB = new ShipmentPlan(planB);
        ShipmentPlan spC = new ShipmentPlan(planC);

        System.out.println("--- Initial Farms ---\n");

        System.out.println("  Farm A ---\n");
        System.out.print(oliveGrove);
        System.out.println("\n");

        System.out.println("  Farm B ---\n");
        System.out.print(riverbank);
        System.out.println("\n");

        System.out.println("\n--- After merge at Olive Grove ---\n");
        oliveGrove.mergeFrom(riverbank);
        System.out.println("\n");

        System.out.println("\n--- Original Olive Grove plots were ---\n");
        System.out.print(oliveGrove);

        System.out.println("\n--- After aid allocation at Olive Grove ---\n");
        oliveGrove.allocateAid(riverbank);
        System.out.println("\n");
        oliveGrove.allocateAid(annex);

        System.out.println("\n--- Original Olive Grove plots were ---\n");
        System.out.print(oliveGrove);

        oliveGrove.scaleAll(2);
        System.out.println("\n");
        oliveGrove.rotateClockwise();
        System.out.println("\n");

        // Trigger mismatched merge
        oliveGrove.mergeFrom(annex);
        System.out.println("\n");

        // Parity checks and emptiness
        System.out.println("\n--------------Parity checks----------- \n");
        oliveGrove.checkFarmParity();
        System.out.println("\n");
        riverbank.checkFarmParity();
        System.out.println("\n");
        greenLand.checkFarmParity();
        System.out.println("\n");
        greenValley.checkFarmParity();
        System.out.println("\n");
        
        unnamed.checkAllZero();
        System.out.println("\n");
        greenLand.checkAllZero();
        System.out.println("\n");

        // Majority check for value 5
        oliveGrove.checkMajorityValue(5);
        System.out.println("\n");

        System.out.println("\n--- Applying shipment plan to Olive Grove ---\n");
        PlotGrid resA = spA.apply(oliveGrove);
        System.out.print(resA);
        System.out.println("\n");

        System.out.println("\n--- Applying shipment plan to Riverbank ---\n");
        PlotGrid resB = spB.apply(riverbank);
        System.out.print(resB);
        System.out.println("\n");

        System.out.println("\n--- Applying shipment plan to Coastal Annex ---\n");
        PlotGrid resC = spC.apply(annex);
        System.out.print(resC);
        System.out.println("\n");
        
        //////////////////// in lab test code /////////////////////////
System.out.println("\n........................... in lab .............................");

System.out.println("\n");
oliveGrove.analyzePlots(2);
System.out.println("\n");
oliveGrove.checkUniformityAndSymmetry();
System.out.println("\n");
oliveGrove.fertilizeDiagonal(5);
System.out.println("\n");

annex.analyzePlots(2);
System.out.println("\n");
annex.checkUniformityAndSymmetry();
System.out.println("\n");
annex.fertilizeDiagonal(5);
System.out.println("\n");
greenValley.analyzePlots(2);
System.out.println("\n");
greenValley.checkUniformityAndSymmetry();
System.out.println("\n");
greenValley.fertilizeDiagonal(5);

System.out.println("\n");
greenHill.analyzePlots(2);
System.out.println("\n");
greenHill.checkUniformityAndSymmetry();
System.out.println("\n");
greenHill.fertilizeDiagonal(5);
System.out.println("\n");
ArrayList<Integer> arrList1 = new ArrayList<>(Arrays.asList(2, 3, 2));
ArrayList<Integer> arrList2 = new ArrayList<>(Arrays.asList(3, 5, 2, 4));
System.out.println("\n Testing overloaded apply method \n");
spA.apply(arrList1);
System.out.println("\n");
spB.apply(arrList2);
        
        
    }
}
