import java.util.Scanner;

public class Comp132Lab0 {
	/* *********** Pledge of Honor ************************************************ *

	I hereby certify that I have completed this lab assignment on my own
	without any help from anyone else. I understand that the only sources of authorized
	information in this lab assignment are (1) the course textbook, (2) the
	materials posted on the course website, and (3) any study notes handwritten by myself.
	I have not used, accessed, or received any information from any other unauthorized
	source in taking this lab assignment. The effort in the assignment thus belongs
	completely to me.
	READ AND SIGN BY WRITING YOUR NAME SURNAME, AND STUDENT ID
	SIGNATURE: <Adnan Gültekin, 86816>
	********************************************************************************/	
	public static void main(String[] args) {
		
		

		// TODO:  1.  Define Variables: Define three variables of type double, namely distance, fuelConsumptionRate, and fuelPrice.
		
		double distance;
		double fuelConsumptionRate;
		double fuelPrice;
		
		// TODO:  2. User Input: Let the user input three values:

			// distance: The total distance of the road trip (in kilometers).	
			// fuelConsumptionRate: The fuel consumption rate of the vehicle (in liters per 100 kilometers).
			//fuelPrice: The price of fuel per liter (in your local currency).
		
		
		
		
		// Note: You can use the defined input object of type Scanner to get input from the user.
		
		Scanner input = new Scanner(System.in);
			System.out.println("Enter the total distance of the road trip (in kilometers): ");
			distance = input.nextDouble();
			System.out.println("Enter the fuel consumption rate of the vehicle (in liters per 100 kilometers): ");
			fuelConsumptionRate = input.nextDouble();
			System.out.println("Enter the price of fuel per liter (in your local currency): ");
			fuelPrice = input.nextDouble();
			
			// TODO:  3. Calculation: Write code that calculates the Total Fuel Cost.
            double totalCost;
			totalCost = ((distance/100) * fuelConsumptionRate * fuelPrice);
			

		// TODO:  4. Display the Result: Use System.out.println to display the total cost of the trip to the user.
			System.out.println(totalCost);
			


		// TODO:  5. Personalize with Your Information:

			// Define an object of type String, and store the string values of your name and surname in this object.
			// Define a variable of type int, and store your KUSIS ID number in this variable.
			// Use System.out.println to display your name, surname, and KUSIS ID number.
			
			String nameSurname = "Adnan Gültekin";
			int idNumber = 86816;
			System.out.println(nameSurname + " idNumber");
			
					


		// TODO:  6. Explore Unicode: Write the code for displaying the integer equivalents of the letters in your name and surname.
		System.out.printf("Character %c has the value %d%n", 'A', (int) 'A');
		System.out.printf("Character %c has the value %d%n", 'd', (int) 'd');
		System.out.printf("Character %c has the value %d%n", 'n', ((int) 'n'));
		System.out.printf("Character %c has the value %d%n", 'a', ((int) 'a'));
		System.out.printf("Character %c has the value %d%n", 'n', ((int) 'n'));
		System.out.printf("Character %c has the value %d%n", 'G', ((int) 'G'));
		System.out.printf("Character %c has the value %d%n", 'ü', ((int) 'ü'));
		System.out.printf("Character %c has the value %d%n", 'l', ((int) 'l'));
		System.out.printf("Character %c has the value %d%n", 't', ((int) 't'));
		System.out.printf("Character %c has the value %d%n", 'e', ((int) 'e'));
		System.out.printf("Character %c has the value %d%n", 'k', ((int) 'k'));
		System.out.printf("Character %c has the value %d%n", 'i', ((int) 'i'));
		System.out.printf("Character %c has the value %d%n", 'n', ((int) 'n'));

	}	

}
