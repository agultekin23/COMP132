package img;

public class CircularQueue {
	private int front, rear;
	private int[] nums;
	public CircularQueue(int initialSize) {
		this.front = this.rear = -1;
		this.nums = new int[initialSize];
	}
	
	public CircularQueue(int data) {
		this.data = data;
		this.next = null;
	}
	
	public void enqueue(int data) {
		CircularQueue n = new CircularQueue(data);
		if(rear==null) {
			n.next = n;
		}
		rear = n;
	}
	
	public int dequeue() {
		if(rear==null) {
			throw new NoSuchElementException();
			int temp = rear.next.data;
			if(rear.next == rear) {
				rear = null;
			}else {
				rear.next = rear.next.next;
			}
			return temp;
		}
	}

}
