[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/DJDRRhO9)
# COMP132, Fall2025, Lab 5 PreLab

# IMPORTANT

For each lab assignment, **you must include and sign (by writing your name and student ID number) the following Pledge of Honor statement at the beginning of your main method source code file. After including this statement, make sure that you do the commit and push operation on GitHub. Otherwise, your lab solution will not be graded.**
```
/* *********** Pledge of Honor ************************************************ *

I hereby certify that I have completed this lab assignment on my own
without any help from anyone else. I understand that the only sources of authorized
information in this lab assignment are (1) the course textbook, (2) the
materials posted on the course website, and (3) any study notes handwritten by myself.
I have not used, accessed, or received any information from any other unauthorized
source in taking this lab assignment. The effort in the assignment thus belongs
completely to me.
READ AND SIGN BY WRITING YOUR NAME SURNAME, AND STUDENT ID
SIGNATURE: <Name Surname, Student id>
********************************************************************************/
```
## Please carefully review the following important notes. Violating each one of them will result in a grade deduction.

## IMPORTANT NOTES: 

   ##### :pushpin: - All instance variables MUST have the exact name written in the instructions.
   ##### :pushpin: - You should implement getter/setter methods whenever needed (for example, if you are going to access the instance variables from other classes). You may use auto-generator for getter/setter methods (under the Source menu in Eclipse). Do NOT implement unused Getter/Setter methods. You will be penalized for each unused Getter/Setter.
   ##### :pushpin: -  You MUST follow the instructions (Package name, Class name, method name, variables, ...) so carefully. The packages, classes, instance variables, and methods MUST be created following the descriptions given in the assignment.
   ##### :pushpin: -  Please check the sample output provided at the end of this assignment. Your output MUST be exactly the same as the provided sample output.
   ##### :pushpin: -  After you complete the tasks, do not forget to commit your changes and push them to your repository on GitHub BEFORE 9.30 :clock930: AM, Friday.
   ##### :pushpin: -  This README.md file only contains the instructions for PRELAB. You will also have INLAB questions.

# Type Hierarchy for Streaming Content Management
In this pre-lab, you are asked to build a Java-type hierarchy aimed at representing types of Content and their up-to-date attributes using Java inheritance and polymorphism concepts.

You are provided with a Java project template, and you should do your development on this template. In the given Java project, the main program code Main.java in the package main is provided to test your code. Please note that we may test your code with additional test cases as well.

You should create another package named streaming that should include all the types described below. Based on the descriptions below, decide whether each type should be an abstract class, a concrete class, a superclass, or a subclass. Also, you must decide on the access modifiers according to the provided descriptions below.

<div align="center">
  <img src="/img/streaming.jpg" alt="Streaming service" />
</div>

## Package Structure
```
src
├── main
│   └── Main.java
└── streaming
    ├── Content.java
    ├── OnDemandContent.java
    ├── Series.java
    └── LiveStream.java
```

## Type Hierarchy:
- **Content**: This refers to a general type entity representing any streaming content. All Content represents different media available on a streaming platform.
- **OnDemandContent**: Represents media content that can be viewed at any time. It tracks viewing progress and supports downloading.
- **Series**: A form of OnDemandContent that consists of multiple episodes. 
- **LiveStream**: Represents content that broadcasts in real-time, with limited bandwidth.

**Note**: Throughout this document, when you see text within angle brackets like `<title>` or `<views>` in print statements, these indicate placeholders that should be replaced with the actual variable values. Do not print the angle brackets themselves. For example, `"Series: <title>"` should print as `"Series: Breaking Bad"` when the title variable contains "Breaking Bad".

---

# Package: streaming

## Class: Content

### Fields:
- `static ArrayList<Content> contentList`: An ArrayList of type Content holding all the content created so far.
- `String title`: Keeps the title of the content.
- `int views`: Records the number of views this content has received.
- `double availableHours`: Represents the hours of the content available for viewing.

### Methods:
- A **static** method `int getContentQuantity()`: Returns the total number of media items in the contentList.
- An **abstract** method `void stream()`: Can be implemented differently by concrete subclasses of class Content.
- An **abstract** method `void update()`: Can be implemented differently by concrete subclasses of class Content.
- A **static** method `void printAllContent()`: Iterates over contentList and prints information about all elements.
- **Constructor:** `Content(String title, int views)`: Initializes title and views fields, adding this content to the contentList. Validates input values to ensure they are logically consistent. Implementation should perform the following checks:
  - If `views` is negative, set it to zero.
  - If the input for `title` is `null` or empty (Check the string length by calling the `length()` method), then set title to `"Untitled"`.
- `toString()`: Returns information about the content, including `title`, and `views`. Take a closer look at the sample output to see the method's behavior in more detail.

---

## Class: OnDemandContent

### Fields:
- `double totalDuration`: Represents the total length of the content in hours.
- `double watchedDuration`: Indicates how many hours have been watched.

### Methods:
- **Constructor**: `OnDemandContent(String title, int views, double totalDuration, double watchedDuration)`:  
  **Important Note**: Make sure you check the input values inside the constructor properly. The constructor should perform the following validations:
  - If `totalDuration` is less than 1 hour, set it to 1.
  - If `watchedDuration` is negative, set it to 0.
  - If `watchedDuration` exceeds `totalDuration`, set it to `totalDuration`.
  - Calculate and set `availableHours = totalDuration - watchedDuration`.

---

## Class: Series

### Methods:
- **Constructor** `Series(String title, int views, double totalDuration, double watchedDuration)`:

- `void stream()`: Simulates streaming the series. This method performs the following operations:
  - If `availableHours > 0`:
    - Increases `watchedDuration` by 1 hour or by `availableHours`, if `availableHours` is less than 1.
    - Update `availableHours` accordingly.
    - Increases `views` by 1.
    - Prints: `"Streaming series <title>. Watched <timeWatched> hour(s)."` Where `timeWatched` is the amount actually watched.
  - If `availableHours` is equal to 0:
    - Prints: `"Cannot stream series <title>. All content already watched."`

- `void update()`: Adds new episodes to the series.
  - Increases `totalDuration` by 2 hours (representing new episodes added).
  - Update `availableHours` accordingly.
  - Prints: `"Series <title> updated with new episodes. Total duration now: <totalDuration> hours"`

- `toString()`: Override to include series-specific information. It should print `"Series: <title>, Views: <views>, Watched: <watchedDuration>/<totalDuration> hours, Availability: <availableHours> hours"` Take a look at the sample output for an example.

---

## Class: LiveStream

### Fields:
- `boolean isLive`: Indicates whether the stream is currently broadcasting.
- `static ArrayList<LiveStream> liveStreamList`: An ArrayList containing all created live streams.

### Methods:
- **Constructor** `LiveStream(String title, int views, double availableHours)`:
  - Initializes the object fields with the given parameters.
  - Sets `isLive` to `false` by default.
  - Validates input:
    - If `availableHours` is less than 0, set it to 0.
  - Adds the created object to `liveStreamList`.

- **static** `int getLiveStreamQuantity()`: Returns the size of `liveStreamList`.

- `void stream()`: Starts the live broadcast.
  - If `availableHours > 0`:
    - Sets `isLive` to `true`.
    - Prints: `"LiveStream <title> is now live!"`
  - If `availableHours <= 0`:
    - Prints: `"Cannot start stream. No time remaining for <title>."`

- `void streamToViewers(int viewers)`: Simulates streaming sessions with concurrent viewers, consuming scheduled time based on the number of viewers.
  - If the stream is live:
    - Calculates time consumed as `timeConsumed = 0.5 + (viewers * 0.01)`
    - Decreases `availableHours` by `timeConsumed`.
    - Increases `views` by the number of viewers.
    - If `availableHours > 0`:
      - Prints: `"LiveStream <title> streaming to <viewers> viewers. <availableHours> hours remaining."`
    - If `availableHours <= 0`:
      - Sets `availableHours` to 0.
      - Sets `isLive` to `false`.
      - Prints: `"LiveStream <title> has ended due to resource limits. No time remaining."`
  - If the stream is not live (`isLive` is `false`):
    - Prints: `"LiveStream <title> is not currently live."`

- **static** `void startAllStreams()`: Iterates over `liveStreamList` and calls `stream()` on each LiveStream.

- `void update()`: Extends the scheduled streaming time.
  - Adds 2 hours to `availableHours`.
  - Prints: `"LiveStream <title> extended. New availability: <availableHours> hours"`

- `toString()`: Returns a string displaying the LiveStream's details. Format: `"LiveStream: <title>, Views: <views>, Availability: <availableHours> hours, Live: <isLive>"` Take a look at the sample output for an example.

---

# Package: main

## Class: Main

The provided `Main.java` class is for testing your implemented Java application. This class is a driver class to demonstrate and test the functionalities of your implemented application. You are not allowed to change the given file. You are only allowed to add the pledge of honor to it. Any other changes may lead to grade reduction.

---

## Sample Output
```
LiveStream Gaming Stream is now live!
LiveStream Gaming Stream streaming to 10 viewers. 2.4 hours remaining.
LiveStream Gaming Stream extended. New availability: 4.4 hours
LiveStream: Gaming Stream, Views: 1510, Availability: 4.4 hours, Live: true


Streaming series Breaking Bad. Watched 1.0 hour(s).
Series Breaking Bad updated with new episodes. Total duration now: 62.0 hours
Cannot stream series Game of Thrones. All content already watched.
Streaming series Lonesome Dove. Watched 0.5 hour(s).
Series: Breaking Bad, Views: 50001, Watched: 1.0/62.0 hours, Availability: 61.0 hours


Total Content Created: 6
Total Live Streams: 2


Printing all content:
List of all content:
LiveStream: Gaming Stream, Views: 1510, Availability: 4.4 hours, Live: true
LiveStream: Music Concert, Views: 5000, Availability: 2.0 hours, Live: false
Series: Breaking Bad, Views: 50001, Watched: 1.0/62.0 hours, Availability: 61.0 hours
Series: Game of Thrones, Views: 80000, Watched: 73.0/73.0 hours, Availability: 0.0 hours
Series: Stranger Things, Views: 65000, Watched: 0.0/8.0 hours, Availability: 8.0 hours
Series: Lonesome Dove, Views: 2001, Watched: 4.0/4.0 hours, Availability: 0.0 hours


Starting all live streams:
LiveStream Gaming Stream is now live!
LiveStream Music Concert is now live!


LiveStream: Music Concert, Views: 5000, Availability: 2.0 hours, Live: true
LiveStream Music Concert streaming to 20 viewers. 1.3 hours remaining.
LiveStream: Music Concert, Views: 5020, Availability: 1.3 hours, Live: true
LiveStream Music Concert streaming to 15 viewers. 0.7 hours remaining.
LiveStream: Music Concert, Views: 5035, Availability: 0.7 hours, Live: true
LiveStream Music Concert streaming to 10 viewers. 0.1 hours remaining.
LiveStream: Music Concert, Views: 5045, Availability: 0.1 hours, Live: true
LiveStream Music Concert has ended due to resource limits. No time remaining.
LiveStream: Music Concert, Views: 5050, Availability: 0.0 hours, Live: false



