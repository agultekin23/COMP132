
public class SafeHouse {

}
