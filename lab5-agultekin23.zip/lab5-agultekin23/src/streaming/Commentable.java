package streaming;

public abstract class Commentable {
	public abstract void addComment(String comment);
	public abstract void displayComment();

}
