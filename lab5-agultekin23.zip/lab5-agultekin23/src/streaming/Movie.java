package streaming;

import java.util.ArrayList;

public class Movie extends Series{
	protected static ArrayList<String> comments = new ArrayList();

	public Movie(String title, int views, double totalDuration, double watchedDuration) {
		super(title, views, totalDuration, watchedDuration);
	}
	
	public void stream() {
		if(this.availableHours>0) {
			this.watchedDuration += 2;
			if(this.watchedDuration>this.totalDuration) {
				this.watchedDuration = this.totalDuration;
			}
			this.availableHours -= this.watchedDuration;
			views++;
			System.out.printf("Streaming movie %s. Watched %d hour(s).", this.title, this.watchedDuration);
		}else {
			System.out.printf("Cannot stream movie %s. All content already watched.", this.title);
		}

	}
	
	public void update() {
		this.totalDuration += 0.5;
		this.availableHours += 0.5;
		System.out.printf("Movie %s updated with bonus content. Total duration now: %d hours", this.title, this.availableHours);
	}
	
	
	public void download() {
		System.out.printf("Downloading movie %s... Download complete!", this.title);
	}
	public String toString() {
		return "Movie: " + this.title + ", Views: "+ this.views + ",Watched: " + this.watchedDuration+"/"+ "hours, Availability:" +this.availableHours+ "hours";
	}
	


}
