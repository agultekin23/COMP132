package streaming;

import java.util.ArrayList;

public class LiveStream extends Content{
	protected boolean isLive;
	protected static ArrayList<LiveStream> liveStreamList = new ArrayList<LiveStream>();
	protected ArrayList<String> comments = new ArrayList<String>();
	
	
	public LiveStream(String title, int views, double availableHours) {
		super(title,views);
		
		this.isLive = false;
		if(availableHours<0) {
			this.availableHours = 0;
		}else {
			this.availableHours = availableHours;
		}
		liveStreamList.add(this);
	}
	
	public static int getLiveStreamQuantity() {
		return liveStreamList.size();
	}
	
	public void stream() {
		if(availableHours>0) {
			isLive = true;
			System.out.println("LiveStream " + this.title + " is now live!");
		}else {
			System.out.println("Cannot start stream. No time remaining for "+this.title+".");
		}
	}
	
	public void streamToViewers(int viewers) {
		if(isLive) {
			double timeConsumed = 0.5 + (viewers * 0.01);
			this.availableHours -= timeConsumed;
			this.views += viewers;

		if(this.availableHours <0) {
			this.availableHours = 0;
		}
		
		if(this.availableHours>0) {
			System.out.printf("LiveStream %s streaming to %d viewers. %.1f hours remaining.%n", this.title, viewers, this.availableHours);
		}
		
		else {
		this.isLive = false;
			System.out.println("LiveStream "+this.title+" has ended due to resource limits. No time remaining.");
		}}
		else {
			System.out.println("LiveStream "+ this.title +" is not currently live.");
			
					
		}}
	
	
	public static void startAllStreams() {
		for (int i=0; i<LiveStream.liveStreamList.size(); i++) {
			LiveStream y = LiveStream.liveStreamList.get(i);
			y.stream();
		}
	}
	
	public void update() {
		availableHours += 2;
		System.out.printf("LiveStream %s extended. New availability: %.1f hours%n", this.title, this.availableHours);
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("LiveStream: ").append(this.title);
		sb.append(", Views: ").append(this.views);
		sb.append(", Availability: ");
		sb.append(String.format("%.1f", this.availableHours));
		sb.append(" hours, Live: ").append(this.isLive);
		return sb.toString();
	}
	

	
	public void addComment(String comment) {
		
		comments.add(comment);
		System.out.println("Live chat in "+this.title+":" +comment);
	
	}
	
	public void displayComments() {
		if(this.comments.size()==0) {
			System.out.printf("No chat messages yet for %s.", this.title);
		}else {
			for(int i=0; i<this.comments.size(); i++) {
				System.out.println("Live chat for " + this.title +":" + this.comments.get(i));
		}
	}
	
}
	
	
}

