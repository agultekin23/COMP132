package streaming;

import java.util.ArrayList;

public abstract class Content {
	protected static ArrayList<Content> contentList = new ArrayList();
	protected String title;
	protected int views;
	protected double availableHours;
	
	public static int getContentQuantity() {
		return contentList.size();
		
	}
	
	public abstract class content{
		
		public abstract void stream();
		
		
		public abstract void update();
		
		
	}
	
	public static void printAllContent() {
		for(int i=0; i<contentList.size(); i++) {
			Content x = contentList.get(i);
			System.out.println(x);
		}
	}
	
	public Content(String title, int views) {
		this.views = views;
		this.title = title;
		
		if(views<0) {
			views = 0;
		}
		if(title.equals(null) || title.length()==0) {
			title = "Untitled";
		}else {
			this.title = title;
		}
		
		contentList.add(this);
	}
	
	public static void printContentStatistics() {
		int content1 = contentList.size();
		int numOfMovies = 0;
		int numOfSeries = 0;
		int numOfLiveStreams = 0;
		double allAvailableHours = 0;
		for(Content c:contentList) {
			if(c instanceof Movie) {
				allAvailableHours++;
				numOfMovies++;
			}
			if(c instanceof Series) {
				allAvailableHours++;
				numOfSeries++;
			}
			if(c instanceof LiveStream) {
				numOfLiveStreams++;
			}
			
		}
		int totalNumber  = numOfMovies + numOfSeries + numOfLiveStreams;
		System.out.println("The content statistics: ");
		System.out.println(" ");
		System.out.println("Total content: " + totalNumber );
		System.out.println("Series: "+ numOfSeries);
		System.out.println("LiveStreams: "+ numOfLiveStreams);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	public String toString() {
		return 	"Content: " + this.views + ", Views: " + this.views;
		
	}

	public static void setContentList(ArrayList<Content> contentList) {
		Content.contentList = contentList;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setViews(int views) {
		this.views = views;
	}

	public void setAvailableHours(double availableHours) {
		this.availableHours = availableHours;
	}

	public static ArrayList<Content> getContentList() {
		return contentList;
	}

	public String getTitle() {
		return title;
	}

	public int getViews() {
		return views;
	}

	
	
}
