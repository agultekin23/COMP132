package streaming;

public interface Downloadable {
	public abstract void download();

}
