package streaming;

public class OnDemandContent extends Content {

	protected double totalDuration;
	protected double watchedDuration;
	
	public OnDemandContent(String title, int views, double totalDuration, double watchedDuration) {
		super(title, views);
		this.totalDuration = totalDuration;
		this.watchedDuration = watchedDuration;
		if(totalDuration<1) {
			this.totalDuration = 1;
		}
		if(watchedDuration<0) {
			this.watchedDuration = 0;
		}
		
		if(watchedDuration>totalDuration) {
			this.watchedDuration = this.totalDuration;
		}
		this.availableHours = this.totalDuration - this.watchedDuration;
	}
	
}
