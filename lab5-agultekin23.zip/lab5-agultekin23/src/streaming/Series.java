package streaming;

import java.util.ArrayList;

public class Series extends OnDemandContent{

	public Series(String title, int views, double totalDuration, double watchedDuration) {
		super(title, views, totalDuration, watchedDuration);
	}
	
	public void stream() {
	    
	    if (this.availableHours <= 0) {
	        System.out.println("Cannot stream series " + this.title + ". All content already watched.");
	        return; 
	    }

	    double watched;
	    
	    if (this.availableHours < 1.0) {
	        watched = this.availableHours;
	    } else {
	        watched = 1.0;
	    }
	    
	    this.watchedDuration += watched;
	    this.availableHours -= watched; 
	    
	    if (this.availableHours < 0) {
	        this.availableHours = 0;
	    }
	    
	    this.views++;
	    
	    System.out.printf("Streaming series %s. Watched %.1f hour(s).%n", this.title, watched);
	}
	
	public void update() {
		this.totalDuration+=2;
		this.availableHours = this.totalDuration - this.watchedDuration;
		System.out.println("Series " + this.title + " updated with new episodes. Total duration now: " + totalDuration+ " hours");
	}
	@Override
	public String toString() {
		return "Series: " + this.title+ ", Views: " + this.views+ ", Watched: " + this.watchedDuration+ "/"+ this.totalDuration+" hours, Availability: "+ this.availableHours+" hours";
		
	}
	protected static ArrayList<String> comments = new ArrayList();
	
	public void addComment(String comment) {
		comments.add(comment);
		System.out.printf("Comment added to series %s: %s", this.title, comment);
	}
	
	public void displayComments() {
		if (comments.size()==0) {
			System.out.printf("No comments yet for %s.", this.title);
		}else {
			for(int i=0; i<comments.size(); i++) {
				System.out.println("Comments for " + this.title +":" + comments.get(i));
			}
		}
	}
	
	public void download() {
		System.out.println("Downloading series " + this.title + "... Download complete!");
	}
	
}

