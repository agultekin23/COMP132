
public abstract class Location {

}
