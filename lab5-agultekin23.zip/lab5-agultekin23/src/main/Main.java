/* *********** Pledge of Honor ************************************************ *

I hereby certify that I have completed this lab assignment on my own
without any help from anyone else. I understand that the only sources of authorized
information in this lab assignment are (1) the course textbook, (2) the
materials posted on the course website, and (3) any study notes handwritten by myself.
I have not used, accessed, or received any information from any other unauthorized
source in taking this lab assignment. The effort in the assignment thus belongs
completely to me.
READ AND SIGN BY WRITING YOUR NAME SURNAME, AND STUDENT ID
SIGNATURE: <Adnan Gültekin, 86816>
********************************************************************************/
package main;

import streaming.*;

public class Main {

	public static void main(String[] args) {
		 // Create LiveStreams
        LiveStream stream1 = new LiveStream("Gaming Stream", 1500, 3.0);
        LiveStream stream2 = new LiveStream("Music Concert", 5000, 2.0);
        stream1.stream();
        stream1.streamToViewers(10);
        stream1.update();
        System.out.println(stream1 + "\n");

        // Create Series
        Series series1 = new Series("Breaking Bad", 50000, 60, 0);
        Series series2 = new Series("Game of Thrones", 80000, 73, 73);
        Series series3 = new Series("Stranger Things", 65000, 8, -5);
        Series series4 = new Series("Lonesome Dove", 2000, 4.0, 3.5);
        series1.stream();
        series1.update();
        series2.stream();
        series4.stream();
        System.out.println(series1);
        System.out.println();

        

        // Print the number of content created
        System.out.println("Total Content Created: " + Content.getContentQuantity());
        System.out.println("Total Live Streams: " + LiveStream.getLiveStreamQuantity());
        
        
        // Print all content
        System.out.println("\nPrinting all content:");
        Content.printAllContent();
        
        // Start all live streams
        System.out.println("\nStarting all live streams:");
        LiveStream.startAllStreams();
        
        System.out.println("\n");  
        
        System.out.println(stream2.toString());
        stream2.streamToViewers(20);
        System.out.println(stream2.toString());
        stream2.streamToViewers(15);
        System.out.println(stream2.toString());
        stream2.streamToViewers(10);
        System.out.println(stream2.toString());
        stream2.streamToViewers(5);
        System.out.println(stream2.toString());
        
        System.out.println("\n...................................... InLab......................................\n");
        		//Create different content types
        		Movie m1 = new Movie("Inception", 100000, 2.5, 0);
        		Movie m2 = new Movie("The Matrix", 95000, 2.3, 2.3);
        		Series s1 = new Series("The Office", 120000, 73, 10);
        		LiveStream ls1 = new LiveStream("Cooking Show", 5000, 1.5);
        		//Test Downloadable
        		System.out.println("Testing Downloadable:\n");
        		m1.download();
        		m2.download();
        		s1.download();
        		System.out.println();
        		//Test Commentable
        		System.out.println("Testing Commentable:\n");
        		s1.addComment("UK version is better!");
        		s1.addComment("No laugh tracks!!!");
        		ls1.addComment("Great recipe!");
        		ls1.addComment("Love the presentation");
        		System.out.println();
        		//Display comments
        		s1.displayComments();
        		System.out.println();
        		ls1.displayComments();
        		System.out.println();
        		//Test Movie streaming
        		System.out.println("Testing Movie streaming:\n");
        		m1.stream();
        		System.out.println(m1);
        		m2.stream();
        		System.out.println();

        		//Test Movie update
        		m1.update();
        		System.out.println(m1);
        		m1.stream();
        		System.out.println();
        		//Print content statistics
        		Content.printContentStatistics();
	}

}
