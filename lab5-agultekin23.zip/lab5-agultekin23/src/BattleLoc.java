
public abstract class BattleLoc {

}
