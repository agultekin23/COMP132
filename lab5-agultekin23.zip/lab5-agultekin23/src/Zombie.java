
public class Zombie {

}
