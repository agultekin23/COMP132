
public abstract class NormalLoc {

}
