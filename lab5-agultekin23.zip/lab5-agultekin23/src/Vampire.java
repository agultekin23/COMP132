
public class Vampire {

}
