
public class Inventory {

}
