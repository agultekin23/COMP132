
public class Bear {

}
