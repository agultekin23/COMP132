
public class Obstacle {

}
