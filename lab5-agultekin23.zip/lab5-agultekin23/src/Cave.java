
public class Cave {

}
