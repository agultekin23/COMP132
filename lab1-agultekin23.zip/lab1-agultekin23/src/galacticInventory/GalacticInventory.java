/* *********** Pledge of Honor ************************************************ *

I hereby certify that I have completed this lab assignment on my own
without any help from anyone else. I understand that the only sources of authorized
information in this lab assignment are (1) the course textbook, (2) the
materials posted at the course website and (3) any study notes handwritten by myself.
I have not used, accessed or received any information from any other unauthorized
source in taking this lab assignment. The effort in the assignment thus belongs
completely to me.
READ AND SIGN BY WRITING YOUR NAME SURNAME AND STUDENT ID
SIGNATURE: <Adnan Gültekin, 86816>
********************************************************************************/
package galacticInventory;

import java.util.Arrays;

public class GalacticInventory {
    public static void main(String[] args) {
        // Define arrays for item names and their prices (in credits)
        String[] itemNames = {"Quantum Battery", "Anti-Gravity Boots", "Plasma Rifle Core", "Nano-Med Kit", "Stasis Crystal", "Hull Repair Foam", "Navigation AI Chip"};

        double[] itemPrices = {
            1200.0,   // Quantum Battery
            450.5,    // Anti-Gravity Boots
            3200.75,  // Plasma Rifle Core
            875.0,    // Nano-Med Kit
            1500.0,   // Stasis Crystal
            300.0,    // Hull Repair Foam
            999.99    // Navigation AI Chip
        };

        // Cargo manifests from two different stations
        String[] station1 = {"Quantum Battery", "Anti-Gravity Boots", "Plasma Rifle Core", "Navigation AI Chip", "Hull Repair Foam", "Nano-Med Kit", "Stasis Crystal"};

        String[] station2 = {"Cloaking Field Emitter", "Navigation AI Chip", "Plasma Rifle Core", "Quantum Battery", "Terraforming Seed Pod", "Nano-Med Kit"};

        System.out.print("\nOriginal cargo manifest: ");
        printCollection(itemNames, itemPrices);

        // 1. Sort items by price in descending order
        sortByPriceDescending(itemNames, itemPrices);
        System.out.print("\nItems sorted by price (descending): \n");
        printCollection(itemNames, itemPrices);
        System.out.println("\n\nExpected: Plasma Rifle Core, Stasis Crystal, Quantum Battery, Nano-Med Kit, Navigation AI chip, Anti-Gravity Boots, Hull Repair Foam ");

        // 2. Sort items by price in ascending order
        sortByPriceAscending(itemNames, itemPrices);
        System.out.print("\n\nItems sorted by price (ascending): ");
        printCollection(itemNames, itemPrices);
        System.out.println("\n\nExpected: Hull Repair Foam, Anti-Gravity Boots, Navigation AI Chip, Nano-Med Kit, Quantum Battery, Stasis Crystal, Plasma Rifle Core");

        // 3. Calculate the total cargo value
        double totalCost = calculateTotalCost(itemPrices);
        System.out.println("\n\nTotal cargo value is " + totalCost + " credits");
        System.out.println("Expected: 8526.24 credits");

        // 4. Find the most expensive item
        String mostExpensive = findMostExpensive(itemNames, itemPrices);
        System.out.println("\nMost expensive item: " + mostExpensive);
        System.out.println("Expected: Plasma Rifle Core");

        // 5. Remove an item from the manifest by name
        String[] updatedInventory = removeItem(itemNames, itemPrices, "Plasma Rifle Core");
        System.out.print("\nAfter removing Plasma Rifle Core, remaining cargo: ");
        printArray(updatedInventory);
        // As long as your method correctly removes the requested item, the order of the remaining items does not matter.
        System.out.println("Expected: Quantum Battery, Anti-Gravity Boots, Nano-Med Kit, Stasis Crystal, Hull Repair Foam, Navigation AI Chip");  
      
        // in-lab test code in main method
        System.out.print("\n\n--------------- In Lab ---------------\n");
        String[] cargoManifest1 = {"Quantum Battery", "Anti-Gravity Boots", "Nano-Med Kit", "Plasma Rifle Core",
        "Navigation AI Chip", "Hull Repair Foam", "Stasis Crystal"};
        String[] cargoManifest2 = {"Cloaking Field Emitter", "Navigation AI Chip", "Plasma Rifle Core", "Quantum Battery", "Terraforming Seed Pod", "Nano-Med Kit"};
        findCommonItems(cargoManifest1, cargoManifest2);
        

    }  // End of Main method

    // This method should sort items by price in ascending order.
    // TODO: Implement this method using the approach in sortByPriceDescending.
    public static void sortByPriceAscending(String[] names, double[] prices) {
        // Implementation required
        int i, j;
        for (i = 0; i < prices.length - 1; i++) {
            int minIndex = i;
            for (j = i + 1; j < prices.length; j++) {
                if (prices[j] < prices[minIndex]) {
                    minIndex = j;
                }
            }
            // Swap prices
            // swap(neye göre sıralamak istediğim, ilk eleman, bir sonraki eleman)
            swap(prices, i, minIndex);

            // Swap names accordingly 
            // swap(neye göre sıralamak istediğim, ilk eleman, bir sonraki eleman)
            swap(names, i, minIndex);
        }
    }

    	
    	
    

    // This method should sort items by price in descending order.
    // TODO: FIX this method if needed
    public static void sortByPriceDescending(String[] names, double[] prices) {
        int i, j;
        for (i = 0; i < prices.length - 1; i++) {
            int maxIndex = i;
            for (j = i + 1; j < prices.length; j++) {
                if (prices[j] > prices[maxIndex]) {
                    maxIndex = j;
                }
            }
            // Swap prices
            // swap(neye göre sıralamak istediğim, ilk eleman, bir sonraki eleman)
            swap(prices, i, maxIndex); //hatavar

            // Swap names accordingly 
            // swap(neye göre sıralamak istediğim, ilk eleman, bir sonraki eleman)
           swap(names, i, maxIndex); //hatavar
        }
    }

    // This method should swap the contents of two cells in a String array
    // TODO: FIX this method if needed
    public static void swap(String[] array, int firstIndex, int secondIndex){
        String temp = array[firstIndex];
        array[firstIndex] = array[secondIndex];
        array[secondIndex] = temp;
    }

    // This method should swap the contents of two cells in a double array
    // TODO: FIX this method if needed
    public static void swap(double[] array, int firstIndex, int secondIndex){
        double temp = array[firstIndex];
        array[firstIndex] = array[secondIndex];
        array[secondIndex] = temp; //hata vardı swaplenme doğru  olmuyordu. swap(String) mantığı yukarıdaki doğru. İki kez atama vardı. 
    }

    // TODO: FIX this method
    public static double calculateTotalCost(double[] prices) {
        double total = 0;
        for (double price : prices) {
            total += price; //hata totalcostu bulmak istiyoruz average olmadığı için length'e bölmemize gerek yok.
        }
        return total;
    }

    // TODO: FIX this method
    public static String findMostExpensive(String[] names, double[] prices) {
        int maxIndex = 0;
        for (int i = 1; i < prices.length; i++) {
            if (prices[i] > prices[maxIndex]) {
                maxIndex = i; 
            }
        }
        return names[maxIndex];
    }

    // TODO: FIX this method to remove an item by name
    public static String[] removeItem(String[] names, double[] prices, String itemToRemove) {
        int newSize = names.length - 1;
        String[] newNames = new String[newSize];
        double[] newPrices = new double[newSize];

        int j = 0;
        for (int i = 0; i < names.length; i++) {
            if (!names[i].equals(itemToRemove)) {
                newNames[j] = names[i];
                newPrices[j] = prices[i];
                j++;
            }
        }
        return newNames;
    }


    // Helper method to print the collection (DO NOT MODIFY)
    public static void printCollection(String[] names, double[] prices) {
        System.out.print("\n[");
        for (int i = 0; i < names.length; i++) {
            System.out.print(names[i] + " (" + prices[i] + " cr)");
            if (i != names.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("]");
    }

    // Helper method to print an array (DO NOT MODIFY)
    public static void printArray(String[] array) {
        System.out.print("[");
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i]);
            if (i != array.length - 1) { 
                System.out.print(", ");
            }
        }
        System.out.println("]");
    }
    
    public static void findCommonItems(String[] cargoManifest1, String[] cargoManifest2) {
    	int ortak = 0;
    	for(int i=0; i<cargoManifest1.length; i++) {
    		for(int j=0; j<cargoManifest2.length; j++) {
    			if(cargoManifest1[i]==cargoManifest2[j]) {
    				ortak++;
    			}}}
    	System.out.println("Number of common items: " + ortak);	

    	
    	String[] newArray = new String[ortak];
    	int index =0;
    	for(int i=0; i<cargoManifest1.length; i++) {
    		for(int j=0; j<cargoManifest2.length; j++) {
    			if(cargoManifest1[i]==cargoManifest2[j]) {
    				newArray[index] = cargoManifest1[i];
    				index++;
    
    			}
    		}
    	}
    	System.out.println("Common items:" + Arrays.toString(newArray));
    	
    	
    	
    }

    //////////////////////////////////////////////////////// In-lab test code will be added below//////////////////////////////////////////////////////////////////////

} 




