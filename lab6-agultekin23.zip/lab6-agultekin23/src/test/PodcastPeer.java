package test;

import java.util.HashMap;
import java.util.Map;

public class PodcastPeer implements Comparable<PodcastPeer>{
	static int totalPeers=0;
	int id;
	String name;
	boolean status;
	Map<String, PodcastEpisode> tracks;
	KuPodcastNet kuPodcastNet;
	
	PodcastPeer(String name, Map<String, PodcastEpisode> tracks){
		this.name = name;
		this.tracks = new HashMap<>(tracks);
		this.status = true; 
		totalPeers++;
		this.id = totalPeers;}
	
	public void joinNetwork(KuPodcastNet network){
		this.kuPodcastNet = network;
		network.registerPeer(this);
	}
	
	public boolean hasTrack(PodcastEpisode track) {
		if(tracks.containsKey(track.name)) {
			return true;
		}else {
			return false;
		}
	}
	
	public void receiveTrack(PodcastEpisode track) {
		this.tracks.put(track.name, track);
		
	}
	
	public String toString() {
		String status;
	    
	    if (this.status == true) {
	        status = "Online";
	    } else {
	        status = "Offline";
	    }


	   return  "Peer ID: " + this.id + "\n" +
	           "Name: " + this.name + "\n" +
	           "Status: " + status + "\n";
	
	}

	
	public boolean downloadTrack(String name) {
	    System.out.println(this.name + " tries to download " + name);

	    boolean success = false;

	    if (kuPodcastNet == null) {
	        System.out.println(this.name + " Peer hasn't joined the network yet, download aborted.\n");
	    } 
	    else if (this.kuPodcastNet.trackExists(name) == false) {
	        System.out.println(name + " Track does not exist in the network, download was aborted.\n");
	    } 
	    else if (this.tracks.containsKey(name)) {
	        System.out.println(this.name + " already has the track: " + name + " Skipping download.\n");
	    } 
	    else {
	        PodcastEpisode track2 = this.kuPodcastNet.getTrackInfo(name);
	        System.out.println(this.name + " Downloading track: " + name);

	        this.receiveTrack(track2);
	        track2.addLocation(this);
	        
	        System.out.println(name + " has been downloaded by " + this.name + "\n");
	        success = true;
	    }

	    return success;
	}

	public int compareTo(PodcastPeer otherPeer) {
		if(this.id>otherPeer.id) {
			return 1;
		}else if(this.id==otherPeer.id){
			return 0;
		}else {
			return -1;
		}
	}
	

}
