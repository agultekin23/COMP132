/* *********** Pledge of Honor ************************************************ *

I hereby certify that I have completed this lab assignment on my own
without any help from anyone else. I understand that the only sources of authorized
information in this lab assignment are (1) the course textbook, (2) the
materials posted on the course website, and (3) any study notes handwritten by myself.
I have not used, accessed, or received any information from any other unauthorized
source in taking this lab assignment. The effort in the assignment thus belongs
completely to me.
READ AND SIGN BY WRITING YOUR NAME SURNAME, AND STUDENT ID
SIGNATURE: <Adnan Gültekin, 86816>
********************************************************************************/
package test;

import java.util.*;
import java.util.Map.Entry;

import kupodcastnet.*;

public class Test {
	   public static void main(String[] args) {
	       // Creating sample music tracks
	       PodcastEpisode[] podcastEpisodes = {
	               new PodcastEpisode("Track1", "Artist1", 240, 512),
	               new PodcastEpisode("Track2", "Artist2", 180, 384),
	               new PodcastEpisode("Track3", "Artist3", 320, 768),
	               new PodcastEpisode("Track4", "Artist3", 240, 580)
	       };
		   // Creating KuPodcastNet instance
	       KuPodcastNet kuPodcastNet = new KuPodcastNet(podcastEpisodes);
	       // Creating sample peers with initial tracks
	       Map<String, PodcastEpisode> initialTracks1 = new HashMap<>();
	       initialTracks1.put("Track1", podcastEpisodes[0]);
	       initialTracks1.put("Track3", podcastEpisodes[2]);
	       initialTracks1.put("Track4", podcastEpisodes[3]);
	       PodcastPeer peer1 = new PodcastPeer("Peer1", initialTracks1);
	      
	       Map<String, PodcastEpisode> initialTracks2 = new HashMap<>();
	       initialTracks2.put("Track2", podcastEpisodes[1]);
	       PodcastPeer peer2 = new PodcastPeer("Peer2", initialTracks2);
	      
	       PodcastPeer peer3 = new PodcastPeer("Peer3", initialTracks2);
	       // Joining peers to the network
	       peer1.joinNetwork(kuPodcastNet);
	       peer2.joinNetwork(kuPodcastNet);
	       // Testing download functionality
	       peer1.downloadTrack("Track2"); // Peer1 downloads Track2
	       peer1.downloadTrack("Track4"); // Peer1 tries to download Track4
		   peer1.downloadTrack("Track5"); // Peer1 tries to donwload unused (which doesn't exist in the network)
		   peer2.downloadTrack("Track3"); // Peer2 downloads Track3
	       peer3.downloadTrack("Track3"); // Peer3 tries to Track3

	       // Displaying peer information
	       System.out.println("\nPeer 1 Info:");
	       System.out.println(peer1);
	       System.out.println("\nPeer 2 Info:");
	       System.out.println(peer2);
		   
	    	/////////////////////////////////////////////////// In-lab Test code /////////////////////////////////////////////
	       System.out.println("\n** INLAB **\n");
	       for (PodcastEpisode podcastEpisode : initialTracks1.values()) {
	       peer3.receiveTrack(podcastEpisode);
	       }
	       peer3.joinNetwork(kuPodcastNet);
	       System.out.println("Track Infos:\n");
	       for (PodcastEpisode podcastEpisode : podcastEpisodes) {

	       System.out.println(podcastEpisode+"\n");
	       }
	       System.out.println("******************************");
	       System.out.println("Compare Peers: " + ((peer1.compareTo(peer3) == -1) ?
	       "Correct" : "False") + "\n");
	       System.out.println("Sort Peers:\n");
	       kuPodcastNet.sortPeers();
	       System.out.print(kuPodcastNet.showPeers());
	       System.out.println("******************************");
	       System.out.println("Reverse Sort Peers:\n");
	       kuPodcastNet.sortPeersReverse();
	       System.out.print(kuPodcastNet.showPeers());
	       System.out.println("******************************");
	       System.out.println("Common Tracks between peers joined to the network:\n");
	       Map <PodcastPeer, Map <PodcastPeer, List<PodcastEpisode>>>

	       commonTracks = kuPodcastNet.findCommonTracks();
	       ArrayList<PodcastPeer> peers = new

	       ArrayList<>(commonTracks.keySet());
	       Collections.sort(peers);
	       int outerEntryCount = 1;
	       for (PodcastPeer student: peers) {
	       System.out.println("Entry " + outerEntryCount++);
	       System.out.println(student + "\n");
	       int innerEntryCount=1;
	       Map <PodcastPeer, List<PodcastEpisode>> innerMap =

	       commonTracks.get(student);

	       ArrayList<PodcastPeer> innerPodcastPeers = new

	       ArrayList<>(innerMap.keySet());

	       Collections.sort(innerPodcastPeers);
	       for (PodcastPeer innerPodcastPeer: innerPodcastPeers) {
	       System.out.println("Matched entry " +

	       innerEntryCount++);

	       System.out.println(innerPodcastPeer + "\n");
	       for (PodcastEpisode podcastEpisode :

	       innerMap.get(innerPodcastPeer)) {

	       System.out.println(podcastEpisode+ "\n");
	       }
	       }
	       System.out.println("******************************");
	       }
	   }
	}
