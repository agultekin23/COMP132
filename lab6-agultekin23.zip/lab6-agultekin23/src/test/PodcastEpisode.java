package test;

import java.util.HashSet;
import java.util.Set;

public class PodcastEpisode {
	
	String name;
	String artist;
	int duration;
	int fileSize;
	Set<PodcastPeer> locations;
	
	public PodcastEpisode(String name, String artist, int duration, int fileSize) {
		this.name = name;
		this.artist = artist;
		this.duration = duration;
		this.fileSize = fileSize;
		this.locations = new HashSet<>();
	}
	
	public void addLocation(PodcastPeer p) {
		this.locations.add(p);
		
	}
	
	public boolean availableAt(PodcastPeer p) {
		if(this.locations.contains(p)) {
			return true;
		} else {
			return false;
		}
	}
	
	public String toString() {
		   return  "Track: " + name + "\n" +
		           "Artist: " + artist + "\n" +
		           "Duration: " + duration + "\n"+
		           "File Size: " + fileSize + "\n";
	}
	
	
	
}
