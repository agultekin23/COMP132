package test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

public class KuPodcastNet {
	
	List<PodcastPeer> peers = new ArrayList<>();	
	Map<String, PodcastEpisode> tracks = new HashMap<>();
	
	public KuPodcastNet(PodcastEpisode[] tracks) {
		this.peers = new ArrayList<>();
		this.tracks = new HashMap<>();
		
		for(PodcastEpisode x : tracks) {
			this.tracks.put(x.name, x);
		}
	}
	
	public boolean trackExists(String name) {
		if(this.tracks.containsKey(name)) {
			return true;
		}else {
			return false;
		}
	}
	
	public PodcastEpisode getTrackInfo(String name) {
		if(this.trackExists(name)) {
			return this.tracks.get(name);
		}else {
			return null;
		}
	}
	
	public void registerPeer(PodcastPeer p) {
		this.peers.add(p);
		addPeerTracksToNetwork(p);
	}
	
	private void addPeerTracksToNetwork(PodcastPeer p) {
		Map<String, PodcastEpisode> peerMap = p.tracks;

	    for (PodcastEpisode k : peerMap.values()) {
	        String trackName = k.name;
	        boolean isTrackInNetwork;
	        if(this.tracks.containsKey(trackName)) {
	        	isTrackInNetwork=true;
	        }else {
	        	isTrackInNetwork=false;
	        }

	        if (isTrackInNetwork) {
	            PodcastEpisode networkTrack = this.tracks.get(trackName);
	            networkTrack.addLocation(p);
	        }
	    }
	}
	
	public void sortPeers() {
		
		Collections.sort(peers);
		
	}
	
	public void sortPeersReverse() {
		
		Collections.sort(peers, Collections.reverseOrder());
		
	}
	
	public String showPeers() {
		   
		String x="";
		for(PodcastPeer p : peers) {
			x += p.toString() + "\n";
		}
		return x;
	}
	
	public Map<PodcastPeer, Map<PodcastPeer, List<PodcastEpisode>>> findCommonTracks(){
		Map<PodcastPeer, Map<PodcastPeer, List<PodcastEpisode>>> newMap1 = new HashMap<>();
		
		List<PodcastPeer> list1 = new ArrayList<>();
		List<PodcastPeer> list2 = new ArrayList<>();


		for(int k=0; k<peers.size(); k++) {
			Map<PodcastPeer, List<PodcastEpisode>> newMap2 = new HashMap<>();
			
			for(int j=0; j<peers.size(); j++) {
				if(peers.get(k)==peers.get(j)) {
					continue;
				}else {
					//newMap1.put(peers.get(k).tracks);
					//newMap2.put(peers.get(j).tracks);
				}
			}
		}
		return newMap1;
	}
	
	
	
	
	
	
	

}
