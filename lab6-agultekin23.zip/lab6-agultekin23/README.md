# COMP132, Fall2025, Lab 6 PreLab

# IMPORTANT

For each lab assignment, **you must include and sign (by writing your name and student ID number) the following Pledge of Honor statement at the beginning of your main method source code file. After including this statement, make sure that you do the commit and push operation on GitHub. Otherwise, your lab solution will not be graded.**
```
/* *********** Pledge of Honor ************************************************ *

I hereby certify that I have completed this lab assignment on my own
without any help from anyone else. I understand that the only sources of authorized
information in this lab assignment are (1) the course textbook, (2) the
materials posted on the course website, and (3) any study notes handwritten by myself.
I have not used, accessed, or received any information from any other unauthorized
source in taking this lab assignment. The effort in the assignment thus belongs
completely to me.
READ AND SIGN BY WRITING YOUR NAME SURNAME, AND STUDENT ID
SIGNATURE: <Name Surname, Student id>
********************************************************************************/
```
## Please carefully review the following important notes. Violating each one of them will result in a grade deduction.

## IMPORTANT NOTES: 

   ##### :pushpin: - All instance variables MUST have the exact name written in the instructions.
   ##### :pushpin: - You should implement getter/setter methods whenever needed (for example, if you are going to access the instance variables from other classes). You may use auto-generator for getter/setter methods (under the Source menu in Eclipse). Do NOT implement unused Getter/Setter methods. You will be penalized for each unused Getter/Setter.
   ##### :pushpin: -  You MUST follow the instructions (Package name, Class name, method name, variables, ...) so carefully. The packages, classes, instance variables, and methods MUST be created following the descriptions given in the assignment.
   ##### :pushpin: -  Please check the sample output provided at the end of this assignment. Your output MUST be exactly the same as the provided sample output.
   ##### :pushpin: -  After you complete the tasks, do not forget to commit your changes and push them to your repository on GitHub BEFORE 9.30 :clock930: AM, Friday.
   ##### :pushpin: -  This README.md file only contains the instructions for PRELAB. You will also have INLAB questions.

# Lab 6 Prelab: KuPodcastNet Application

In this lab, your task is to develop a simplified simulation of a decentralized peer-to-peer (P2P) podcast-sharing system using data structures of **Java Collections Framework**. You will design and implement classes that represent podcast episodes, peers in the network, and the overall KuPodcastNet system that connects them. The purpose of this assignment is to help you practice using Java Collection Framework structures (such as Lists, Maps, and Sets) while managing interactions between peers who share podcast episodes without relying on a central server.

KuPodcastNet is a peer-to-peer (P2P) music-sharing application designed to allow users to share and download music files directly from other peers in the Network. KuPodcastNet operates without a central server, distributing music files across multiple peers. Each peer stores a collection of Podcast episodes and can share these tracks with other peers upon request.

## Package Structure:

- kupodcastnet: Contains classes related to the KuPodcastNet application.
- test: Contains a test class to verify the functionality of your implemented KuPodcastNet application. It is already given to you. 
  
```
src
├── kupodcastnet
│   ├── KuPodcastNet.java
│   ├── PodcastEpisode.java
│   └── PodcastPeer.java
└── test
    └── Test.java
```

<div align="center">
  <img src="/img/06.png" alt="Podcast Net" />
</div>

# Class Details


## KuPodcastNet Class

### Fields:
- `peers`: A List of all peers in the KuPodcastNet network.
- `tracks`: A Map from String to PodcastEpisode object, where the key is the name of the `PodcastEpisode` and the value is the PodcastEpisode object itself.

### Methods:
- Constructor: `KuPodcastNet(PodcastEpisode[] tracks)`: Takes a parameter of `PodcastEpisode` array and initializes the `KuPodcastNet` network with the given Podcast episodes and an empty list of peers.
- `boolean trackExists(String name)`: Checks if a Podcast episode exists in the track Map.
- `PodcastEpisode getTrackInfo(String name)`: Searches for a track using its name and returns the `PodcastEpisode` object if it exists. Otherwise, it returns null.
- `void registerPeer(PodcastPeer p)`: Adds a peer to the list of peers in the network and adds the peer's tracks by calling the `addPeerTracksToNetwork(p)` method.
- `private void addPeerTracksToNetwork(PodcastPeer p)`: Adds a peer's tracks to the network by updating the `PodcastEpisode` objects' locations.


## PodcastEpisode Class

Each `PodcastEpisode` object represents a music file with the following details:

### Fields:
- `String name`: Name of the Podcast episode.
- `String artist`: Artist name.
- `int duration`: Duration of the track (sec).
- `int fileSize`: Size of the file (bytes).
- `locations`: A Set of `PodcastPeer` objects within the podcast network that have a copy of this track.

### Methods:

- `Constructor` with the signature `public PodcastEpisode(String name, String artist, int duration, int fileSize)`: Initializes the Podcast episode with the given information and an empty set of locations.
- `void addLocation(PodcastPeer p)`: Adds a peer to the set of locations.
- `boolean availableAt(PodcastPeer p)`: Returns true if peer p has a copy of this track, false otherwise.


## PodcastPeer Class

Peers in the network can share their collection of Podcast episodes with other peers upon request, allowing users to discover and download tracks directly from other users' machines.

### Fields:
- `int totalPeers`: A static variable that keeps count of all peers, to generate peer IDs.
- `int id`: The ID of each peer.
- `String name`: Name of the peer.
- `tracks`: A Map from String to PodcastEpisode object, where the key is the name of the PodcastEpisode and the value is the PodcastEpisode object itself.
- `boolean status`: Status of the peer as a boolean.
- `kuPodcastNet`: The KuPodcastNet object (the network) a peer belongs to.

### Methods:
- `Constructor`: Takes as a parameter a string name, and a Map that stores podcast episodes, with track name as the key, and the `PodcastEpisode` object as the value itself. Initializes the peer with the given name, sets status as online by default, increments the total number of peers, assigns it as the peer's ID, and creates a new Map object with the given Map of `PodcastEpisodes`.
- `void joinNetwork(KuPodcastNet network)`: Sets the `KuPodcastNet` object and calls that object's `registerPeer` method.
- `boolean hasTrack(PodcastEpisode track)`: Returns true if this peer has the given track, false otherwise.
- `void receiveTrack(PodcastEpisode track)`: Adds the given track to this peer's tracks Map.
- `String toString()`: Returns a string representation of the peer, including its ID, name, and status (check the sample output).
- `boolean downloadTrack(String name)`: Downloads the track with the given name from the network. Returns true if the download is successful, false otherwise. The download will be unsuccessful if:
    - The corresponding Peer hasn't joined the network yet.
    - The corresponding Track does not exist in the network.
    - The corresponding Peer already has the track.

In all cases, the application should display a proper message (Check the sample output for the messages).
   - Successful downloading:
      - “Peer1 tries to download Track2”
      - “Peer1 Downloading track: Track2”
      - “Track2 has been downloaded by Peer1”
   - Already exists:
      - “Peer1 tries to download Track4”
      - “Peer1 already has the track: Track4 Skipping download.”
   - Doesn’t exist in the network:
      - “Peer1 tries to download Track5”
      - “Track5 Track does not exist in the network, download was aborted.”
    


## Sample output
```
Peer1 tries to download Track2
Peer1 Downloading track: Track2
Track2 has been downloaded by Peer1

Peer1 tries to download Track4
Peer1 already has the track: Track4 Skipping download.

Peer1 tries to download Track5
Track5 Track does not exist in the network, download was aborted.

Peer2 tries to download Track3
Peer2 Downloading track: Track3
Track3 has been downloaded by Peer2

Peer3 tries to download Track3
Peer3 Peer hasn't joined the network yet, download aborted.

Peer 1 Info:
Peer ID: 1
Name: Peer1
Status: Online

Peer 2 Info:
Peer ID: 2
Name: Peer2
Status: Online
```
