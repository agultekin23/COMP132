/************** Pledge of Honor ******************************************
I hereby certify that I have completed this programming project on my own without
any help from anyone else. The effort in the project thus belongs completely to me.
I did not search for a solution, or I did not consult any program written by others
or did not copy any program from other sources. I read and followed the guidelines
provided in the project description.
READ AND SIGN BY WRITING YOUR NAME SURNAME AND STUDENT ID
SIGNATURE: <Adnan Gültekin, 86816>
*************************************************************************/
package main;

import fileIo.FileHandler;
import gamePlaces.Ecosystem;
import modesAndEcosystems.GameManager;
import view.GameWindow;
import view.StartScreen;

public class Main {
    public static void main(String[] args) {
        Object[] setup = StartScreen.showSetup();
        if (setup == null) return;

        StartScreen.showGameInfo(); 

        if (setup[0].equals("LOAD")) {
            FileHandler gh = new FileHandler();
            gh.importFile("savegame.txt");
            Ecosystem loadedEco = new Ecosystem(gh.gridSize); 
            GameManager gm = new GameManager(gh.era, gh.gridSize, gh.totalRounds, loadedEco);
            gm.savedData(gh); 
            new GameWindow(gm, gh.gridSize);
        } else {
            int size = (int) setup[0];
            int rounds = (int) setup[1];
            String era = (String) setup[2];
            Ecosystem eco = new Ecosystem(size);
            GameManager gm = new GameManager(era, size, rounds, eco);
            new GameWindow(gm, size);
        }
    }
}