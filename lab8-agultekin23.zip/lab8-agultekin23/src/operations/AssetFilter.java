package operations;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import asset.Asset;
import asset.ServiceDueAsset;

public class AssetFilter {
	
	public Map<String, Double> removeBasedOnValue(Map<String, Double> assetValues, int threshold){
		Map<String, Double> Map2 = new LinkedHashMap<>();
		
		for (Map.Entry<String, Double> number : assetValues.entrySet()) {			
			if(number.getValue() >= threshold) {
			Map2.put(number.getKey(), number.getValue()*2);
		}}
		return Map2;

	}
	
	public <T extends Comparable<T>> T findMaximum(List<T> assets) {
		if (assets == null) {
	        return null;
	    }if(assets.isEmpty()==true){
	        return null; 

	    }
		return Collections.max(assets);
	}
	
	public <T extends Comparable<T>> List<T> orderByAscending(List<T> list){
		Collections.sort(list);
		return list;
	}
	
	public <T extends Asset> List<T> applyDepreciation(List<T> assets, int rate){
		double newRate = (100-rate) * 0.01; // /100 sıkıntı çıkardığı için 0.01 ile çarptım. 
		for(T asset : assets) {
			double newUnitValue = asset.getUnitValue() * newRate;
			asset.setUnitValue(newUnitValue);
		}
		return assets;
	}
	
	public <T extends ServiceDueAsset> void removeInvalidServiceDates(List<T> assets, AssetManager manager) {
		for(T asset : assets) {
			if (isValidServiceDate(manager)==false) {
				assets.remove(indexOf(asset));
			}
		}
	}

	public List<ServiceDueAsset> removeOverdue(List<ServiceDueAsset> exAssets, String string) {
		// TODO Auto-generated method stub
		return null;
	}
	

}







