package operations;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import asset.CampusAsset;
import asset.ServiceDueAsset;

public class AssetManager {
	
	private static final Pattern ASSET_TAG_PATTERN = Pattern.compile("^[A-Z]{2}[0-9]{4}[*#@]$");
	private static final Pattern SERVICE_DATE_PATTERN = Pattern.compile("\\d{4}-([0][0-9]|[1][0-2])-([0][1-9][1][0-9][2][0-9][3][0-1])");
	
	public boolean isAssetTagValid(CampusAsset asset) {
		if(asset.getAssetTag()==null) {
			return false;
		}
		
		if (asset.getAssetTag().length() != 7) {
	        return false;
	    }
		
		if(ASSET_TAG_PATTERN.matcher(asset.getAssetTag()).matches()==true) {
			return true;
		}else {
			return false;
		}}
	
	public String generateAssetCode(CampusAsset asset) {
		String assetName = asset.getAssetName();
		String assetTag = asset.getAssetTag();
		
		String sb = new StringBuilder(assetName.substring(0,3)).reverse().toString().toUpperCase();
		String id = assetTag.substring(4,6);
		
		char middleLetter = assetTag.charAt(3); //tek de olsa çift de olsa sonuç 3 çıkıyor o yüzden 3'e eşitleyebiliriz. 
		
		
		return sb+id+middleLetter;
	}
	
	public Map<String, Double>assetValueCalc(List<CampusAsset> assets){
		Map<String, Double> Map1 = new LinkedHashMap<>();
		
		for(CampusAsset asset: assets) {
			double totalAsset = asset.getUnitValue() * asset.getUnitsAvailable();
			Map1.put(asset.getAssetName(), totalAsset);
		}
		return Map1;
		
	}
		public boolean isValidServiceDate(String dateStr) {
			Matcher m = ASSET_TAG_PATTERN.matcher(dateStr);
			return m.matches();
		}



	    public <T extends ServiceDueAsset> void removeInvalidServiceDates(List<T> assets, AssetManager manager) {
	        List<T> resultList = new ArrayList<T>(assets);
	        
	        		for(ServiceDueAsset a : resultList) {
	        			if(!manager.isValidServiceDate()) {
	        				assets.remove(a);
	        				
	        			}
	        		}
	    }


	    public <T extends ServiceDueAsset> List<T> removeOverdue(List<T> assets, String date) {
	        List<T> resultList = new ArrayList<T>();
	        
	        	for (int i = 0; i < assets.size(); i++) {
	        		T asset = assets.get(i);
	           
	        		if (asset.setServiceDueDate().compareTo(date) >= 0) {
	                resultList.add(asset);
	            }
	        }
	        
	        return resultList;
	    }

	    public <T> void reverse(List<T> list) {
	        int size = list.size();
	  	        for (int i = 0; i < size; i++) {
	  	        	T a = list.get(i);
	  	        	

	        }
	  	        
	    }
	    
	    
	}
	
	
	
	

	
	



