package asset;

public class ServiceDueAsset extends Asset{
	private String assetTag;
	private String assetName;
	private int unitsAvailable;
	private String serviceDueDate;
	public ServiceDueAsset(String assetTag, String assetName, double unitValue, int unitsAvailable, String serviceDueDate) {
		super(unitValue);
		this.serviceDueDate = serviceDueDate;
		this.assetTag = assetTag;
		this.assetName = assetName;
		this.unitsAvailable = unitsAvailable;
		
	}
	
	public String toString() {
		return String.format("Tag: %s, Name: %s, UnitValue: %.2f, Units: %d, Service Due: %s", assetTag, assetName, unitValue, unitsAvailable, serviceDueDate);

	}

	public String getAssetTag() {
		return assetTag;
	}

	public void setAssetTag(String assetTag) {
		this.assetTag = assetTag;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public int getUnitsAvailable() {
		return unitsAvailable;
	}

	public void setUnitsAvailable(int unitsAvailable) {
		this.unitsAvailable = unitsAvailable;
	}

	public String getServiceDueDate() {
		return serviceDueDate;
	}

	public void setServiceDueDate(String serviceDueDate) {
		this.serviceDueDate = serviceDueDate;
	}
	
	
}
 