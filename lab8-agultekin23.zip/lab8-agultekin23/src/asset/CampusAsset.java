package asset;

public class CampusAsset extends Asset{
	
	private String assetTag;
	private String assetName;
	private String assetCode;
	private int unitsAvailable;

	public CampusAsset(String assetTag, String assetName, double unitValue, int unitsAvailable) {
		super(unitValue);
		this.assetTag = assetTag;
		this.assetName = assetName;
		this.unitsAvailable = unitsAvailable; 
	
	}

	public String toString() {
	    return String.format("Tag: %s, Name: %s, Code: %s, UnitValue: %.2f, Available quantity: %d", assetTag, assetName, assetCode, unitValue, unitsAvailable);
	}

	public void setAssetTag(String assetTag) {
		this.assetTag = assetTag;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public void setAssetCode(String assetCode) {
		this.assetCode = assetCode;
	}

	public void setUnitsAvailable(int unitsAvailable) {
		this.unitsAvailable = unitsAvailable;
	}

	public String getAssetTag() {
		return assetTag;
	}

	public String getAssetName() {
		return assetName;
	}

	public String getAssetCode() {
		return assetCode;
	}

	public int getUnitsAvailable() {
		return unitsAvailable;
	}

}
