package asset;

public abstract class Asset implements Comparable<Asset>{
	
	protected double unitValue;
	
	public double getUnitValue() {
		return unitValue;
	}

	public void setUnitValue(double unitValue) {
		this.unitValue = unitValue;
	}

	public Asset(double unitValue) {
		this.unitValue = unitValue;
	}
	public int compareTo(Asset o) {
	    if (this.unitValue < o.unitValue) {
	        return -1;
	    } else if (this.unitValue > o.unitValue) {
	        return 1;
	    } else {
	        return 0;
	    }
	}
	
	

}
