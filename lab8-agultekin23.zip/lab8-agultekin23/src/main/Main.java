/* *********** Pledge of Honor ************************************************ *

I hereby certify that I have completed this lab assignment on my own
without any help from anyone else. I understand that the only sources of authorized
information in this lab assignment are (1) the course textbook, (2) the
materials posted on the course website, and (3) any study notes handwritten by myself.
I have not used, accessed, or received any information from any other unauthorized
source in taking this lab assignment. The effort in the assignment thus belongs
completely to me.
READ AND SIGN BY WRITING YOUR NAME SURNAME, AND STUDENT ID
SIGNATURE: <Adnan Gültekin, 86816>
********************************************************************************/
package main;

import asset.*;
import operations.*;
import util.*;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        String filePath = "src/assets.txt";
        AssetManager manager = new AssetManager();

        List<CampusAsset> assets = AssetFileUtils.readCampusAssets(filePath, manager);

        List<Asset> genericAssets = new ArrayList<>(assets);

        System.out.println("\nAll Campus Assets:");
        for (CampusAsset asset : assets)
            System.out.println(asset);


        // calculate total values
        Map<String, Double> values = manager.assetValueCalc(assets);
        System.out.println("\nAsset Values:");
        for (Map.Entry<String, Double> e : values.entrySet())
            System.out.println(e.getKey() + ": " + e.getValue());


        // filter and transform
        AssetFilter filter = new AssetFilter();
        Map<String, Double> filtered = filter.removeBasedOnValue(values, 100);
        System.out.println("\nFiltered (>=threshold=100) and adjusted for reporting:");
        for (Map.Entry<String, Double> e : filtered.entrySet())
            System.out.println(e.getKey() + ": " + e.getValue());

        // order by ascension
        System.out.println("\nOrdering by unit value (ascending): ");
        filter.orderByAscending(genericAssets);
        for (Object o : genericAssets)
            System.out.println(o);

        // find maximum unitValued asset
        CampusAsset mostExpensive = (CampusAsset) filter.findMaximum(genericAssets);
        System.out.println("\nHighest unit-value asset: " + mostExpensive);

        System.out.println("\nAssets before depreciation:");
        for (Object o : genericAssets)
            System.out.println(o);


        //
        filter.applyDepreciation(genericAssets, 20);
        System.out.println();

        System.out.println("\nAssets after depreciation:");
        for (Object o : genericAssets)
                System.out.println(o);

        System.out.println("\n---------------------INLAB---------------------");
        List<ServiceDueAsset> exAssets = new ArrayList<>();
        exAssets.add(new ServiceDueAsset("EL1234*", "GPU Workstation", 2.50,
        30, "2025-06-01"));
        exAssets.add(new ServiceDueAsset("CL5678#", "Oscilloscope", 8.00, 20,
        "30-05-2025"));
        exAssets.add(new ServiceDueAsset("FO9012#", "Tablet", 3.00, 6,
        "2025-5-12"));
        exAssets.add(new ServiceDueAsset("DX3456*", "3D Printer", 7.00, 15,
        "2026-01-30"));
        exAssets.add(new ServiceDueAsset("EB7890@", "Sensor Kit", 13.00, 12,
        "2025-12-31"));
        filter.removeInvalidServiceDates(exAssets, manager);

        System.out.println("\nExpirable assets after checking validity: ");
        for (Object o : exAssets)
        System.out.println(o);
        System.out.println("\nRemoving expired assets.");
        exAssets = filter.removeOverdue(exAssets, "2025-05-23");
        System.out.println("\nExpirable assets before depreciation: ");
        for (Object o : exAssets)
        System.out.println(o);
        filter.applyDepreciation(exAssets, 20);
        System.out.println("\nExpirable assets after depreciation: ");
        for (Object o : exAssets)
        System.out.println(o);
        List<Asset> mixedAssets = new ArrayList<>();
        mixedAssets.addAll(genericAssets);
        mixedAssets.addAll(exAssets);
        System.out.println("\nMixed List after reversal: ");
        filter.reverse(mixedAssets);
        for (Object o : mixedAssets)
        System.out.println(o);        }
    }
