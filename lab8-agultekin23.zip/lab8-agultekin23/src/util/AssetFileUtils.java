package util;

import asset.CampusAsset;
import operations.AssetManager;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class AssetFileUtils {
    public static List<CampusAsset> readCampusAssets(String filePath, AssetManager manager) {
        List<CampusAsset> assets = new ArrayList<>();
        try (Scanner scanner = new Scanner(new File(filePath))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] words = line.split(",");
                
                try {
                    if (words.length != 4) throw new Exception();

                    String word1 = words[0];
                    String word2 = words[1];
                    double word3 = Double.parseDouble(words[2]);
                    int word4 = Integer.parseInt(words[3]);

                    CampusAsset asset = new CampusAsset(word1, word2, word3, word4);

                    if (manager.isAssetTagValid(asset)) {
                        String code = manager.generateAssetCode(asset);
                        asset.setAssetCode(code);
                        assets.add(asset);
                    } else {
                        System.out.println("Skipping malformed or invalid line: " + line);
                    }
                } catch (Exception e) {
                    System.out.println("Skipping malformed or invalid line: " + line);
                }
            }
        } catch (FileNotFoundException e) {
            return null;
        }
        return assets;
    }
}
	

