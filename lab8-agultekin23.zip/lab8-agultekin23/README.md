[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/nO0xGvK9)
# COMP132, Fall2025, Lab 8 Prelab

# IMPORTANT

For each lab assignment, **you must include and sign (by writing your name and student ID number) the following Pledge of Honor statement at the beginning of your main method source code file. After including this statement, make sure that you do the commit and push operation on GitHub. Otherwise, your lab solution will not be graded.**
```
/* *********** Pledge of Honor ************************************************ *

I hereby certify that I have completed this lab assignment on my own
without any help from anyone else. I understand that the only sources of authorized
information in this lab assignment are (1) the course textbook, (2) the
materials posted on the course website, and (3) any study notes handwritten by myself.
I have not used, accessed, or received any information from any other unauthorized
source in taking this lab assignment. The effort in the assignment thus belongs
completely to me.
READ AND SIGN BY WRITING YOUR NAME SURNAME, AND STUDENT ID
SIGNATURE: <Name Surname, Student id>
********************************************************************************/
```
## Please carefully review the following important notes. Violating each one of them will result in a grade deduction.

## IMPORTANT NOTES: 

   ##### :pushpin: - All instance variables MUST have the exact name written in the instructions.
   ##### :pushpin: - You should implement getter/setter methods whenever needed (for example, if you are going to access the instance variables from other classes). You may use auto-generator for getter/setter methods (under the Source menu in Eclipse). Do NOT implement unused Getter/Setter methods. You will be penalized for each unused Getter/Setter.
   ##### :pushpin: -  You MUST follow the instructions (Package name, Class name, method name, variables, ...) so carefully. The packages, classes, instance variables, and methods MUST be created following the descriptions given in the assignment.
   ##### :pushpin: -  Please check the sample output provided at the end of this assignment. Your output MUST be exactly the same as the provided sample output.
   ##### :pushpin: -  After you complete the tasks, do not forget to commit your changes and push them to your repository on GitHub BEFORE 9.30 :clock930: AM, Friday.
   ##### :pushpin: -  This README.md file only contains the instructions for PRELAB. You will also have INLAB questions.

  # Lab 8 Prelab: Campus IT and Lab Equipment Unified Asset Management System
  
  This programming lab focuses on data validation using **Regular Expressions** and **Generics**. The assignment aims to enhance your understanding of Regular Expressions and Generics by implementing an asset management system that validates, filters, and retrieves assets.

<div align="center">
  <img src="/img/img.png" alt="image" />
</div>

  Modern universities manage a wide range of high-value assets, including scientific laboratory instruments and research computing devices such as workstations, sensors, tablets, and specialized hardware. These assets are shared across departments and research groups, making accurate tracking, validation, and auditing essential.
  In this lab, you will implement a Unified Asset Management System that validates asset records, standardizes asset codes, calculates asset values, and filters equipment based on predefined criteria. The system must ensure that all registered assets follow strict institutional identification rules and support safe, type-checked operations across different asset collections.

  Each asset record includes:

- A formally structured asset ID assigned by the university
- A descriptive asset name
- A system-generated asset code
- A unit value
- A quantity representing available units

## Requirements

- Use Regular Expressions.
- Use Generics for implementing type-safe operations.
- Do ***not*** use lambda expressions or streams.
- Add getter/setter methods when applicable.

You are provided with the **Main.java** file and an input text file. Check the main file to understand the sample output better and how each method and field is used. You need to develop your assignment by following the instructions below.

## Package Structure
```
src/ 
   - main/
      - Main.java 
      - assets.txt
   - asset/
      - CampusAsset.java
      - Asset.java
   - operations/ 
      - AssetManager.java
      - AssetFilter.java 
   - util/ 
      - AssetFileUtils.java
```
## asset package:

## Asset Class

This class is an abstract class that must implement the generic Comparable interface of Collections.

### Instance Variable:
- `double unitValue`: UnitValue of the asset.

### Method:
- `public Asset(double unitValue)`: Constructor for the Asset class.

## CampusAsset Class

This class must extend Asset. 

### Instance Variables:
- `String assetTag`: Unique identifier for the asset.
- `String assetName`: Name of the asset.
- `String assetCode`: Code of the asset.
- `int unitsAvailable`: Quantity available in the stock.

### Methods:
- `public CampusAsset(String assetTag, String assetName, double unitValue, int unitsAvailable)`: The constructor initializes the campus asset with the necessary information.
- `toString()`: Displays asset details in the given format.

#### Sample Output:
```Tag: AB1234*, Name: SmartWatch, Code: AMS342, UnitValue: 10.00, Available quantity: 20```

## operations package:

## AssetManager Class

### Instance Variable:
- `private static final Pattern ASSET_TAG_PATTERN = Pattern.compile("your_regex_here")`: Pattern to match.

### Methods:
- `public boolean isAssetTagValid(CampusAsset asset)`:Validates the asset Tag using the following rules (implemented via Regular Expressions):
    - Starts with 2 uppercase letters.
    - Followed by 4 digits.
    - Ends with a special character from `(*, #, @)` only.
    - The total length of the characters should be exactly 7.
  Returns true if the item ID is valid and false otherwise.

- `public String generateAssetCode(CampusAsset asset)`: Generates a unique code based on the item’s properties based on the following:
  - The first three letters of the item name in reverse in uppercase.
  - The last two digits of the digit part of the item ID.
  - The middle letter of the item ID. (For even IDs, take the ceiling.)
  - It should return the generated code.

- `public Map<String, Double>assetValueCalc(List<CampusAsset> assets)`:
  - Calculates the total value  (`price x quantity`) of each item in the asset
  - Returns a map where keys are the item names and the values are the values of the items.

## AssetFilter Class

### Methods:
- `public Map<String, Double> removeBasedOnValue(Map<String, Double> assetValues, int threshold)`: Filters and transforms the asset list based on a threshold `n`. It should remove any entry from the map where the asset value is less than the specified integer `n`. For each remaining asset, `(i.e., >= n)`, the value of that asset is doubled. It returns a new `Map<String, Double>` containing only the filtered and transformed assets.

- `public <T extends Comparable<T>> T findMaximum(List<T> assets)`: A method to return the highest value in the list.

- `public <T extends Comparable<T>> List<T> orderByAscending(List<T> list)`: A method to compare assets based on `unitValue` in ascending order. Two assets with the same `unitValue` are considered equal. Implement any necessary method before implementing this one.

- `public <T extends Asset> List<T> applyDepreciation(List<T> assets, int rate)`: Takes a list of assets and applies a depreciation on it based on an input value rate. The unit value is decreased according to the specified rate.

## util package:

## AssetFileUtils Class

### Methods:
- `public static List<CampusAsset> readCampusAssets(String filePath, AssetManager manager)`:
   - Using Scanner class methods, reads the `assets.txt` and parses the line expecting the format: `assetTag`, `assetName`, `unitValue`, `unitsAvailable`. 
   - Validates the `assetTag` using the `isAssetTagValid()` method from `AssetManager`. It should generate a unique `assetCode` using the `generateAssetCode()` method and insert it after assetName to the appropriate field, namely `assetCode`. The structure should be as follows: `assetTag`, `assetName`, `assetCode`, `unitValue`, and `unitsAvailable`. 
   - Constructs a `CampusAsset` using the updated and validated information. 
   - Skips any malformed or invalid entries and logs a warning message: “Skipping malformed or invalid asset record: [asset record]”.
   - Returns a list of all successfully parsed and validated `CampusAsset` objects.


## main package

## Main.java

The provided **Main class** will test the implementation. You should add the **pledge of honor** to it. Any change more than that may lead to grade reduction.


## Sample output
```
Skipping malformed or invalid line: IJ7890*,WorkStation,11.0,5,3
Skipping malformed or invalid line: INVALID,Asset,1.0,1

All Campus Assets:
Tag: AB1234*, Name: SmartWatch, Code: AMS342, UnitValue: 10.00, Available quantity: 20
Tag: CD5678#, Name: Computer, Code: MOC786, UnitValue: 5.00, Available quantity: 50
Tag: EF9012@, Name: Phone, Code: OHP120, UnitValue: 25.00, Available quantity: 3
Tag: GH3456#, Name: Headset, Code: AEH564, UnitValue: 12.00, Available quantity: 10

Asset Values:
SmartWatch: 200.0
Computer: 250.0
Phone: 75.0
Headset: 120.0

Filtered (>=threshold=100) and adjusted for reporting:
SmartWatch: 400.0
Computer: 500.0
Headset: 240.0

Ordering by unit value (ascending): 
Tag: CD5678#, Name: Computer, Code: MOC786, UnitValue: 5.00, Available quantity: 50
Tag: AB1234*, Name: SmartWatch, Code: AMS342, UnitValue: 10.00, Available quantity: 20
Tag: GH3456#, Name: Headset, Code: AEH564, UnitValue: 12.00, Available quantity: 10
Tag: EF9012@, Name: Phone, Code: OHP120, UnitValue: 25.00, Available quantity: 3

Highest unit-value asset: Tag: EF9012@, Name: Phone, Code: OHP120, UnitValue: 25.00, Available quantity: 3

Assets before depreciation:
Tag: CD5678#, Name: Computer, Code: MOC786, UnitValue: 5.00, Available quantity: 50
Tag: AB1234*, Name: SmartWatch, Code: AMS342, UnitValue: 10.00, Available quantity: 20
Tag: GH3456#, Name: Headset, Code: AEH564, UnitValue: 12.00, Available quantity: 10
Tag: EF9012@, Name: Phone, Code: OHP120, UnitValue: 25.00, Available quantity: 3


Assets after depreciation:
Tag: CD5678#, Name: Computer, Code: MOC786, UnitValue: 4.00, Available quantity: 50
Tag: AB1234*, Name: SmartWatch, Code: AMS342, UnitValue: 8.00, Available quantity: 20
Tag: GH3456#, Name: Headset, Code: AEH564, UnitValue: 9.60, Available quantity: 10
Tag: EF9012@, Name: Phone, Code: OHP120, UnitValue: 20.00, Available quantity: 3
```






  
