package characters;

public class moveException extends Exception{
	
	/*
	 * moveException class is to not get an error if the character moves wrong. 
	 * It takes a message as parameter.
	 */
	public moveException(String message) {
        super(message);
    }

}
