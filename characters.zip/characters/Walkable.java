package characters;

public interface Walkable {
	
	/*
	 * moveTo and specialAbilty are the methods that common for all characters. They are used by characters commonly. 
	 */
	public void moveTo(int targetR, int targetC);	
	public void specialAbility(int targetR, int targetC);
}
