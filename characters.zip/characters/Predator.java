package characters;

public class Predator extends Characters {
    public Predator(String charactersName, int locationX, int locationY) {
        super(charactersName, locationX, locationY);
    }

    @Override
    /*
     * overriden method moveTo It is inherited from Walkable Interface
     * since moveTo and specialAbility is common for all characters it is used by characters
     */
    public void moveTo(int targetR, int targetC) {
        this.setLocationX(targetR);
        this.setLocationY(targetC);
    }

    @Override
    /*
     * overriden method specialAbility It is inherited from Walkable Interface
     * since moveTo and specialAbility is common for all characters it is used by characters
     */
    public void specialAbility(int targetR, int targetC) {
        this.setLocationX(targetR);
        this.setLocationY(targetC);
    }
}