package characters;

public abstract class Characters {
    private String charactersName;
    private int locationX;
    private int locationY;
    private int score = 0;
    private int cooldown = 0;
    
    /*
     * this is the constructor of characters class.
     * It takes parameters as charactersName, locationX and locationY
     */
    public Characters(String charactersName, int locationX, int locationY) {
    	this.charactersName = charactersName; 
    	
    	this.locationX = locationX; 
    	
    	this.locationY = locationY; }
    
    /*
     * It updates cooldown if it greater than 0 since it should be decrease after movement
     */

    public void updateCooldown() {
    	
    	if (cooldown > 0) {
    		cooldown--; 
    	}
    	
    } 
    
    /*
     * It checks if the cooldown is 0 or not. If it is 0 we can use ability
     */
    
    public boolean canUseAbility() { 
    	
    	return cooldown == 0; 
    	
    	}
    /*
     * It uses moveTo and specialAbility methods as abstract since chracaters' class(like prey) are inherited from that class.
     */
   
	public abstract void moveTo(int targetR, int targetC);	
    
	public abstract void specialAbility(int targetR, int targetC);

	/*
	 * getter and setters methods
	 */
	
	public String getCharactersName() {
		return charactersName;
	}

	public void setCharactersName(String charactersName) {
		this.charactersName = charactersName;
	}

	public int getLocationX() {
		return locationX;
	}

	public void setLocationX(int locationX) {
		this.locationX = locationX;
	}

	public int getLocationY() {
		return locationY;
	}

	public void setLocationY(int locationY) {
		this.locationY = locationY;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public int getCooldown() {
		return cooldown;
	}

	public void setCooldown(int cooldown) {
		this.cooldown = cooldown;
	}


}