package characters;

public class ApexPredator extends Characters {
	/*
	 * constructor of apexPredator class and it takes parameters as charactersName, locationX, locationY.
	 * It does not return but calls the super of superclass.
	 */
    public ApexPredator(String charactersName, int locationX, int locationY) {
        super(charactersName, locationX, locationY);
    }

    @Override
    /*
     * overriden method moveTo It is inherited from Walkable Interface
     * since moveTo and specialAbility is common for all characters it is used by characters
     */
    public void moveTo(int targetR, int targetC) {
        this.setLocationX(targetR);
        this.setLocationY(targetC);
    }

    @Override
    /*
     * overriden method specialAbility It is inherited from Walkable Interface
     * since moveTo and specialAbility is common for all characters it is used by characters
     */
    public void specialAbility(int targetR, int targetC) {
        this.setLocationX(targetR);
        this.setLocationY(targetC);
    }
    
    
}