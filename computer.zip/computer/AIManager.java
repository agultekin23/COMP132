package computer;

import java.util.List;
import characters.*;
import gamePlaces.*;
import modesAndEcosystems.EraSettings;

public class AIManager {

	/*
	 * it takes some parameters and defines an object from characters class then it checks if it can use ability after that it record the best movement as array
	 * And it decides the apex's movement. after that if the era is past it organizes the approach logic. Since it is a void method there is no return(empty returns are allowed in void methods.).
	 */

    public static void handleApexTurn(ApexPredator apex, List<Prey> preys, List<Predator> preds, String era, Ecosystem eco) {
        Characters aim = getClosest(apex, preys, preds);
        
        if(aim == null) {
        	return;
        }
        int range = 1; 
        if (apex.canUseAbility()) {
            range = EraSettings.getAbilityDistance("Apex", era);
        }

        int[] bestMove = FindBestDecision.getApexMove(apex, preys, preds, range, eco);
        
        if (era.equalsIgnoreCase("Past") && range > 1) {
            if (bestMove[0] != apex.getLocationX() && bestMove[1] != apex.getLocationY()) {
                approach(apex, aim.getLocationX(), aim.getLocationY(), eco);
                return;
            }
        }

        moveTo(apex, bestMove[0], bestMove[1], eco);
    }
    /*
     * It takes some parameters. Logic is based on how to prey move. The logic is same with handleApexTurn it records bestMove to an array and it decides tue prey's move.
     * since it is void method there is no returned value.
     */
    public static void handlePreyTurn(Prey prey, List<Predator> preds, List<ApexPredator> apexes, List<Food> foods, String era, Ecosystem eco) {
        int range = 1;
        if (prey.canUseAbility()) {
            range = EraSettings.getAbilityDistance("Prey", era);
        }

        int[] bestMove = FindBestDecision.getPreyMove(prey, preds, apexes, foods, range, eco);
        moveTo(prey, bestMove[0], bestMove[1], eco);
    }

    /*
     * this method is relevant with obstacles in my game. When you play game you can easily see obstacles as fire images. 
     * firstly it decides the limit movement value and targets. after that if it is not an obstacle you can move that grid. Since it is void there is no return.
     */
    private static void moveTo(Characters c, int x, int y, Ecosystem eco) {
        int lim = eco.getGridSize() - 1;
        int targetX = Math.max(0, Math.min(lim, x));
        int targetY = Math.max(0, Math.min(lim, y));

        if (!eco.getGrid()[targetX][targetY].isObstacle()) {
            c.setLocationX(targetX);
            c.setLocationY(targetY);
        }
    }
    /*
     * the logic in approach method is move in a straight line especially for apex.
     * there is no return value.
     */

    private static void approach(Characters c, int tx, int ty, Ecosystem eco) {
        int nx = c.getLocationX();
        int ny = c.getLocationY();
        if (tx > nx) {
        	nx++; 
        }
        else if (tx < nx) {
        	nx--;
        }
        if (ty > ny) {
        	ny++; 
        }
        else if (ty < ny) {
        	ny--;
        }
        moveTo(c, nx, ny, eco);
    }
    /* this method finds the distance for possible movement. To sense same as diagonals and straight movement I had to use that formula.
     * it returns double distance value.
     */
    private static double findDistance(int x1, int y1, int x2, int y2) {
        double d = Math.max(Math.abs(x1 - x2), Math.abs(y1 - y2));
        return d;
    }

    /*
     * It takes one characters object and two generic List objects which extends characters class. It sets minD as double max_value -like infinity- to use correctly. Sİnce all the other reel values smaller than infinity algorithm will work correctly.
     * by that way algorithm finds the min distance and closest point. and it returns closest point.
     */
    private static Characters getClosest(Characters source, List<? extends Characters> l1, List<? extends Characters> l2) {
        Characters closest = null;
        double minD = Double.MAX_VALUE;
        if (l1 != null) {
            for (Characters c : l1) {
                double d = findDistance(source.getLocationX(), source.getLocationY(), c.getLocationX(), c.getLocationY());
                if (d < minD) {
                	minD = d; 
                	closest = c; 
                	}
            }
        }
        if (l2 != null) {
            for (Characters c : l2) {
                double d = findDistance(source.getLocationX(), source.getLocationY(), c.getLocationX(), c.getLocationY());
                if (d < minD) { 
                	minD = d; 
                	closest = c; 
                	}
            }
        }
        return closest;
    }
}