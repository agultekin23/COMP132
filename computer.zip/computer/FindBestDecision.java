package computer;

import java.util.List;
import characters.*;
import gamePlaces.Ecosystem;
import gamePlaces.Food;

public class FindBestDecision {
	/*
	 * It takes points as parameters which it will calculate the distance. I used same Logic in AIManager class findDistance method. To specify easily I also wrote that another method but same functionality. 
	 * it returns distance 
	 */

    public static int getDistance(int x1, int y1, int x2, int y2) {
        int d = Math.max(Math.abs(x1 - x2), Math.abs(y1 - y2)); 
        return d;
    }
    /*
     * It works for prey actually. It identifies the nearest threat. In my algorithm I specified the threatDist importance against foodDist 1.5k. Which means run and live is 1.5k more important than scoring.
     * It calculates the position score and at the end it decides how to move by position score
     */
    public static int[] getPreyMove(Prey prey, List<Predator> predators, List<ApexPredator> apexList, List<Food> foods, int moveRange, Ecosystem eco) {
        int preyX = prey.getLocationX();
        int preyY = prey.getLocationY();
        int gridSize = eco.getGridSize();
        
        int bestX = preyX;
        int bestY = preyY;
        double bestScoreSoFar = Double.NEGATIVE_INFINITY;
        
        Characters closestThreat = findNearestEnemy(prey, predators, apexList);
        Food closestFood = findNearestFood(prey, foods);
        
        int minX = Math.max(0, preyX - moveRange);
        int maxX = Math.min(gridSize - 1, preyX + moveRange);
        int minY = Math.max(0, preyY - moveRange);
        int maxY = Math.min(gridSize - 1, preyY + moveRange);
        
        for (int candidateX = minX; candidateX <= maxX; candidateX++) {
            for (int candidateY = minY; candidateY <= maxY; candidateY++) {
                
                if (eco.getGrid()[candidateX][candidateY].isObstacle()) {
                    continue; 
                }

                double threatDist = 0.0;
                double foodDist = 0.0;
                
                if (closestThreat != null) {
                    threatDist = getDistance(candidateX, candidateY, closestThreat.getLocationX(), closestThreat.getLocationY());
                } else {
                    threatDist = gridSize; 
                }
                
                if (closestFood != null) {
                    foodDist = getDistance(candidateX, candidateY, closestFood.getX(), closestFood.getY());
                }
                
                double positionScore = (threatDist * 1.5) - foodDist;
                
                if (positionScore > bestScoreSoFar) {
                    bestScoreSoFar = positionScore;
                    bestX = candidateX;
                    bestY = candidateY;
                }
            }
        }
        return new int[]{bestX, bestY};
    }
    /*It is relevant with apex movement. It uses same logic with prey movement. But since there is no hunter for apex it just tries to eat something. 
     * There is possible candidate points and tehy are recorded to array. But in the last point it returns best candidates.
     */
    public static int[] getApexMove(ApexPredator apex, List<Prey> preys, List<Predator> predators, int range, Ecosystem eco) {
        int apexX = apex.getLocationX();
        int apexY = apex.getLocationY();
        int gridSize = eco.getGridSize();
        
        int bestX = apexX;
        int bestY = apexY;
        double shortestTargetDistance = Double.MAX_VALUE;
        
        Characters target = findClosestTarget(apex, preys, predators);
        
        if (target != null) {
            int minX = Math.max(0, apexX - range);
            int maxX = Math.min(gridSize - 1, apexX + range);
            int minY = Math.max(0, apexY - range);
            int maxY = Math.min(gridSize - 1, apexY + range);
            
            for (int candidateX = minX; candidateX <= maxX; candidateX++) {
                for (int candidateY = minY; candidateY <= maxY; candidateY++) {
                    
                    if (eco.getGrid()[candidateX][candidateY].isObstacle()) {
                    	continue;
                    }

                    double distance = getDistance(candidateX, candidateY, target.getLocationX(), target.getLocationY());
                    if (distance < shortestTargetDistance) {
                        shortestTargetDistance = distance;
                        bestX = candidateX;
                        bestY = candidateY;
                    }
                }
            }
        }
        return new int[]{bestX, bestY};
    }
    /*These three methods actually uses exactly same logic. for that method we find the nearestenemy by using getDistance we finded closest point. 
     * It returns closest enemies coordinates.
     */
    private static Characters findNearestEnemy(Characters source, List<Predator> preds, List<ApexPredator> apexes) {
        Characters closest = null;
        double minD = Double.MAX_VALUE;
        for (Predator p : preds) {
            double d = getDistance(source.getLocationX(), source.getLocationY(), p.getLocationX(), p.getLocationY());
            if (d < minD) { 
            minD = d; 
            closest = p; 
            }
        }
        for (ApexPredator a : apexes) {
            double d = getDistance(source.getLocationX(), source.getLocationY(), a.getLocationX(), a.getLocationY());
            if (d < minD) { 
            	minD = d; 
            	closest = a; }
        }
        return closest;
    }
    /*
     * Here we use same logic again we are trying to find nearestFood. At the end method returns closest food's coordinates.
     */

    private static Food findNearestFood(Characters source, List<Food> foods) {
        Food closest = null;
        double minD = Double.MAX_VALUE;
        for (Food f : foods) {
            double d = getDistance(source.getLocationX(), source.getLocationY(), f.getX(), f.getY());
            if (d < minD) {
            	minD = d; 
            	closest = f; 
            	}
        }
        return closest;
    }
    /*
     * Here we use same logic again we are trying to find closestTarget. At the end method returns closest food's coordinates.
     */

    private static Characters findClosestTarget(Characters source, List<Prey> preys, List<Predator> predators) {
        Characters closest = null;
        double minD = Double.MAX_VALUE;
        for (Prey p : preys) {
            double d = getDistance(source.getLocationX(), source.getLocationY(), p.getLocationX(), p.getLocationY());
            
            if (d < minD) { 
            	minD = d; 
            	closest = p; 
            	}
        }
        for (Predator pr : predators) {
            double d = getDistance(source.getLocationX(), source.getLocationY(), pr.getLocationX(), pr.getLocationY());
            
            if (d < minD) { 
            	minD = d; 
            	closest = pr; 
            	}
        }
        return closest;
    }
}