package exception;

public class InvalidSportEquipmentException extends Exception{
	public InvalidSportEquipmentException(String message) {
        super("SportEquipment is invalid because " + message);
    }
	
	


}
