package exception;

public class InvalidRentalException extends Exception{
	public InvalidRentalException(String message) {
        super("Rental is invalid because " + message);
    }

}
