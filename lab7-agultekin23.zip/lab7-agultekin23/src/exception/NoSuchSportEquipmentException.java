package exception;

public class NoSuchSportEquipmentException extends Exception {
	public NoSuchSportEquipmentException(String message) {
        super("Rental aborted because " + message);
    }
}
