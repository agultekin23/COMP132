package rental;

import exception.InvalidRentalException;
import sportEquipment.SportEquipment;

import java.time.LocalDate;

public class RentalValidator {
	
	public void validateDueDate(LocalDate dueDate) throws InvalidRentalException {
		if (dueDate.isBefore(LocalDate.now())) {
            throw new InvalidRentalException("the dueDate should be after the current date");
        }
	}
	public void validateIsAvailability(SportEquipment sportEquipment) throws InvalidRentalException{
		if(sportEquipment.isAvailable()==false) {
            throw new InvalidRentalException("The sportEquipment with code  " + sportEquipment.getCode() + "  is not available for rental.");

		}
	
}
	

	}
	
	


