package rental;

import sportEquipment.SportEquipment;
import sportEquipment.SportEquipmentValidator;
import exception.InvalidRentalException;
import java.time.LocalDate;

public class Rental {
	private String borrower;
	private SportEquipment sportEquipment;
	private LocalDate dueDate;
	boolean isReturned = false;
	
public Rental(String borrower, SportEquipment sportEquipment, LocalDate dueDate) throws InvalidRentalException{
	new RentalValidator().validateDueDate(dueDate);
	new RentalValidator().validateIsAvailability(sportEquipment);

	this.borrower = borrower;
	this.sportEquipment = sportEquipment;
	this.dueDate = dueDate;

}

public String getBorrower() {
	return borrower;
}

public SportEquipment getSportEquipment() {
	return sportEquipment;
}

public LocalDate getDueDate() {
	return dueDate;
}

public boolean isReturned() {
	return isReturned;
}

public void setBorrower(String borrower) {
	this.borrower = borrower;
}

public void setSportEquipment(SportEquipment sportEquipment) {
	this.sportEquipment = sportEquipment;
}

public void setDueDate(LocalDate dueDate) {
	this.dueDate = dueDate;
}

public void setReturned(boolean isReturned) {
	this.isReturned = isReturned;
}





}