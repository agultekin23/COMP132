package main;

import exception.InvalidSportEquipmentException;
import sportEquipment.SportEquipment;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Processor {
	
	public static void processInputFile(KUSportsHub kuSportsHub, String filePath) {
        File loadedFile = new File(filePath);
        
        try (Scanner scanner = new Scanner(loadedFile)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                
                if (line.isEmpty()) continue;

                ArrayList<String> words = new ArrayList<>();
                StringBuilder stringBuilder = new StringBuilder();

                for (int i = 0; i < line.length(); i++) {
                    char c = line.charAt(i);

                    if (c != ' ' && c != '\t') {
                    	stringBuilder.append(c);
                    } 
                    else if (stringBuilder.length() > 0) {
                    	words.add(stringBuilder.toString());
                    	stringBuilder.setLength(0); 
                    }
                }
                
                if (stringBuilder.length() > 0) {
                	words.add(stringBuilder.toString());
                }

                if (words.size() >= 3) {
                    try {
                        String code = words.get(0);
                        String type = words.get(1);
                        String owner = words.get(2);

                        SportEquipment sportEquipment = new SportEquipment(code, type, owner, true);
                        kuSportsHub.addSportEquipment(sportEquipment);
                    } catch (InvalidSportEquipmentException e) {
                        System.err.println(e.getClass().getSimpleName() + ": " + e.getMessage());
                    }
                }
            }
        } catch (FileNotFoundException e) {
            System.err.println("File not found: " + filePath);
        }
    }
		
	}


