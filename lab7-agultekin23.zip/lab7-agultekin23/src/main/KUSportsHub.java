package main;

import exception.*;
import rental.Rental;
import sportEquipment.SportEquipment;
import sportEquipment.SportEquipmentValidator;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

public class KUSportsHub {
	private String name;
    private HashMap<String, SportEquipment> sportEquipments;
    private ArrayList<Rental> rentals;

    public KUSportsHub(String name) {
        this.name = name;
        this.sportEquipments = new HashMap<>();
        this.rentals = new ArrayList<>();
    }

    public void addSportEquipment(SportEquipment sportEquipment) {
        sportEquipments.put(sportEquipment.getCode(), sportEquipment);
        System.out.println("SportEquipment added: " + sportEquipment.getSportEquipmentType() + ", Code: " + sportEquipment.getCode() + ", Owner: " + sportEquipment.getOwner());
    }

    public void borrowSportEquipment(String borrower, String code, LocalDate dueDate) 
            throws NoSuchSportEquipmentException, InvalidRentalException { 
        
        SportEquipmentValidator.validateExistence(sportEquipments, code, this.name);
        
        SportEquipment sportEquipment = sportEquipments.get(code);
        
        Rental rental = new Rental(borrower, sportEquipment, dueDate);
        
        sportEquipment.setAvailable(false);
        rentals.add(rental);
        
    }

    public void returnSportEquipment(String code) throws NoSuchSportEquipmentException {
        SportEquipmentValidator.validateExistence(sportEquipments, code, this.name);
        
        SportEquipment sportEquipment = sportEquipments.get(code);
        sportEquipment.setAvailable(true);
        
        for (Rental rental : rentals) {
            if (rental.getSportEquipment().getCode().equals(code) && !rental.isReturned()) {
            	rental.setReturned(true);
                break;
            }
        }
    }

    public void printAllRentals() {
        for (Rental rental : rentals) {
            System.out.println("Borrower: " + rental.getBorrower() + ", SportEquipment: " + 
            		rental.getSportEquipment().getCode() + ", Due Date: " + 
            		rental.getDueDate() + ", Returned: " + rental.isReturned());
        }
    }
    
    private String getBorrowerName(String code) {
        for (Rental rental : rentals) {
        	if(rental.getSportEquipment().getCode().equals(code)&& rental.isReturned()){
        		return rental.getBorrower();
        	}
        }
        return "";
    }
    
    private LocalDate getDueDate(String code) {
        for (Rental rental : rentals) {
        	if(rental.getSportEquipment().getCode().equals(code)&& !rental.isReturned()){
        		return rental.getDueDate();
        	}
        }
        return null;    	
    }
    
    public void printKUSportsHubCatalog() {
    	
    	
    	for (SportEquipment sportEquipment : sportEquipments.values()) {
    		if(sportEquipment.isAvailable()) {
    			
                System.out.println("SportEquipment type: " + sportEquipment.getSportEquipmentType() + 
    					", Code: " + sportEquipment.getCode() + 
    					", Status: " + sportEquipment.isAvailable());
    			
    		}else {
    			
    			System.out.println(		"SportEquipment type: " + sportEquipment.getSportEquipmentType() + 
    								", Code: " + sportEquipment.getCode() + 
    								", Status: " + sportEquipment.isAvailable() +
    								", Borrower: " + getBorrowerName(sportEquipment.getCode()) +                              
    								", Due Date: " + getDueDate(sportEquipment.getCode()));
    			
    		}

        }
    	
    }
    

	public void setName(String name) {
		this.name = name;
	}

	public void setSportEquipments(HashMap<String, SportEquipment> sportEquipments) {
		this.sportEquipments = sportEquipments;
	}

	public void setRentals(ArrayList<Rental> rentals) {
		this.rentals = rentals;
	}

	public String getName() {
		return name;
	}

	public HashMap<String, SportEquipment> getSportEquipments() {
		return sportEquipments;
	}

	public ArrayList<Rental> getRentals() {
		return rentals;
	}
	

}
