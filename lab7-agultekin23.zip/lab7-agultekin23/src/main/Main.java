/* *********** Pledge of Honor ************************************************ *

I hereby certify that I have completed this lab assignment on my own
without any help from anyone else. I understand that the only sources of authorized
information in this lab assignment are (1) the course textbook, (2) the
materials posted on the course website, and (3) any study notes handwritten by myself.
I have not used, accessed, or received any information from any other unauthorized
source in taking this lab assignment. The effort in the assignment thus belongs
completely to me.
READ AND SIGN BY WRITING YOUR NAME SURNAME, AND STUDENT ID
SIGNATURE: <Adnan Gültekin, 86816>
********************************************************************************/
package main;

import java.time.LocalDate;
import exception.*;

public class Main {
	public static void main(String[] args) throws InvalidSportEquipmentException {
		KUSportsHub kuSportsHub = new KUSportsHub("RF");
		Processor.processInputFile(kuSportsHub, "src/main/Input.txt");
		
		System.out.println("\n ----------  Borrows: ---------- ");
       try {
           String borrower = "Student-1";
           String code = "12345";
           LocalDate dueDate = LocalDate.of(2026, 01, 5);
           kuSportsHub.borrowSportEquipment(borrower, code, dueDate);
           System.out.println("Rental created: Borrower: " + borrower + ", SportEquipment: " + kuSportsHub.getSportEquipments().get(code).getSportEquipmentType() + ", Due date: " + dueDate);
           } catch (InvalidRentalException | NoSuchSportEquipmentException e) {
           System.out.println(e.getClass().getSimpleName() + ": " + e.getMessage());
          
       }
       try {
           String borrower = "Student-2";
           String code = "23456";
           LocalDate dueDate = LocalDate.of(2026, 01, 10);
           kuSportsHub.borrowSportEquipment(borrower, code, dueDate);
           System.out.println("Rental created: Borrower: " + borrower + ", SportEquipment: " + kuSportsHub.getSportEquipments().get(code).getSportEquipmentType() + ", Due date: " + dueDate);
           } catch (InvalidRentalException | NoSuchSportEquipmentException e) {
           System.out.println(e.getClass().getSimpleName() + ": " + e.getMessage());
          
       }
       try {
           String borrower = "Student-3";
           String code = "6789z";
           LocalDate dueDate = LocalDate.of(2026, 01, 10);
           kuSportsHub.borrowSportEquipment(borrower, code, dueDate);
           System.out.println("Rental created: Borrower: " + borrower + ", SportEquipment: " + kuSportsHub.getSportEquipments().get(code).getSportEquipmentType() + ", Due date: " + dueDate);
           } catch (InvalidRentalException | NoSuchSportEquipmentException e) {
           System.out.println(e.getClass().getSimpleName() + ": " + e.getMessage());
          
       }
       try {
           String borrower = "Student-4";
           String code = "34567";
           LocalDate dueDate = LocalDate.of(2026, 01, 25);
           kuSportsHub.borrowSportEquipment(borrower, code, dueDate);
           System.out.println("Rental created: Borrower: " + borrower + ", SportEquipment: " + kuSportsHub.getSportEquipments().get(code).getSportEquipmentType() + ", Due date: " + dueDate);
           } catch (InvalidRentalException | NoSuchSportEquipmentException e) {
           System.out.println(e.getClass().getSimpleName() + ": " + e.getMessage());
          
       }
       try {
           String borrower = "Student-5";
           String code = "56789";
           LocalDate dueDate = LocalDate.of(2026, 01, 1);
           kuSportsHub.borrowSportEquipment(borrower, code, dueDate);
           System.out.println("Rental created: Borrower: " + borrower + ", SportEquipment: " + kuSportsHub.getSportEquipments().get(code).getSportEquipmentType() + ", Due date: " + dueDate);
           } catch (InvalidRentalException | NoSuchSportEquipmentException e) {
           System.out.println(e.getClass().getSimpleName() + ": " + e.getMessage());
          
       }
      
       System.out.println("\n ----------  Returns: ---------- ");
       try {
           String code = "12345";
           kuSportsHub.returnSportEquipment(code);
           System.out.println("SportEquipment returned: " + kuSportsHub.getSportEquipments().get(code).getSportEquipmentType() + ", code: " + code);
       } catch (NoSuchSportEquipmentException e) {
           System.out.println(e.getClass().getSimpleName() + ": " + e.getMessage());
       }
       try {
           String code = "23456";
           kuSportsHub.returnSportEquipment(code);
           System.out.println("SportEquipment returned: " + kuSportsHub.getSportEquipments().get(code).getSportEquipmentType() + ", code: " + code);
       } catch (NoSuchSportEquipmentException e) {
           System.out.println(e.getClass().getSimpleName() + ": " + e.getMessage());
       }
       try {
           String code = "34567";
           kuSportsHub.returnSportEquipment(code);
           System.out.println("SportEquipment returned: " + kuSportsHub.getSportEquipments().get(code).getSportEquipmentType() + ", code: " + code);
       } catch (NoSuchSportEquipmentException e) {
           System.out.println(e.getClass().getSimpleName() + ": " + e.getMessage());
       }
  
       System.out.println("\n----------  All rentals: ---------- ");
       kuSportsHub.printAllRentals();

        /////////////////////////////////////////////////// In-lab Test code /////////////////////////////////////////////
        ///
       System.out.println("\n------------- Inlab - Task 1 --------------");

       try {
       String borrower = "Student-6";
       String code = "12345";
       LocalDate dueDate = LocalDate.of(2026, 02, 12);
       kuSportsHub.borrowSportEquipment(borrower, code,

       dueDate);

       System.out.println("Rental created: Borrower: " +

       borrower + ", SportEquipment: " +
       kuSportsHub.getSportEquipments().get(code).getSportEquipmentType() + ",Due date: " + dueDate);
       } catch (InvalidRentalException | NoSuchSportEquipmentException
       e) {

       System.out.println(e.getClass().getSimpleName() + ": " +

       e.getMessage());
       }
       try {
       String borrower = "Student-5";
       String code = "56789";
       LocalDate dueDate = LocalDate.of(2026, 01, 01);
       kuSportsHub.borrowSportEquipment(borrower, code, dueDate);
       System.out.println("Rental created: Borrower: " + borrower +

       ", SportEquipment: " +
       kuSportsHub.getSportEquipments().get(code).getSportEquipmentType() + ",Due date: " + dueDate);

       } catch (InvalidRentalException |

       NoSuchSportEquipmentException e) {

       System.out.println(e.getClass().getSimpleName() + ": " +

       e.getMessage());
       }
       System.out.println("\n---------- All rentals: ---------- ");
       kuSportsHub.printAllRentals();
       System.out.println("\n------------- InLab - Task 2 ------------- ");
       System.out.println("KUSportsHub Catalog:");
       kuSportsHub.printKUSportsHubCatalog();
      
	}
}

