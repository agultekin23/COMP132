package sportEquipment;

import exception.InvalidRentalException;
import exception.InvalidSportEquipmentException;
import exception.NoSuchSportEquipmentException;
import rental.RentalValidator;

import java.util.Map;

public class SportEquipmentValidator {
	

	
public void validateCode(String code) throws InvalidSportEquipmentException{
		
		if(code.length()!=0) {
		if (code.length() != 5) {
			   throw new InvalidSportEquipmentException("the length of the Code should be 5");
			}}
		for (int i = 0; i < code.length(); i++) {
	        char c = code.charAt(i);
	        if (!Character.isDigit(c)) {
	            throw new InvalidSportEquipmentException("the code should contain only numeric characters.");
	        }
	    }
	}
	
public static void validateExistence(Map<String, SportEquipment> sportEquipments, String code, String kuSportsHubName) throws NoSuchSportEquipmentException {
    if (!sportEquipments.containsKey(code)) {
        throw new NoSuchSportEquipmentException("the sportEquipment with Code " + code + " does not exist in the " + kuSportsHubName + " KUSportsHub");
    }
}



}


