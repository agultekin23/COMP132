package sportEquipment;

import exception.InvalidSportEquipmentException;

public class SportEquipment {
	private String code;
	private String sportEquipmentType;
	private String owner;
	boolean isAvailable;



public SportEquipment(String code, String sportEquipmentType, String owner, boolean isAvailable) throws InvalidSportEquipmentException {
	new SportEquipmentValidator().validateCode(code)	;
	this.code = code;
	this.sportEquipmentType = sportEquipmentType;
	this.owner = owner;
	this.isAvailable = isAvailable;
		}

public String getCode() {
	return code;
}
public void setCode(String code) {
	this.code = code;
}
public String getSportEquipmentType() {
	return sportEquipmentType;
}
public void setSportEquipmentType(String sportEquipmentType) {
	this.sportEquipmentType = sportEquipmentType;
}
public String getOwner() {
	return owner;
}
public void setOwner(String owner) {
	this.owner = owner;
}
public boolean isAvailable() {
	return isAvailable;
}
public void setAvailable(boolean isAvailable) {
	this.isAvailable = isAvailable;
}
}
