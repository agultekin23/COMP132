# Fall2025-lab7

# COMP132, Fall2025, Lab 7 PreLab

# IMPORTANT

For each lab assignment, **you must include and sign (by writing your name and student ID number) the following Pledge of Honor statement at the beginning of your main method source code file. After including this statement, make sure that you do the commit and push operation on GitHub. Otherwise, your lab solution will not be graded.**
```
/* *********** Pledge of Honor ************************************************ *

I hereby certify that I have completed this lab assignment on my own
without any help from anyone else. I understand that the only sources of authorized
information in this lab assignment are (1) the course textbook, (2) the
materials posted on the course website, and (3) any study notes handwritten by myself.
I have not used, accessed, or received any information from any other unauthorized
source in taking this lab assignment. The effort in the assignment thus belongs
completely to me.
READ AND SIGN BY WRITING YOUR NAME SURNAME, AND STUDENT ID
SIGNATURE: <Name Surname, Student id>
********************************************************************************/
```
## Please carefully review the following important notes. Violating each one of them will result in a grade deduction.

## IMPORTANT NOTES: 

   ##### :pushpin: - All instance variables MUST have the exact name written in the instructions.
   ##### :pushpin: - You should implement getter/setter methods whenever needed (for example, if you are going to access the instance variables from other classes). You may use auto-generator for getter/setter methods (under the Source menu in Eclipse). Do NOT implement unused Getter/Setter methods. You will be penalized for each unused Getter/Setter.
   ##### :pushpin: -  You MUST follow the instructions (Package name, Class name, method name, variables, ...) so carefully. The packages, classes, instance variables, and methods MUST be created following the descriptions given in the assignment.
   ##### :pushpin: -  Please check the sample output provided at the end of this assignment. Your output MUST be exactly the same as the provided sample output.
   ##### :pushpin: -  After you complete the tasks, do not forget to commit your changes and push them to your repository on GitHub BEFORE 9.30 :clock930: AM, Friday.
   ##### :pushpin: -  This README.md file only contains the instructions for PRELAB. You will also have INLAB questions.

  # Lab 7 Prelab: KU-IT Management Application

  In this programming lab, you will be mainly practicing **Exception Handling** and **Files Processing** by implementing an application that simulates a **KU-IT Management** system. The KU IT decided to provide electronic sportEquipments for short-term borrowing by KU members in case of emergency needs. At the same time, the KU members who own extra sportEquipments can share their sportEquipments with the people who need them via KU IT management group. So, the  KU-IT management system involves adding digital sportEquipments to the system, borrowing sportEquipments, and returning them. Each borrowing/returning operation is called a "Rental".

<div align="center">
  <img src="/img/07.png" alt="KU-IT" />
</div>

You are provided with the Main.java file and an input text file. You need to develop your assignment by following the below instructions. 

# Note: 

- Constructors generally do not have `try/catch` statements. Instead, they should `throw exceptions` when validation fails.
- Validators in this project (`SportEquipmentValidator` and `RentalValidator`) are responsible for ensuring that an entity (e.g., sport equipment code, due date) conforms to the expected formats and constraints. Validators **MUST NOT** use `try-catch` inside them. Instead, they should `throw exceptions` when validation fails.
- When an exception is caught, print its message using `System.err`.

## You need to develop your assignment by following the instructions below. 

## Package Structure:
```
src/
    sportEquipment/
        SportEquipment.java
        SportEquipmentValidator.java
    rental/
        Rental.java
        RentalValidator.java
    exception/
        InvalidSportEquipmentException.java
        InvalidRentalException.java
        NoSuchSportEquipmentException.java
    sportsHubGUI/
        KUSportsHubGUI.java
    main/
        Input.txt
        Processor.java
        Main.java
        KUSportsHub.java
```

## SportEquipment Class

This class represents the electronic sportEquipments' features as follows:

### Fields:
- `String code`: Each SportEquipment code should include 5 digits
- `String sportEquipmentType`: SportEquipment types can be Ball, Rocket, Mat, etc.
- `String owner`: Indicates the name of the owner
- `boolean isAvailable` 


### Methods:
- A public constructor with the signature `SportEquipment(String code, String sportEquipmentType, String owner, boolean isAvailable)`: The constructor uses `SportEquipmentValidator .validateCode(String code)` to validate the provided code, if any.

## SportEquipmentValidator Class

### Methods:

- `void validateCode` method with signature (String code) validates:
    - If the length of the Code is different than 5, it throws an `InvalidSportEquipmentException`.
    - If the Code contains any non-numeric characters, it throws an `InvalidSportEquipmentException`.
- `void validateExistence` method with signature (`Map<String, SportEquipment> sportEquipments, String code, String kuSportsHubName`) validates:
    - If `sportEquipments` Map does not contain a sportEquipment with the given Code, it throws NoSuchSportEquipmentException.
    - Note: the parameter kuSportsHubName is passed to use in formatting the exception message. 

## Rental Class

### Fields:
- `String borrower`
- `SportEquipment sportEquipment`
- `LocalDate dueDate`
- `boolean isReturned` (default value is false)

### Methods:
- A constructor with the signature `Rental(String borrower, SportEquipment sportEquipment, LocalDate dueDate)`. 
   - The constructor validates the `dueDate` using the `RentalValidator`, where if the `dueDate` is invalid, it throws an `InvalidRentalException`.

## RentalValidator Class

### Methods:

- `void validateDueDate` method with signature (`LocalDate dueDate`) 
    - If the `dueDate` is before the current date, it throws an `InvalidRentalException`.

# Custom Exception Classes

## InvalidSportEquipmentException Class

This is a custom exception class. It takes an error message and prints "`SportEquipment` is invalid because " + error message which states why this exception was thrown. 
Examples:
    - If the length of the Code of a `sportEquipment` is different than 5, it should print "`SportEquipment` is invalid because the length of the Code should be 5".
    - If the Code contains any non-numeric characters, it should print "`SportEquipment` is invalid because the code should contain only numeric characters".

## InvalidRentalException Class

This is a custom exception class. It takes an error message and prints "Rental is invalid because " + error message, which states why this exception was thrown. 
Example:
    - If the `dueDate` of the rental is before the current date, it should print "Rental is invalid because the dueDate should be after the current date".

## NoSuchSportEquipmentException Class

This is a custom exception class. It takes an error message and prints "Rental aborted because " + error message which states why this exception was thrown. 
Example:
    - A `sportEquipment` with Code … is given, and this `sportEquipment` does not exist in the specified `KUSportsHub`, it should print "Rental aborted because the `sportEquipment` with Code … does not exist in the … `KUSportsHub`".



## KUSportsHub  Class
### Fields:
- `String name`:  Indicates the campus name, such RF, West, İstinye, … .
- `SportEquipmentValidator sportEquipmentValidator`
- `RentalValidator rentalValidator`
- `HashMap<String, SportEquipment> sportEquipments`: The keys of the map are the Code of the `sportEquipment`. The values of the map are the `SportEquipment` object.
- `ArrayList rentals`

### Methods:
- A constructor with the signature public `KUSportsHub(String name)`
- `void addSportEquipment` method with signature (`SportEquipment sportEquipment`) 
    - Validate `sportEquipment`
    - Add the passed `sportEquipment` to the `sortEquipments` map. 
- `void borrowSportEquipment` method with signature (`String borrower, String code, LocalDate dueDate`)
    - Validate existence of `sportEquipment` and rental (by crateing a Rental object)
    - Update the availability of the `sportEquipment`
    - Add rental object to `rentals` List. 
- `void returnSportEquipment` method with signature (`String code`)
    - Validate existence of `sportEquipment`
    - Update the availability of the `sportEquipment`
    - Update isReturned field of rental. (hint: by looping through `rentals` arrayList to find the right rental)
- `printAllRentals` method prints the information of all rentals.


## Processor  Class
This class handles the file-processing procedure using a method with the following signature:
`public static void processInputFile(KUSportsHub kuSportsHub, String filePath)`. 

This method should do the following tasks, along with handling the possible exceptions.
- Use Scanner class for reading the file. Note: make sure to handle the necessary exceptions when opening the file (`FileNotFoundException`). 
- It should check the line format, where each line should include 3 items of information.
- It should add valid inputs to the `KUSportsHub` object. Each line consists of three space-separated strings. The first string is the sport equipment code. The second string is the sport equipment type. And the third string is the sports equipment owner. 

## Input Text File (given)
```
12345 Ball John  
23456 Ball Jane  
6789z Racket William 
34567 Mat Lucy 
56789 Racket Richard
56789 Swimming mat
```
## KUSportsHubGUI class
You are tasked to implement a simple Swing GUI-related application that will help you get familiar with the framework as a preparation for the project. Check the details of the task at the pdf document “PreLab7 GUI Extension Tasks.pdf”, after the sample output. 


## Sample Output

```
SportEquipment added: Ball, Code: 12345, Owner: John  
SportEquipment added: Ball, Code: 23456, Owner: Jane  
InvalidSportEquipmentException: SportEquipment is invalid because the code should contain only numeric characters.
SportEquipment added: Mat, Code: 34567, Owner: Lucy 
SportEquipment added: Racket, Code: 56789, Owner: Richard
SportEquipment added: Swimming, Code: 56789, Owner: mat

 ----------  Borrows: ---------- 
Rental created: Borrower: Student-1, SportEquipment: Ball, Due date: 2026-01-05
Rental created: Borrower: Student-2, SportEquipment: Ball, Due date: 2026-01-10
NoSuchSportEquipmentException: Rental aborted because the sportEquipment with Code 6789z does not exist in the RF KUSportsHub
Rental created: Borrower: Student-4, SportEquipment: Mat, Due date: 2026-01-25
Rental created: Borrower: Student-5, SportEquipment: Swimming, Due date: 2026-01-01

 ----------  Returns: ---------- 
SportEquipment returned: Ball, code: 12345
SportEquipment returned: Ball, code: 23456
SportEquipment returned: Mat, code: 34567

----------  All rentals: ---------- 
Borrower: Student-1, SportEquipment: 12345, Due Date: 2026-01-05, Returned: true
Borrower: Student-2, SportEquipment: 23456, Due Date: 2026-01-10, Returned: true
Borrower: Student-4, SportEquipment: 34567, Due Date: 2026-01-25, Returned: true
Borrower: Student-5, SportEquipment: 56789, Due Date: 2026-01-01, Returned: false
```

